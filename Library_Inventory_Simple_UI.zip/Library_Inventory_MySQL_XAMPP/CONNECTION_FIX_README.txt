MYSQL CONNECTION FIX — START HERE

1. Extract this ZIP into a new folder. Do not run from inside the ZIP.
2. Start MySQL in XAMPP. Note the port shown next to MySQL.
3. Run SETUP_AND_START.cmd (internet needed for initial dependencies).
4. If connection fails, a MySQL connection window now opens.
   Host: 127.0.0.1 for a database on this laptop.
   Port: the actual MySQL port shown by XAMPP, not an assumed 3307.
   Username: your database account, commonly root for local XAMPP.
   Password: that account's actual database password. Leave blank ONLY if
             the account has no password. This is not your Library login.
   Database: library_inventory, or the existing database holding your records.
5. Click Test, save and open library. A successful connection opens the app.

To change a working connection later, close Library Inventory and run
CONFIGURE_MYSQL.cmd. Saved settings take priority over mysql-config.json.
They are stored in the app's existing library-records folder under its Windows
user-data directory, so settings remain writable in packaged apps too.
The project mysql-config.json provides initial defaults only.

What this update fixes:
- Startup login/connection errors open a settings window instead of stopping
  before the library interface can appear.
- You can retry the exact port/account/password and see specific diagnostics.
- Settings are saved only after a connection and database-access test succeeds.
- mysql2 connects directly; the XAMPP mysql.exe plugin DLL is not used by the app.
- Existing inventory, accounts, backups, phone access and QR features remain.
- No passwords are reset and no database records are deleted by this fix.

If XAMPP MySQL will not remain green, fix that server startup problem first.
If the connection window says access denied, the server is running but the
credentials or permissions are wrong. The app cannot determine an unknown
password or bypass MySQL authentication.

Use the same database name as before to see existing MySQL data. A different
name creates a separate database. Existing databases are not overwritten by
connection setup. First-time migration still runs only into empty app storage.

Validation: 35 automated tests passed; one real-MySQL integration test was
skipped because no local MySQL server was available in the test environment.
The Windows/XAMPP connection must be verified on your laptop.

