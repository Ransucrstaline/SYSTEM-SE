@echo off
setlocal
cd /d "%~dp0"
set ELECTRON_RUN_AS_NODE=
echo Close any running Library Inventory window before continuing.
call npm start -- --configure-mysql
pause
