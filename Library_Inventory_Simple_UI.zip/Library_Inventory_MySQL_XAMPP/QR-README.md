# QR book labels (offline)

Open **Barcode** and select **Refresh book QR codes**. Each physical copy gets a QR generated from its unique accession number; adding a new copy creates its label automatically. Select **Print QR label** to print and attach it to the corresponding copy.

Scan with a USB QR scanner (configured to type text and Enter) or choose **Start camera scanner** if Electron/Chromium supports the BarcodeDetector API and camera permissions. You can also type an accession number. The matching book details appear on screen.

QR codes encode `LIBRARY-COPY:<accession number>`; no SQL, cloud QR service, or internet is used. Camera QR decoding depends on browser support; USB scanners and manual lookup remain available.
