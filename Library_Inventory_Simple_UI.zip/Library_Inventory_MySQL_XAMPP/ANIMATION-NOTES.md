# UI motion update

- Pages fade and rise slightly in 200 ms.
- Forms fade and scale subtly; drawers and notifications slide quickly.
- Buttons have a small press effect; card hover effects apply only to mouse devices.
- Book QR groups smoothly expand and collapse while retaining keyboard support and lazy label rendering.
- Successful lookups show a checkmark and brief green outline; QR labels stay steady.
- Returned loan rows fade after the backend confirms saving, then lists and counts refresh.
- Reduced-motion preferences disable movement.

Run as before: npm install, npm run build, npm start. The included js/app.js is also updated.
