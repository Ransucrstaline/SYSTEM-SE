# Library Inventory 3.2 improvements

- Unified QR and barcode accession lookup, with Borrow and Return buttons on the scanned book card. Existing backend loan rules, fine calculations, and member selection remain in use.
- Dashboard: six-month borrowing trend and overdue/upcoming due alerts, computed from local JSON data.
- Backup panel: validates stored snapshots and explains the importance of exporting off-computer backups. Existing automatic daily snapshots, restore and JSON export are retained.
- Subtle screen/button transitions and reduced-motion support.

## Run
`npm install` then `npm start`. The first launch requires an administrator password. Records are stored automatically on this computer.

## Notes
Camera QR recognition requires Chromium BarcodeDetector support; USB scanners and typed accession numbers still work. For off-computer protection, export JSON backups to USB regularly.
