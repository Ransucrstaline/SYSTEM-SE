# Phone setup (Android and iPhone)
1. On the computer, run `npm install`, then `npm run build`, then `npm start`.
2. Sign in. Open Barcode and press **Connect phone**.
3. Connect the phone and computer to the same trusted Wi-Fi/router. Scan the connection QR with your phone camera and open the link (or type the displayed address). Allow the app through Windows Firewall on Private networks if prompted. Guest Wi-Fi may block device connections.
4. The phone opens the library interface. In Barcode, press **Take photo / choose image** and photograph a book barcode or QR label. You can also upload an existing clear photo or type the accession number.
5. The matching book appears with Borrow and Return buttons. These use the desktop's existing validation and JSON storage. Refresh another device's view after changes.

The computer and app must stay running and signed in. No internet is required after initial dependency installation/build. This is paired local-network access, not a standalone phone installation. Live camera preview requires a secure browser context; on a normal HTTP Wi-Fi connection use the photo button, which opens the phone's camera. The included ZXing decoder reads QR and common linear barcodes without relying on native BarcodeDetector support. Printed codes must contain that copy's accession number (or LIBRARY-COPY: followed by it); an ISBN alone cannot identify an individual physical copy.

Pairing links grant full inventory access: share only with trusted staff on a trusted network. Local HTTP is not encrypted. Disconnect phones or sign out on the desktop to revoke access. Each new connection generates a new link. Keep security, account changes, backup browsing and restoring on the desktop. Existing desktop features and JSON storage remain in place.
