# Library Inventory — MySQL / XAMPP

Read **MYSQL_XAMPP_SETUP.txt** for complete Windows setup, migration, phone access,
backup, restore, and troubleshooting instructions. Start MySQL in XAMPP, edit
mysql-config.json if needed, then run SETUP_AND_START.cmd.

The existing Electron desktop interface, phone HTTPS server, QR/barcode scanning,
borrowing, returns, reports, and images use MySQL persistence. Each collection has
its own SQL table; each record retains its complete fields in a LONGTEXT column.
All inventory saves and recovery snapshots are transactional. The sql.js dependency
is retained solely to read the prior SQLite database during initial migration.

Run `npm run db:check` to check credentials. Run `npm test` for unit tests.
Integration tests run only when LIBRARY_MYSQL_TEST=1 is set and use a temporary
unique database on the configured MySQL server (database creation permission needed).
