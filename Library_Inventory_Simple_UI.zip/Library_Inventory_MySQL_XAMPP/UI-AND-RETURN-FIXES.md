# Reports, settings, backups and returns update

- Reports now have consistent date filters, summary cards, a scrolling table with fixed headings and a clear empty state. Invalid date ranges are rejected. The main Refresh action now works.
- Settings and backups use a responsive dialog, labeled numeric fields, styled actions and a verified snapshot list. Escape closes the dialog; backup restoration still asks before replacing records.
- Borrowed & Return now shows outstanding loans only. Returning a book removes it immediately; revisiting the page starts with On loan. Completed transactions remain in Reports & History for reporting, fines and audit records.
- Fixed initialization before administrator login. Locked or unreadable storage no longer silently creates sample records, which could overwrite saved return changes. Existing JSON data loads after successful login.
- Kept offline local JSON storage, QR/barcode tools, covers, members, reporting and backup features.

## Start
Extract the project, open its folder in a terminal, run `npm install` and then `npm start`.
Keep the same Windows account and app identity to use your existing saved records. Your installed app data is not stored inside this ZIP.

## Validation
Build passed and all 21 automated tests passed, including return persistence across backend restart and protection against locked/corrupt storage being replaced by samples.
Visual browser inspection could not run in the build environment because a browser executable was unavailable.
