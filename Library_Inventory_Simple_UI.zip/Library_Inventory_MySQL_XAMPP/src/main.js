import { addDays } from "./dates.js";
import { get, post, put, storageInfo } from "./api.js";
import { $, config, store, emit, on, changed, today } from "./util.js";
import { toast, segmented, initLayers, confirmDialog } from "./ui.js";
import catalog from "./catalog.js";
import loans from "./loans.js";
import { checkoutCopy, returnLoan } from "./actions.js";
import members from "./members.js";

const extraView=(id,label,show)=>({el:document.querySelector('#view-'+id),primary:{label,run:show},searchInput:document.querySelector('#scannerInput'),show});
const views = { dashboard:extraView('dashboard','Refresh',renderDashboard), catalog, loans, members, reports:extraView('reports','Refresh',renderReports), scanner:extraView('scanner','Find book',()=>document.querySelector('#scannerInput').focus()) };
let active = "dashboard";
let authUnlocked = false;

initLayers();

/* ---------- Navigation ---------- */
const tabs = segmented($("#tabs"), (v) => { location.hash = v; });
function go(name) {
  if (!views[name]) name = "dashboard";
  if (!authUnlocked) return;
  active = name;
  Object.entries(views).forEach(([k, v]) => { v.el.hidden = k !== name; });
  tabs.set(name);
  $("#primaryLabel").textContent = views[name].primary.label;
  const label = name === "catalog" ? "Library Inventory" : name[0].toUpperCase() + name.slice(1);
  document.title = `${label} · Library Inventory`;
  views[name].show();
}
addEventListener("hashchange", () => go(location.hash.slice(1)));
$("#primaryAction").addEventListener("click", async () => {
  try { await views[active].primary.run(); } catch (ex) { toast(ex.message); }
});

/* ---------- Stats (counts in the filters, summary line) ---------- */
async function refreshStats() {
  try { store.stats = await get("/stats"); emit("stats-updated"); } catch { /* shown by the views */ }
}
on("data-changed", refreshStats);

/* ---------- Theme + header ---------- */
$("#themeToggle").addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem("libraryCatalogTheme", next); } catch { /* private mode */ }
});
const topbar = $("#topbar");
const onScroll = () => topbar.classList.toggle("scrolled", scrollY > 8);
addEventListener("scroll", onScroll, { passive: true });
onScroll();

/* ---------- Backup, restore, erase ---------- */
$("#exportButton").addEventListener("click", async () => {
  try {
    const blob = new Blob([JSON.stringify(await get("/export"))], { type: "application/json" });
    const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `library-catalog-${today()}.json` });
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    toast("Backup downloaded");
  } catch (ex) { toast(ex.message); }
});

$("#importButton").addEventListener("click", () => $("#importFile").click());
$("#importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  try {
    const json = JSON.parse(await file.text());
    if (json && json.format === "library-catalog-full") {   // made by Export: replaces everything
      const ok = await confirmDialog({ title: "Restore this backup?", message: "Everything currently in the inventory will be replaced by the contents of the backup file.", confirmLabel: "Restore", danger: true });
      if (!ok) return;
      const r = await post("/restore", json);
      Object.assign(config, await get("/config"));
      toast(`Restored ${r.titles} titles, ${r.members} members and ${r.loans} loans`);
    } else {                                                // older records: added to what you have
      const r = await post("/import", json);
      const parts = [r.titles && `${r.titles} titles`, r.copies && `${r.copies} copies`, r.members && `${r.members} members`].filter(Boolean);
      toast(parts.length ? `Imported ${parts.join(", ")}${r.skipped ? `, skipped ${r.skipped}` : ""}` : "Nothing new to import");
    }
    changed();
  } catch (ex) { toast(ex instanceof SyntaxError ? "That file isn't valid JSON." : ex.message); }
});

$("#eraseButton").addEventListener("click", async () => {
  const ok = await confirmDialog({ title: "Erase all data?", message: "Every title, copy, member and loan will be deleted from this browser. Export a backup first if you might need it.", confirmLabel: "Erase everything", danger: true });
  if (!ok) return;
  try { await post("/reset", { sample: false }); toast("All data erased"); changed(); } catch (ex) { toast(ex.message); }
});

/* ---------- Shortcuts: / to search, N for a new record ---------- */
document.addEventListener("keydown", (e) => {
  if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector(".layer.open")) return;
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)) return;
  if (e.key === "/" && views[active].searchInput) { e.preventDefault(); views[active].searchInput.focus(); }
  else if (e.key.toLowerCase() === "n") { e.preventDefault(); $("#primaryAction").click(); }
});

/* ---------- Start ---------- */
$("#footerYear").textContent = new Date().getFullYear();
$("#saveNote").textContent = storageInfo.desktop ? "Saved automatically to the MySQL database" : storageInfo.persistent ? "Saved automatically in this browser" : "Not saved: this browser is blocking storage";
(async () => {
  // Read inventory only after authentication in checkAuth().
  if (storageInfo.migrated) toast(`Moved ${storageInfo.migrated} titles over from your previous inventory`);
  else if (!storageInfo.persistent) toast("Changes won't be kept. Use Export backup before closing this tab.");
  // Data is loaded after the administrator unlocks local storage.
})();

/* Desktop tools: printable report, verified backups, transaction log, borrowing settings. */
const toolsBtn=document.querySelector('#toolsButton');
toolsBtn?.addEventListener('click',async()=>{
  const old=document.querySelector('#desktopTools'); if(old){old.remove();return;}
  const box=document.createElement('section');box.id='desktopTools';
  box.className='tools-dialog';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-labelledby','toolsTitle');
  const previousFocus=document.activeElement;
  const closeTools=()=>{box.remove();document.removeEventListener('keydown',toolsKeys);previousFocus?.focus();};
  const toolsKeys=e=>{if(document.querySelector('.layer.open'))return;if(e.key==='Escape')closeTools();if(e.key==='Tab'){const items=[...box.querySelectorAll('button,input')].filter(x=>!x.disabled);if(e.shiftKey&&document.activeElement===items[0]){e.preventDefault();items.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===items.at(-1)){e.preventDefault();items[0].focus();}}};
  document.addEventListener('keydown',toolsKeys);
  box.innerHTML=`<div class="tools-shell"><header class="tools-header"><div><span class="eyebrow">WORKSPACE PREFERENCES</span><h2 id="toolsTitle">Settings & backups</h2></div><button class="btn" id="toolClose" type="button" aria-label="Close settings">Close ✕</button></header><div class="tools-body"><section class="tools-card"><h3>Borrowing rules</h3><div id="toolSettings"></div></section><section class="tools-card"><h3>Account security</h3><p>Keep your recovery key somewhere safe.</p><form id="securityForm" class="settings-grid"><label>Current password<input name="current" type="password" required autocomplete="current-password"></label><label>New password<input name="next" type="password" minlength="8" maxlength="256" autocomplete="new-password"></label><label>Confirm new password<input name="confirm" type="password" autocomplete="new-password"></label><button class="btn" name="change">Change password</button><button class="btn" name="recovery">Generate recovery key</button></form></section><section class="tools-card"><h3>Backups & recovery</h3><p>Save or restore a backup.</p><div class="tools-actions"><button class="btn btn-primary" id="toolExport">Export backup</button><button class="btn" id="toolImport">Import backup</button><button class="btn" id="toolBackups">View database snapshots</button></div></section><section class="tools-card"><h3>Reports & activity</h3><div class="tools-actions"><button class="btn" id="toolPrint">Print inventory</button><button class="btn" id="toolLogs">View activity log</button></div></section><div id="toolOutput" class="tools-output" role="status" aria-live="polite"></div></div></div>`;
  document.body.append(box);box.querySelector('#toolClose').onclick=closeTools;box.querySelector('#toolClose').focus();
  box.querySelector('#toolExport').onclick=()=>$('#exportButton').click();
  box.querySelector('#toolImport').onclick=()=>{closeTools();$('#importButton').click();};
  const output=box.querySelector('#toolOutput');
  box.querySelector('#securityForm').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget;try{if(e.submitter.name==='recovery'){const r=await window.libraryDesktop.account('recovery',{current:f.elements.current.value});output.textContent='Save this recovery key offline. Generating another key invalidates this one: '+r.recoveryKey;}else{if(f.elements.next.value!==f.elements.confirm.value)throw Error('New passwords do not match');await window.libraryDesktop.account('change',{current:f.elements.current.value,password:f.elements.next.value});output.textContent='Password changed.';}f.reset();}catch(err){output.textContent=err.message;}};
  try { const cfg=await get('/config'); const keys=['loanDays','renewDays','maxRenewals','maxLoansPerMember','finePerDay'];const labels=['Loan days','Renewal days','Maximum renewals','Maximum active loans','Fine per overdue day (₱)'];
    const form=document.createElement('form');form.className='settings-grid';
    keys.forEach((k,i)=>{const label=document.createElement('label');label.textContent=labels[i]+' ';const input=document.createElement('input');input.type='number';input.name=k;input.min=k==='maxRenewals'||k==='finePerDay'?'0':'1';input.max=k==='finePerDay'?'10000':'365';input.value=cfg[k];input.step=k==='finePerDay'?'0.01':'1';input.required=true;label.append(input);form.append(label);});
    const submit=document.createElement('button');submit.textContent='Save rules';submit.className='btn btn-primary';form.append(submit);box.querySelector('#toolSettings').append(form);
    form.onsubmit=async e=>{e.preventDefault();try{const obj=Object.fromEntries(keys.map(k=>[k,Number(form.elements[k].value)]));Object.assign(config,await put('/config',obj));output.textContent='Borrowing rules saved.';toast('Borrowing rules saved');}catch(err){output.textContent=err.message;}};
  }catch(e){output.textContent=e.message;}
  box.querySelector('#toolLogs').onclick=async()=>{try{output.textContent=(await get('/activity')).map(x=>`${x.at}  ${x.action}`).join('\n')||'No transactions recorded yet.';}catch(e){output.textContent=e.message;}};
  box.querySelector('#toolBackups').onclick=async()=>{try{const backups=await window.libraryDesktop.backups();output.replaceChildren();for(const b of backups){const line=document.createElement('div');line.className='backup-row';line.textContent=b.name+(b.valid?' — Verified':' — CORRUPT: '+b.error)+' ';if(b.valid){const btn=document.createElement('button');btn.textContent='Restore';btn.className='btn btn-sm';btn.onclick=async()=>{if(!(await confirmDialog({title:'Restore snapshot?',message:'Replace current inventory with '+b.name+'? Current data is saved as a recovery snapshot.',confirmLabel:'Restore',danger:true})))return;try{await window.libraryDesktop.restoreBackup(b.name);location.reload();}catch(e){alert(e.message);}};line.append(btn);}output.append(line);}if(!backups.length)output.textContent='No backup snapshots yet.';const note=document.createElement('p');note.textContent='Keep a backup on a USB drive.';output.append(note);}catch(e){output.textContent=e.message;}};
  box.querySelector('#toolPrint').onclick=async()=>{try{const r=await get('/report');const win=window.open('','_blank');if(!win){output.textContent='Enable print popups in this app.';return;}const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));win.document.write(`<title>Library inventory report</title><style>body{font:14px Arial;margin:30px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #999;padding:5px;text-align:left}</style><h1>Library inventory report</h1><p>Generated ${esc(r.generatedAt)} · Titles: ${r.titles.length} · Copies: ${r.copies.length} · Members: ${r.members.length} · Loans: ${r.loans.length}</p><table><tr><th>Accession / Barcode</th><th>Title</th><th>Location</th><th>Condition</th></tr>${r.copies.map(c=>`<tr><td>${esc(c.accessionNumber)}</td><td>${esc(r.titles.find(t=>t.id===c.titleId)?.title)}</td><td>${esc(c.location)}</td><td>${esc(c.status)}</td></tr>`).join('')}</table>`);win.document.close();win.focus();win.print();}catch(e){output.textContent=e.message;}};
});


/* Unified scanner uses existing circulation validation and member selection. */
window.libraryQuickActions={
  borrow(copy,title){checkoutCopy(copy,title.title||'Book');},
  async returnCopy(copy){try{const active=await get('/loans?status=active&q='+encodeURIComponent(copy.accessionNumber));const loan=active.find(l=>l.copyId===copy.id||l.accessionNumber===copy.accessionNumber);if(!loan){toast('No active loan found for this copy');return;}if(!(await confirmDialog({title:'Return this book?',message:'Confirm return of '+copy.accessionNumber+'; any overdue fine will be calculated.',confirmLabel:'Return book'})))return;await returnLoan(loan.id);}catch(e){toast(e.message);}}
};
on('data-changed',()=>window.dispatchEvent(new Event('library-scan-refresh')));
/* Enhanced dashboard, reports, scanner and secure startup. */
const escapeHtml=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function cards(items){return items.map(([name,value])=>`<article class="dash-card"><span>${escapeHtml(name)}</span><strong>${escapeHtml(value)}</strong></article>`).join('');}
async function renderDashboard(){
  try{
    const [s,activity,report]=await Promise.all([get('/stats'),get('/activity'),get('/report')]);
    $('#dashboardCards').innerHTML=cards([['Book titles',s.titles],['Physical copies',s.copies],['Available copies',s.availableCopies],['Currently borrowed',s.onLoan],['Overdue loans',s.overdue],['Active members',s.members],['Unpaid fines','₱'+s.unpaidFines]]);
    renderDashboardInsights(report);
    $('#dashboardActivity').innerHTML=activity.length?activity.slice(0,15).map(a=>`<p><time>${escapeHtml(a.at)}</time> — ${escapeHtml(a.action)}</p>`).join(''):'No recent activity.';
  }catch(e){$('#dashboardActivity').textContent=e.message;}
}
function renderDashboardInsights(r){
  const host=$('#dashboardInsights');if(!host)return;
  const now=today(),soon=addDays(today(),3);
  const overdue=r.loans.filter(l=>!l.returnedAt&&l.dueAt<now),dueSoon=r.loans.filter(l=>!l.returnedAt&&l.dueAt>=now&&l.dueAt<=soon);
  const months=Array.from({length:6},(_,i)=>{const d=new Date(today().slice(0,7)+'-01T00:00:00Z');d.setUTCMonth(d.getUTCMonth()-5+i);return {key:d.toISOString().slice(0,7),label:d.toLocaleString(undefined,{month:'short',timeZone:'Asia/Manila'})};});
  const counts=months.map(m=>r.loans.filter(l=>String(l.borrowedAt||'').startsWith(m.key)).length),max=Math.max(1,...counts);
  host.innerHTML=`<div class="insight-alerts"><h3>Circulation alerts</h3><p><strong>${overdue.length}</strong> overdue loan${overdue.length===1?'':'s'} · <strong>${dueSoon.length}</strong> due in the next 3 days</p><button class="btn" id="alertsLoans">Review borrowing records →</button></div><div class="insight-chart"><h3>Borrowing trend · last 6 months</h3><div class="chart-bars" role="img" aria-label="Monthly loans: ${months.map((m,i)=>m.label+' '+counts[i]).join(', ')}">${months.map((m,i)=>`<div class="chart-col"><b>${counts[i]}</b><span style="height:${Math.max(4,counts[i]/max*112)}px"></span><small>${m.label}</small></div>`).join('')}</div></div>`;
  $('#alertsLoans').onclick=()=>location.hash='loans';
}
let reportRows=[];
async function renderReports(){
  try{
    const from=$('#reportFrom').value,to=$('#reportTo').value;if(from&&to&&from>to){toast('From date must be before the To date');return false;}const r=await get('/report');
    const titles=new Map(r.titles.map(t=>[t.id,t]));const copies=new Map(r.copies.map(c=>[c.id,c]));const members=new Map(r.members.map(m=>[m.id,m]));
    reportRows=r.loans.map(l=>{const c=copies.get(l.copyId)||{};return {borrowed:l.borrowedAt||l.loanedAt||l.createdAt||'',returned:l.returnedAt||'',due:l.dueAt||'',title:titles.get(c.titleId)?.title||'Unknown',accession:c.accessionNumber||'',member:members.get(l.memberId)?.name||'Unknown',status:l.returnedAt?'Returned':(l.dueAt&&l.dueAt<today()?'Overdue':'On loan')};}).filter(x=>(!from||x.borrowed.slice(0,10)>=from)&&(!to||x.borrowed.slice(0,10)<=to)).reverse();
    $('#reportSummary').innerHTML=cards([['Transactions',reportRows.length],['Active',reportRows.filter(x=>x.status==='On loan').length],['Returned',reportRows.filter(x=>x.status==='Returned').length],['Overdue',reportRows.filter(x=>x.status==='Overdue').length]]);
    const headers=['Borrowed','Book','Accession','Borrower','Due','Returned','Status'];
    $('#reportHistory').innerHTML=reportRows.length?'<div class="report-scroll"><table class="report-table"><thead><tr>'+headers.map(h=>'<th>'+h+'</th>').join('')+'</tr></thead><tbody>'+reportRows.slice(0,500).map(r=>'<tr>'+[r.borrowed,r.title,r.accession,r.member,r.due,r.returned,r.status].map(x=>'<td>'+escapeHtml(x)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'+(reportRows.length>500?'<p>Showing first 500 rows; CSV contains all matching records.</p>':''):'<div class="report-empty"><h3>No circulation records</h3><p>No borrowing records match these dates. Change the date range or check out a book.</p></div>';
  return true;}catch(e){$('#reportHistory').textContent=e.message;return false;}
}
$('#reportRefresh').onclick=renderReports;
$('#reportCsv').onclick=async()=>{
  if(!await renderReports())return;const fields=['borrowed','title','accession','member','due','returned','status'];
  const csv=[fields,...reportRows.map(r=>fields.map(k=>r[k]))].map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='library-circulation-'+today()+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
};
$('#scannerForm').onsubmit=async e=>{
  e.preventDefault();const code=$('#scannerInput').value.trim().toLowerCase();if(!code)return;
  try{const r=await get('/report'),c=r.copies.find(x=>String(x.accessionNumber).toLowerCase()===code);const target=$('#scannerResult');
    if(!c){target.textContent='No matching accession number found.';return;}
    const t=r.titles.find(x=>x.id===c.titleId);
    target.innerHTML='<h2>'+escapeHtml(t?.title||'Unknown title')+'</h2><p>Accession: '+escapeHtml(c.accessionNumber)+'</p><p>Status: '+escapeHtml(c.status)+'</p><p>Location: '+escapeHtml(c.location||'Not specified')+'</p><button class="btn btn-primary" id="scanCatalog">Open catalog</button>';
    $('#scanCatalog').onclick=()=>{location.hash='catalog';setTimeout(()=>{$('#searchInput').value=c.accessionNumber;$('#searchField').value='accessionNumber';$('#searchInput').dispatchEvent(new Event('input',{bubbles:true}));},30);};
  }catch(err){$('#scannerResult').textContent=err.message;}
};
const auth=$('#authScreen');
let recovering=false;
function setRecovery(value){
  recovering=value;
  $('#recoveryFields').hidden=!value;
  $('#recoveryBack').hidden=!value;
  $('#recoverAccount').hidden=value;
  $('#authPasswordLabel').hidden=value;
  const password=$('#authPassword');
  password.required=!value;password.disabled=value;password.value='';password.type='password';
  password.closest('.password-wrap').hidden=value;
  $('#passwordToggle').textContent='Show';
  $('#passwordToggle').setAttribute('aria-label','Show password');
  for(const i of $('#recoveryFields').querySelectorAll('input')){i.required=value;i.disabled=!value;i.value='';}
  $('#authTitle').textContent=value?'Recover your account':'Welcome back';
  $('#authHelp').textContent=value?'Use your offline recovery key to create a new administrator password.':'Enter your administrator password to unlock the library.';
  $('#authPasswordHint').textContent=value?'Choose a new password with at least 8 characters.':'Your library data stays on this computer.';
  $('#authSubmit').textContent=value?'Reset password':'Sign in';
  $('#authError').textContent='';
  (value?$('#recoveryKey'):password).focus();
}
$('#recoverAccount').onclick=()=>setRecovery(true);
$('#recoveryBack').onclick=()=>setRecovery(false);
for(const input of $('#recoveryFields').querySelectorAll('input'))input.disabled=true;

async function checkAuth(){
  try{const state=await window.libraryDesktop.authState();auth.hidden=state.authenticated;$('#recoverAccount').hidden=state.setupRequired;authUnlocked=state.authenticated;$('#authTitle').textContent=state.setupRequired?'Create your account':'Welcome back';$('#authPasswordHint').textContent=state.setupRequired?'Choose a password with at least 8 characters.':'Your library data stays on this computer.';$('#authHelp').textContent=state.setupRequired?'First launch: create an administrator password (8+ characters).':'Enter your administrator password to unlock the library.';$('#authSubmit').textContent=state.setupRequired?'Create administrator':'Sign in';if(state.authenticated){Object.assign(config,await get("/config"));await refreshStats();go(location.hash.slice(1)||'dashboard');}}
  catch(e){$('#authError').textContent=e.message;}
}
$('#authForm').onsubmit=async e=>{e.preventDefault();$('#authError').textContent='';try{const state=await window.libraryDesktop.authState();if(recovering){if($('#recoveryPassword').value!==$('#recoveryConfirm').value)throw Error('New passwords do not match');await window.libraryDesktop.account('reset',{key:$('#recoveryKey').value,password:$('#recoveryPassword').value});setRecovery(false);toast('Password reset. Generate a new recovery key in Settings.');}else await window.libraryDesktop.auth(state.setupRequired?'setup':'login',$('#authPassword').value);$('#authPassword').value='';await checkAuth();}catch(err){$('#authError').textContent=err.message;}};
$('#logoutButton').onclick=async()=>{await window.libraryDesktop.auth('logout');await checkAuth();};
checkAuth();
on('data-changed',()=>{if(active==='dashboard')renderDashboard();if(active==='reports')renderReports();});

// UI-only navigation and password visibility.
document.querySelector('#passwordToggle')?.addEventListener('click',()=>{const i=document.querySelector('#authPassword'),b=document.querySelector('#passwordToggle');i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'Show':'Hide';b.setAttribute('aria-label',i.type==='password'?'Show password':'Hide password');});
document.querySelector('#heroCatalog')?.addEventListener('click',()=>{location.hash='catalog';});
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>{location.hash=b.dataset.go;}));

window.libraryDesktop.onSaveStatus(detail=>{const e={detail};const el=$('#saveStatus');el.dataset.failed=String(!e.detail.ok);el.textContent=e.detail.ok?'Saved to MySQL · '+new Date().toLocaleTimeString('en-PH',{timeZone:'Asia/Manila'}):'Save failed: '+e.detail.error;});
