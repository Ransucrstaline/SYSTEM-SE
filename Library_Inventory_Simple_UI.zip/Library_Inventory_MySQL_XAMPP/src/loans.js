import { get } from "./api.js";
import { $, $$, esc, coverHtml, debounce, fmtDate, money, store, on } from "./util.js";
import { toast, segmented, countTo, setEmpty } from "./ui.js";
import { returnLoan, renewLoan, checkoutAny } from "./actions.js";

const el = $("#view-loans"), list = $("#loanList");
let status = "active", dirty = true, reqId = 0;

function dueCell(l) {
  if (l.returnedAt) {
    return `<span>Returned ${fmtDate(l.returnedAt)}</span><span class="sub">${l.fine > 0 ? `Fine ${money(l.fine)}, ${l.finePaid ? "paid" : "unpaid"}` : "No fine"}</span>`;
  }
  if (l.daysOverdue > 0) {
    return `<span class="state overdue"><i></i><span>${l.daysOverdue} ${l.daysOverdue === 1 ? "day" : "days"} overdue</span></span><span class="sub">Due ${fmtDate(l.dueAt)}, fine so far ${money(l.accruingFine)}</span>`;
  }
  return `<span>Due ${fmtDate(l.dueAt)}</span><span class="sub">Borrowed ${fmtDate(l.borrowedAt)}${l.renewals ? `, renewed ${l.renewals}x` : ""}</span>`;
}

function rowHtml(l, i, animate) {
  const t = { id: l.titleId, title: l.titleName, author: l.author, coverUrl: l.coverUrl };
  const actions = l.returnedAt ? "" : `<button class="btn btn-sm btn-primary" data-act="l-return" data-id="${l.id}">Return</button><button class="btn btn-sm" data-act="l-renew" data-id="${l.id}">Renew</button>`;
  return `<div class="row loan${animate ? " enter" : ""}" style="--d:${Math.min(i, 12) * 30}ms">
    <div>${coverHtml(t, true)}</div>
    <div class="cell"><button class="link" data-act="l-title" data-id="${l.titleId}">${esc(l.titleName)}</button><span class="sub">${esc(l.accessionNumber)}, ${esc(l.author)}</span></div>
    <div class="cell"><button class="link" data-act="l-member" data-id="${l.memberId}">${esc(l.memberName)}</button><span class="sub">${esc(l.memberNo)}</span></div>
    <div class="cell">${dueCell(l)}</div>
    <div class="cell actions">${actions}</div></div>`;
}

async function reload(animate = false) {
  const id = ++reqId;
  let arr;
  try { arr = await get(`/loans?status=${status}&q=${encodeURIComponent($("#loanSearch").value.trim())}`); }
  catch (ex) { toast(ex.message); return; }
  if (id !== reqId) return;
  dirty = false;
  list.innerHTML = arr.map((l, i) => rowHtml(l, i, animate)).join("");
  $("#loanResult").textContent = arr.length ? `${arr.length} ${arr.length === 1 ? "loan" : "loans"}` : "";

  const q = $("#loanSearch").value.trim();
  const msg = { active: ["Nothing is on loan", "Check an item out to see it here."], overdue: ["Nothing is overdue", "Every borrowed item is within its due date."], returned: ["No returns yet", "Returned items will be listed here."] }[status];
  setEmpty($("#loanEmpty"), !arr.length, q
    ? { title: `No match for “${q}”`, text: "Try a title, a member name or an accession number." }
    : { title: msg[0], text: msg[1], label: status === "active" ? "Check out" : "", run: checkoutAny });
}

function updateCounts() {
  if (!store.stats) return;
  $$("[data-count]", $("#loanSeg")).forEach((b) => countTo(b, store.stats[b.dataset.count] ?? 0));
  seg.move();
}

const seg = segmented($("#loanSeg"), (v) => { status = v; reload(true); });

list.addEventListener("click", async (e) => {
  const b = e.target.closest("[data-act^='l-']");
  if (!b) return;
  const id = Number(b.dataset.id);
  try {
    switch (b.dataset.act) {
      case "l-return": b.disabled = true; try { await returnLoan(id); await reload(); } finally { b.disabled = false; } break;
      case "l-renew": await renewLoan(id); break;
      case "l-title": document.dispatchEvent(new CustomEvent("open-title", { detail: id })); break;
      case "l-member": document.dispatchEvent(new CustomEvent("open-member", { detail: id })); break;
    }
  } catch (ex) { toast(ex.message); }
});

$("#loanSearch").addEventListener("input", debounce(() => reload(), 160));
on("stats-updated", updateCounts);
on("data-changed", () => { dirty = true; if (!el.hidden) reload(); });

export default {
  el,
  primary: { label: "Check out", run: () => checkoutAny().catch((ex) => toast(ex.message)) },
  searchInput: $("#loanSearch"),
  show() { status = "active"; seg.set("active"); seg.move(); updateCounts(); reload(true); }
};
