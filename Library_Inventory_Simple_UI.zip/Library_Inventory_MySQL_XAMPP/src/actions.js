// Circulation actions shared by the catalog, loans and members views.
import { get, post, del } from "./api.js";
import { formDialog, confirmDialog, toast } from "./ui.js";
import { addDays, config, money, changed } from "./util.js";

async function memberOptions() {
  const members = await get("/members?active=1");
  if (!members.length) { toast("Add a member first, in the Members tab."); return null; }
  return members.map((m) => ({ value: m.id, label: `${m.name} (${m.memberNo})` }));
}

const dueField = () => ({ name: "dueAt", label: "Due date", type: "date", required: true, value: addDays(config.loanDays) });

/* Check out one specific copy */
export async function checkoutCopy(copy, titleName) {
  const options = await memberOptions();
  if (!options) return;
  formDialog({
    title: "Check out", narrow: true, submitLabel: "Check out",
    note: `${titleName}, copy ${copy.accessionNumber}`,
    fields: [{ name: "memberId", label: "Member", type: "select", options, required: true, autofocus: true }, dueField()],
    onSubmit: async (d) => {
      await post("/loans", { copyId: copy.id, memberId: Number(d.memberId), dueAt: d.dueAt });
      toast("Checked out");
      changed();
    }
  });
}

/* Check out any title that has a free copy (used from the Loans tab) */
export async function checkoutAny() {
  const [options, titles] = await Promise.all([memberOptions(), get("/titles?status=available&sort=titleAsc")]);
  if (!options) return;
  if (!titles.length) { toast("No titles have a copy on the shelf right now."); return; }
  formDialog({
    title: "Check out", narrow: true, submitLabel: "Check out",
    fields: [
      { name: "titleId", label: "Title", type: "select", required: true, autofocus: true, options: titles.map((t) => ({ value: t.id, label: `${t.title} (${t.free} on shelf)` })) },
      { name: "memberId", label: "Member", type: "select", options, required: true },
      dueField()
    ],
    onSubmit: async (d) => {
      await post("/loans", { titleId: Number(d.titleId), memberId: Number(d.memberId), dueAt: d.dueAt });
      toast("Checked out");
      changed();
    }
  });
}

export async function reserveTitle(titleId, titleName) {
  const options = await memberOptions();
  if (!options) return;
  formDialog({
    title: "Reserve", narrow: true, submitLabel: "Reserve",
    note: `${titleName}. The member is added to the waiting list.`,
    fields: [{ name: "memberId", label: "Member", type: "select", options, required: true, autofocus: true }],
    onSubmit: async (d) => {
      await post("/reservations", { titleId, memberId: Number(d.memberId) });
      toast("Reserved");
      changed();
    }
  });
}

export async function returnLoan(loanId) {
  const r = await post(`/loans/${loanId}/return`);
  await window.libraryMotion?.returned(loanId);
  toast(r.fine > 0
    ? `Returned ${r.daysOverdue} ${r.daysOverdue === 1 ? "day" : "days"} late. Fine of ${money(r.fine)} added.`
    : "Returned");
  changed();
}

export async function renewLoan(loanId) {
  const r = await post(`/loans/${loanId}/renew`);
  toast(`Renewed until ${new Date(r.dueAt + "T00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" })}`);
  changed();
}

export async function cancelReservation(id) {
  await del(`/reservations/${id}`);
  toast("Reservation cancelled");
  changed();
}

export async function askDelete({ title, message, run, done }) {
  if (!(await confirmDialog({ title, message, confirmLabel: "Delete", danger: true }))) return;
  await run();
  done?.();
  changed();
}
