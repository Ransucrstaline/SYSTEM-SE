// The interface talks to this module exactly as it did with a server.
// Here the "server" is backend.js running in the page, saving to localStorage.
import { createBackend } from "./backend.js";

function pickStorage() {
  try {
    localStorage.setItem("__lc_test", "1");
    localStorage.removeItem("__lc_test");
    return { storage: localStorage, persistent: true };
  } catch {   // e.g. private browsing: keep working, but nothing survives closing the tab
    const m = new Map();
    return { storage: { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }, persistent: false };
  }
}

const desktop = typeof window !== "undefined" && window.libraryDesktop;
if (!desktop) throw Error("Desktop file storage unavailable. Launch using npm run desktop; browser-only storage is disabled.");
const { storage, persistent } = { storage: desktop, persistent: true };
let backend;
function getBackend(){return backend ||= createBackend(storage); }

export const storageInfo = { persistent, migrated: 0, desktop: !!desktop };
export const api = (path, { method = "GET", body } = {}) => desktop.remote ? desktop.api(method,path,body) : getBackend()(method, path, body);
if(desktop.onPhoneRequest) desktop.onPhoneRequest(async({method,route,body})=>{const result=await api(route,{method,body});window.dispatchEvent(new Event('library-scan-refresh'));return result;});
export const get = (p) => api(p);
export const post = (p, body = {}) => api(p, { method: "POST", body });
export const put = (p, body) => api(p, { method: "PUT", body });
export const patch = (p, body) => api(p, { method: "PATCH", body });
export const del = (p) => api(p, { method: "DELETE" });

window.libraryAPI = api;
