import { get, post, put, patch, del } from "./api.js";
import { $, $$, esc, reduced, EASE, coverHtml, debounce, fmtDate, money, shrinkImage, store, on, changed } from "./util.js";
import { toast, segmented, countTo, showDrawer, closeDrawer, drawerContent, drawerIsOpen, formDialog, setEmpty } from "./ui.js";
import { checkoutCopy, reserveTitle, returnLoan, renewLoan, cancelReservation, askDelete } from "./actions.js";

const TYPES = ["Book", "E-book", "DVD", "Audiobook", "Journal", "Other"];
const el = $("#view-catalog"), grid = $("#catalogGrid");
let status = "all", reqId = 0, current = null, dirty = true;
const nodes = new Map();

/* ---------- State label for a title ---------- */
function titleState(t) {
  const wait = t.reservations ? `, ${t.reservations} waiting` : "";
  if (t.copiesTotal === 0) return { cls: "", label: "No copies" };
  if (t.copiesAvailable === 0 && t.copiesOnLoan === 0 && t.copiesTotal > 0) return { cls: "", label: "Missing or damaged" };
  if (t.free > 0) return { cls: "available", label: t.copiesTotal > 1 ? `${t.free} of ${t.copiesTotal} on shelf` : "On shelf" };
  if (t.copiesAvailable > 0) return { cls: "reserved", label: "Held for reservation" };
  if (t.overdue > 0) return { cls: "overdue", label: "Overdue" + wait };
  return { cls: "checked-out", label: "All out" + wait };
}

/* ---------- Grid (keyed so cards glide instead of jumping) ---------- */
const cardSig = (t) => JSON.stringify([t.title, t.author, t.type, t.callNumber, t.copiesTotal, t.copiesAvailable, t.reservations, t.overdue, t.updatedAt]);
function cardInner(t) {
  const st = titleState(t);
  return `${coverHtml(t)}<div class="card-body"><h3 class="card-title">${esc(t.title)}</h3><p class="card-author">${esc(t.author)}</p><p class="card-meta"><span class="state ${st.cls}"><i></i><span>${esc(st.label)}</span></span></p></div>`;
}

function render(arr) {
  const before = new Map();
  nodes.forEach((n, id) => before.set(id, n.getBoundingClientRect()));
  const keep = new Set(arr.map((t) => t.id));
  nodes.forEach((n, id) => { if (!keep.has(id)) { n.remove(); nodes.delete(id); } });

  let k = 0;
  arr.forEach((t) => {
    let n = nodes.get(t.id);
    if (!n) {
      n = document.createElement("article");
      n.className = "card enter";
      n.tabIndex = 0;
      n.setAttribute("role", "button");
      n.dataset.id = t.id;
      n.style.setProperty("--d", Math.min(k++, 14) * 30 + "ms");
      n.addEventListener("animationend", () => n.classList.remove("enter"), { once: true });
      nodes.set(t.id, n);
    }
    const sig = cardSig(t);
    if (n.dataset.sig !== sig) {
      n.innerHTML = cardInner(t);
      n.dataset.sig = sig;
      n.setAttribute("aria-label", `${t.title} by ${t.author}. ${titleState(t).label}`);
    }
    grid.appendChild(n);
  });

  if (!reduced) {
    nodes.forEach((n, id) => {
      const a = before.get(id);
      if (!a) return;
      const b = n.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
      if (dx || dy) n.animate([{ transform: `translate(${dx}px,${dy}px)` }, { transform: "none" }], { duration: 380, easing: EASE });
    });
  }
}

/* ---------- Loading + filters ---------- */
const val = (id) => $("#" + id).value;
const filtersActive = () => val("searchInput").trim() || val("searchField") !== "all" || val("typeFilter") !== "all" || status !== "all";

let lastCount = 0;
function updateText() {
  const s = store.stats, n = lastCount;
  $("#resultText").textContent = !n ? "" : filtersActive()
    ? `${n} of ${s ? s.titles : n} ${n === 1 ? "title" : "titles"}`
    : s ? `${s.titles} titles, ${s.copies} copies, ${s.onLoan} on loan${s.overdue ? `, ${s.overdue} overdue` : ""}` : `${n} titles`;
  $("#resetButton").hidden = !filtersActive();
}
function updateCounts() {
  if (!store.stats) return;
  $$("[data-count]", $("#statusSeg")).forEach((b) => countTo(b, store.stats[b.dataset.count] ?? 0));
  seg.move();
  updateText();
}

async function reload() {
  const id = ++reqId;
  const p = new URLSearchParams({ q: val("searchInput").trim(), field: val("searchField"), type: val("typeFilter"), sort: val("sortSelect") });
  if (status !== "all") p.set("status", status);
  let arr;
  try { arr = await get("/titles?" + p); } catch (ex) { toast(ex.message); return; }
  if (id !== reqId) return;   // a newer request is already running
  dirty = false;
  lastCount = arr.length;
  render(arr);
  updateText();

  if (!arr.length) {
    const q = val("searchInput").trim();
    if (!store.stats || store.stats.titles === 0) setEmpty($("#catalogEmpty"), true, { title: "Your inventory is empty", text: "Add your first title to start building the collection.", label: "New title", run: () => createTitle() });
    else setEmpty($("#catalogEmpty"), true, { title: q ? `No match for “${q}”` : "Nothing found", text: "Try a different word, or clear the filters.", label: "Clear filters", run: resetFilters });
  } else setEmpty($("#catalogEmpty"), false);
}

function resetFilters() {
  $("#searchInput").value = ""; $("#searchField").value = "all"; $("#typeFilter").value = "all"; $("#sortSelect").value = "newest";
  status = "all"; seg.set("all");
  reload();
}

const seg = segmented($("#statusSeg"), (v) => { status = v; reload(); });

/* ---------- Title drawer ---------- */
function copyRow(c) {
  const over = c.daysOverdue > 0;
  const state = c.status === "available" ? ["available", "Available"] : c.status === "lost" ? ["", "Missing"] : c.status === "damaged" ? ["", "Damaged"] : [over ? "overdue" : "checked-out", over ? `Overdue ${c.daysOverdue}d` : "Borrowed"];
  const sub = c.status === "on_loan"
    ? `<button class="link" data-act="t-member" data-id="${c.memberId}">${esc(c.memberName)}</button>, due ${fmtDate(c.dueAt)}`
    : esc(c.location || "No location set");
  const buttons = c.status === "available"
    ? `<button class="btn btn-sm btn-primary" data-act="t-checkout" data-copy="${c.id}">Check out</button><button class="btn btn-sm" data-act="t-editcopy" data-copy="${c.id}">Edit</button>`
    : c.status === "on_loan"
      ? `<button class="btn btn-sm btn-primary" data-act="t-return" data-copy="${c.id}">Return</button><button class="btn btn-sm" data-act="t-renew" data-copy="${c.id}">Renew</button>`
      : `<button class="btn btn-sm" data-act="t-editcopy" data-copy="${c.id}">Edit</button>`;
  return `<div class="copy"><div><strong>${esc(c.accessionNumber)}</strong><span class="copy-sub">${sub}</span></div>
    <div class="copy-actions"><span class="state ${state[0]}"><i></i><span>${state[1]}</span></span>${buttons}</div></div>`;
}

function drawerHtml(t) {
  const st = titleState(t);
  const canReserve = t.copiesTotal > 0 && t.free === 0;
  const rows = [["Call number", t.callNumber], ["ISBN", t.isbn || "Not set"], ["Publisher", t.publisher || "Not set"], ["Year", t.year], ["Edition", t.edition || "Not set"], ["Language", t.language], ["Material", t.type]];
  return `<div class="d-hero">${coverHtml(t)}<div>
      <h2 class="d-title">${esc(t.title)}</h2>${t.subtitle ? `<p class="d-sub">${esc(t.subtitle)}</p>` : ""}
      <p class="d-author">${esc(t.author)}</p><span class="state pill ${st.cls}"><i></i><span>${esc(st.label)}</span></span></div></div>
    ${t.subjects.length ? `<div class="tags">${t.subjects.map((s) => `<span class="tag">${esc(s)}</span>`).join("")}</div>` : ""}
    <div class="d-section"><div class="d-head"><h3>Copies (${t.copiesTotal})</h3><button class="btn btn-sm" data-act="t-addcopy">Add copy</button></div>
      ${t.copies.length ? t.copies.map(copyRow).join("") : '<p class="empty-line">No copies yet. Add one to make this title borrowable.</p>'}</div>
    ${t.queue.length || canReserve ? `<div class="d-section"><div class="d-head"><h3>Waiting list</h3>${canReserve ? '<button class="btn btn-sm" data-act="t-reserve">Reserve</button>' : ""}</div>
      ${t.queue.length ? t.queue.map((q) => `<div class="li"><span>${q.position}. <button class="link" data-act="t-member" data-id="${q.memberId}">${esc(q.memberName)}</button> <span class="muted">${esc(q.memberNo)}</span></span><button class="btn btn-sm" data-act="t-cancelres" data-id="${q.id}">Cancel</button></div>`).join("") : '<p class="empty-line">Nobody is waiting.</p>'}</div>` : ""}
    <div class="d-section"><h3>Details</h3><dl>${rows.map(([a, b]) => `<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join("")}</dl></div>
    ${t.description ? `<div class="d-section"><h3>About</h3><p class="d-desc">${esc(t.description)}</p></div>` : ""}
    ${t.history.length ? `<div class="d-section"><h3>Recent loans</h3>${t.history.map((h) => `<div class="li"><button class="link" data-act="t-member" data-id="${h.memberId}">${esc(h.memberName)}</button><span class="muted">${fmtDate(h.borrowedAt)} to ${h.returnedAt ? fmtDate(h.returnedAt) : "now"}${h.fine > 0 ? `, fine ${money(h.fine)}` : ""}</span></div>`).join("")}</div>` : ""}
    <div class="d-foot"><button class="btn" data-act="t-edit">Edit title</button><button class="btn btn-danger" data-act="t-delete">Delete title</button></div>`;
}

export async function openTitle(id, keepScroll = false) {
  try {
    current = await get(`/titles/${id}`);
    showDrawer(drawerHtml(current), keepScroll);
    Object.assign(drawerContent().dataset, { kind: "title", id });
  } catch (ex) { toast(ex.message); }
}

drawerContent().addEventListener("click", async (e) => {
  const b = e.target.closest("[data-act^='t-']");
  if (!b || !current) return;
  const id = Number(b.dataset.id), copy = current.copies.find((c) => c.id === Number(b.dataset.copy));
  try {
    switch (b.dataset.act) {
      case "t-checkout": await checkoutCopy(copy, current.title); break;
      case "t-return": await returnLoan(copy.loanId); break;
      case "t-renew": await renewLoan(copy.loanId); break;
      case "t-addcopy": addCopy(); break;
      case "t-editcopy": editCopy(copy); break;
      case "t-reserve": await reserveTitle(current.id, current.title); break;
      case "t-cancelres": await cancelReservation(id); break;
      case "t-member": document.dispatchEvent(new CustomEvent("open-member", { detail: id })); break;
      case "t-edit": editTitle(); break;
      case "t-delete":
        await askDelete({ title: "Delete this title?", message: `“${current.title}” and its ${current.copiesTotal} ${current.copiesTotal === 1 ? "copy" : "copies"} will be removed, along with their loan history. This can't be undone.`,
          run: () => del(`/titles/${current.id}`), done: () => { closeDrawer(); toast("Title deleted"); } });
        break;
    }
  } catch (ex) { toast(ex.message); }
});

/* ---------- Copy dialogs ---------- */
function addCopy() {
  formDialog({
    title: "Add copy", narrow: true, submitLabel: "Add copy",
    fields: [
      { name: "accessionNumber", label: "Accession number", hint: "Leave blank to generate one", maxlength: 40, autofocus: true },
      { name: "location", label: "Shelf or location", maxlength: 80, value: current.copies.at(-1)?.location || "" }
    ],
    onSubmit: async (d) => { await post(`/titles/${current.id}/copies`, d); toast("Copy added"); changed(); }
  });
}

function editCopy(copy) {
  formDialog({
    title: `Copy ${copy.accessionNumber}`, narrow: true,
    values: copy,
    fields: [
      { name: "accessionNumber", label: "Accession number", required: true, maxlength: 40, autofocus: true },
      { name: "location", label: "Shelf or location", maxlength: 80 },
      { name: "status", label: "Condition", type: "select", options: [{ value: "available", label: "In the collection" }, { value: "lost", label: "Missing" }, { value: "damaged", label: "Damaged" }] }
    ],
    secondary: [{
      label: "Remove copy", danger: true,
      run: async () => { await del(`/copies/${copy.id}`); toast("Copy removed"); changed(); }
    }],
    onSubmit: async (d) => { await patch(`/copies/${copy.id}`, d); toast("Copy updated"); changed(); }
  });
}

/* ---------- Title form ---------- */
function titleFields(creating) {
  const f = [
    { group: "Basics" },
    { name: "title", label: "Title", required: true, span: 2, maxlength: 120, autofocus: true },
    { name: "subtitle", label: "Subtitle", maxlength: 120 },
    { name: "author", label: "Author or creator", required: true, maxlength: 100 },
    { name: "type", label: "Material type", type: "select", options: TYPES.map((t) => ({ value: t, label: t })) },
    { name: "subjects", label: "Category / Subject", required: true, placeholder: "Science, Technology" },
    { name: "keywords", label: "Keywords", span: 3, placeholder: "Separate with spaces" },
    { group: "Publication" },
    { name: "isbn", label: "ISBN", maxlength: 30, placeholder: "978-…" },
    { name: "publisher", label: "Publisher", maxlength: 100 },
    { name: "year", label: "Year", type: "number", required: true, min: 1000, max: 2100, value: new Date().getFullYear() },
    { name: "edition", label: "Edition", maxlength: 50, placeholder: "3rd edition" },
    { name: "language", label: "Language", maxlength: 50, value: "English" },
    { name: "cover", label: "Book picture / cover", type: "file", hint: creating ? "Click Choose book picture to add a cover (optional)" : "Choose a new picture to replace the existing cover" },
    { group: creating ? "Shelf and copies" : "Shelf" },
    { name: "callNumber", label: "Call number", required: true, maxlength: 50 }
  ];
  if (creating) f.push(
    { name: "location", label: "Shelf or location", maxlength: 80 },
    { name: "copies", label: "Number of copies", type: "number", required: true, min: 0, max: 200, value: 1, hint: "Each copy gets its own accession number" }
  );
  f.push({ group: "Description" }, { name: "description", label: "Abstract", type: "textarea", span: 3, maxlength: 1000 });
  return f;
}

async function titlePayload(d, creating) {
  const p = {
    title: d.title, subtitle: d.subtitle, author: d.author, type: d.type, subjects: d.subjects, keywords: d.keywords,
    isbn: d.isbn, publisher: d.publisher, year: Number(d.year), edition: d.edition, language: d.language,
    callNumber: d.callNumber, description: d.description
  };
  if (creating) { p.copies = Number(d.copies); p.location = d.location; }
  if (d.cover && d.cover.size) p.cover = await shrinkImage(d.cover);
  return p;
}

export function createTitle() {
  formDialog({
    title: "New title", submitLabel: "Add title", fields: titleFields(true),
    onSubmit: async (d) => {
      const t = await post("/titles", await titlePayload(d, true));
      toast("Title added");
      changed();
      openTitle(t.id);
    }
  });
}

function editTitle() {
  formDialog({
    title: "Edit title", submitLabel: "Save changes", fields: titleFields(false),
    values: { ...current, subjects: current.subjects.join(", ") },
    onSubmit: async (d) => { await put(`/titles/${current.id}`, await titlePayload(d, false)); toast("Changes saved"); changed(); }
  });
}

/* ---------- Wiring ---------- */
grid.addEventListener("click", (e) => { const c = e.target.closest(".card"); if (c) openTitle(Number(c.dataset.id)); });
grid.addEventListener("keydown", (e) => {
  if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("card")) { e.preventDefault(); openTitle(Number(e.target.dataset.id)); }
});
$("#searchInput").addEventListener("input", debounce(reload, 160));
["searchField", "typeFilter", "sortSelect"].forEach((id) => $("#" + id).addEventListener("change", reload));
$("#resetButton").addEventListener("click", resetFilters);

on("stats-updated", updateCounts);
on("open-title", (e) => openTitle(e.detail));
on("data-changed", () => {
  dirty = true;
  if (!el.hidden) reload();
  if (drawerIsOpen() && drawerContent().dataset.kind === "title") openTitle(Number(drawerContent().dataset.id), true);
});

export default {
  el,
  primary: { label: "New title", run: createTitle },
  searchInput: $("#searchInput"),
  show() { seg.move(); if (dirty) reload(); }
};
