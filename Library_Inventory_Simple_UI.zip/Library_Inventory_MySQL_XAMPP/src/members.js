import { get, post, put, del } from "./api.js";
import { $, esc, hue, initials, debounce, fmtDate, money, on, changed } from "./util.js";
import { toast, showDrawer, closeDrawer, drawerContent, drawerIsOpen, formDialog, setEmpty } from "./ui.js";
import { returnLoan, renewLoan, cancelReservation, askDelete } from "./actions.js";

const MEMBER_TYPES = ["Student", "Faculty", "Staff", "Public"];
const el = $("#view-members"), list = $("#memberList");
let current = null, dirty = true, reqId = 0;

const avatar = (m, lg = false) => `<div class="avatar${lg ? " lg" : ""}" style="--h:${hue(m.name)}" aria-hidden="true">${esc(initials(m.name))}</div>`;

function standing(m) {
  const owed = m.unpaidFines + m.accruingFines;
  if (owed > 0) return `<span class="state overdue"><i></i><span>Owes ${money(owed)}</span></span>`;
  if (!m.active) return `<span class="state"><i></i><span>Inactive</span></span>`;
  return `<span class="state available"><i></i><span>Good standing</span></span>`;
}

function rowHtml(m, i, animate) {
  const loans = m.activeLoans ? `${m.activeLoans} on loan` : "No loans";
  return `<div class="row member${animate ? " enter" : ""}" style="--d:${Math.min(i, 12) * 30}ms" data-id="${m.id}" tabindex="0" role="button" aria-label="${esc(m.name)}">
    ${avatar(m)}
    <div class="cell"><strong>${esc(m.name)}</strong><span class="sub">${esc(m.memberNo)}, ${esc(m.type)}</span></div>
    <div class="cell"><span>${loans}</span>${m.overdueLoans ? `<span class="sub">${m.overdueLoans} overdue</span>` : ""}</div>
    <div class="cell">${standing(m)}</div></div>`;
}

async function reload(animate = true) {
  const id = ++reqId, q = $("#memberSearch").value.trim();
  let arr;
  try { arr = await get(`/members?q=${encodeURIComponent(q)}`); } catch (ex) { toast(ex.message); return; }
  if (id !== reqId) return;
  dirty = false;
  list.innerHTML = arr.map((m, i) => rowHtml(m, i, animate)).join("");
  $("#memberResult").textContent = arr.length ? `${arr.length} ${arr.length === 1 ? "member" : "members"}` : "";
  setEmpty($("#memberEmpty"), !arr.length, q
    ? { title: `No match for “${q}”`, text: "Try a name, member number, email or phone." }
    : { title: "No members yet", text: "Add the people who borrow from your library.", label: "New member", run: createMember });
}

/* ---------- Drawer ---------- */
function loanLine(l) {
  const late = l.daysOverdue > 0;
  return `<div class="li"><span><button class="link" data-act="m-title" data-id="${l.titleId}">${esc(l.titleName)}</button>
      <span class="copy-sub">${esc(l.accessionNumber)}, ${late ? `<span class="state overdue"><span>${l.daysOverdue}d overdue, ${money(l.accruingFine)} so far</span></span>` : `due ${fmtDate(l.dueAt)}`}</span></span>
    <span class="copy-actions"><button class="btn btn-sm btn-primary" data-act="m-return" data-id="${l.id}">Return</button><button class="btn btn-sm" data-act="m-renew" data-id="${l.id}">Renew</button></span></div>`;
}

function drawerHtml(m) {
  const open = m.loans.filter((l) => !l.returnedAt);
  const past = m.loans.filter((l) => l.returnedAt).slice(0, 10);
  const owed = m.unpaidFines > 0 || m.accruingFines > 0;
  return `<div class="d-hero person">${avatar(m, true)}<div>
      <h2 class="d-title">${esc(m.name)}</h2><p class="d-sub">${esc(m.memberNo)}, ${esc(m.type)}</p>
      <p style="margin-top:10px"><span class="state pill ${m.active ? "available" : ""}"><i></i><span>${m.active ? "Active" : "Inactive"}</span></span></p></div></div>
    ${owed ? `<div class="notice"><div><strong>Unpaid fines ${money(m.unpaidFines)}</strong>${m.accruingFines > 0 ? `<small>${money(m.accruingFines)} more accruing on overdue items</small>` : ""}</div>${m.unpaidFines > 0 ? '<button class="btn btn-sm" data-act="m-pay">Mark as paid</button>' : ""}</div>` : ""}
    <div class="d-section"><h3>Contact</h3><dl><dt>Email</dt><dd>${esc(m.email || "Not set")}</dd><dt>Phone</dt><dd>${esc(m.phone || "Not set")}</dd><dt>Member since</dt><dd>${fmtDate(m.createdAt.slice(0, 10))}</dd></dl></div>
    <div class="d-section"><h3>Currently borrowed (${open.length})</h3>${open.length ? open.map(loanLine).join("") : '<p class="empty-line">Nothing on loan.</p>'}</div>
    ${m.reservations.length ? `<div class="d-section"><h3>Reservations</h3>${m.reservations.map((r) => `<div class="li"><button class="link" data-act="m-title" data-id="${r.titleId}">${esc(r.titleName)}</button><button class="btn btn-sm" data-act="m-cancelres" data-id="${r.id}">Cancel</button></div>`).join("")}</div>` : ""}
    ${past.length ? `<div class="d-section"><h3>History</h3>${past.map((l) => `<div class="li"><button class="link" data-act="m-title" data-id="${l.titleId}">${esc(l.titleName)}</button><span class="muted">${fmtDate(l.borrowedAt)} to ${fmtDate(l.returnedAt)}${l.fine > 0 ? `, fine ${money(l.fine)}${l.finePaid ? " paid" : ""}` : ""}</span></div>`).join("")}</div>` : ""}
    <div class="d-foot"><button class="btn" data-act="m-edit">Edit</button><button class="btn" data-act="m-toggle">${m.active ? "Deactivate" : "Reactivate"}</button><button class="btn btn-danger" data-act="m-delete">Delete</button></div>`;
}

async function openMember(id, keepScroll = false) {
  try {
    current = await get(`/members/${id}`);
    showDrawer(drawerHtml(current), keepScroll);
    Object.assign(drawerContent().dataset, { kind: "member", id });
  } catch (ex) { toast(ex.message); }
}

drawerContent().addEventListener("click", async (e) => {
  const b = e.target.closest("[data-act^='m-']");
  if (!b || !current) return;
  const id = Number(b.dataset.id);
  try {
    switch (b.dataset.act) {
      case "m-return": await returnLoan(id); break;
      case "m-renew": await renewLoan(id); break;
      case "m-cancelres": await cancelReservation(id); break;
      case "m-title": document.dispatchEvent(new CustomEvent("open-title", { detail: id })); break;
      case "m-pay": { const r = await post(`/members/${current.id}/fines/pay`); toast(`${money(r.paid)} marked as paid`); changed(); break; }
      case "m-edit": memberForm(current); break;
      case "m-toggle": {
        const { name, email, phone, type, memberNo, active } = current;
        await put(`/members/${current.id}`, { name, email, phone, type, memberNo, active: !active });
        toast(active ? "Member deactivated" : "Member reactivated"); changed(); break;
      }
      case "m-delete":
        await askDelete({ title: "Delete this member?", message: `${current.name} will be removed. Members with loan history can't be deleted; deactivate them instead.`,
          run: () => del(`/members/${current.id}`), done: () => { closeDrawer(); toast("Member deleted"); } });
        break;
    }
  } catch (ex) { toast(ex.message); }
});

/* ---------- Form ---------- */
function memberForm(m = null) {
  formDialog({
    title: m ? "Edit member" : "New member", narrow: true, submitLabel: m ? "Save changes" : "Add member", values: m || {},
    fields: [
      { name: "name", label: "Full name", required: true, maxlength: 100, autofocus: true },
      { name: "memberNo", label: "Member number", maxlength: 30, hint: m ? "" : "Leave blank to generate one" },
      { name: "type", label: "Member type", type: "select", options: MEMBER_TYPES.map((t) => ({ value: t, label: t })), value: "Student" },
      { name: "email", label: "Email", type: "email", maxlength: 120 },
      { name: "phone", label: "Phone", maxlength: 40 }
    ],
    onSubmit: async (d) => {
      if (m) { await put(`/members/${m.id}`, d); toast("Changes saved"); changed(); }
      else { const created = await post("/members", d); toast("Member added"); changed(); openMember(created.id); }
    }
  });
}
const createMember = () => memberForm();

list.addEventListener("click", (e) => { const r = e.target.closest(".row"); if (r) openMember(Number(r.dataset.id)); });
list.addEventListener("keydown", (e) => {
  if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("row")) { e.preventDefault(); openMember(Number(e.target.dataset.id)); }
});
$("#memberSearch").addEventListener("input", debounce(() => reload(false), 160));

on("open-member", (e) => openMember(e.detail));
on("data-changed", () => {
  dirty = true;
  if (!el.hidden) reload(false);
  if (drawerIsOpen() && drawerContent().dataset.kind === "member") openMember(Number(drawerContent().dataset.id), true);
});

export default {
  el,
  primary: { label: "New member", run: createMember },
  searchInput: $("#memberSearch"),
  show() { if (dirty) reload(true); }
};
