// The whole "server" running inside the browser.
// It exposes the same routes the interface calls (GET /titles, POST /loans, ...) but keeps all
// records in one JSON document saved to localStorage after every change.
import { today, addDays, daysBetween, isDate } from "./dates.js";

export const DEFAULT_CONFIG = {
  loanDays: 14,          // default loan period
  renewDays: 7,          // extra days per renewal
  maxRenewals: 2,        // renewals allowed per loan
  maxLoansPerMember: 5,  // simultaneous loans
  finePerDay: 5,         // fine for each day a loan is overdue
  currency: "₱"
};
export const CONFIG = { ...DEFAULT_CONFIG };
export const TYPES = ["Book", "E-book", "DVD", "Audiobook", "Journal", "Other"];
export const MEMBER_TYPES = ["Student", "Faculty", "Staff", "Public"];

const STORAGE_KEY = "libraryCatalogDB_v3";
const LEGACY_KEYS = ["libraryCatalogItemsV2", "libraryCatalogItems"];   // the original single-file version
const COVER_RE = /^data:image\/(?:png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/;

/* ---------- Errors and validation ---------- */
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const bad = (m) => new HttpError(400, m);
const notFound = (w) => new HttpError(404, `${w} not found`);
const conflict = (m) => new HttpError(409, m);

function str(v, { name = "Field", max = 200, required = false } = {}) {
  const s = v == null ? "" : String(v).trim();
  if (required && !s) throw bad(`${name} is required`);
  if (s.length > max) throw bad(`${name} must be at most ${max} characters`);
  return s;
}
function int(v, { name = "Field", min = -Infinity, max = Infinity } = {}) {
  const n = Number(v);
  if (v === "" || v == null || !Number.isInteger(n)) throw bad(`${name} must be a whole number`);
  if (n < min || n > max) throw bad(`${name} must be between ${min} and ${max}`);
  return n;
}
function oneOf(v, list, name) {
  if (!list.includes(v)) throw bad(`${name} must be one of: ${list.join(", ")}`);
  return v;
}
function dateStr(v, name) {
  if (!isDate(v)) throw bad(`${name} must be a date (YYYY-MM-DD)`);
  return v;
}
const lower = (s) => String(s || "").toLowerCase();
const words = (q, max = 8) => lower(q).split(/\s+/).filter(Boolean).slice(0, max);
const splitSubjects = (v) => (Array.isArray(v) ? v : String(v || "").split(",")).map((x) => String(x).trim()).filter(Boolean);

function parseCover(v) {
  if (v === undefined) return undefined;          // keep the current cover
  if (v === null || v === "") return null;        // remove it
  if (typeof v !== "string" || !COVER_RE.test(v)) throw bad("Cover must be a PNG, JPEG, WebP or GIF image");
  if (v.length > 1_000_000) throw bad("Cover image is too large");
  return v;
}

function parseTitle(b) {
  const subjects = splitSubjects(b.subjects);
  if (!subjects.length) throw bad("At least one subject is required");
  return {
    title: str(b.title, { name: "Title", max: 120, required: true }),
    subtitle: str(b.subtitle, { name: "Subtitle", max: 120 }),
    author: str(b.author, { name: "Author", max: 100, required: true }),
    isbn: str(b.isbn, { name: "ISBN", max: 30 }),
    publisher: str(b.publisher, { name: "Publisher", max: 100 }),
    year: int(b.year, { name: "Year", min: 1000, max: 2100 }),
    edition: str(b.edition, { name: "Edition", max: 50 }),
    language: str(b.language, { name: "Language", max: 50 }) || "English",
    type: oneOf(b.type || "Book", TYPES, "Type"),
    subjects: subjects.join(", "),
    keywords: str(b.keywords, { name: "Keywords", max: 300 }),
    callNumber: str(b.callNumber, { name: "Call number", max: 50, required: true }),
    description: str(b.description, { name: "Description", max: 1000 })
  };
}

function parseMember(b, current) {
  const email = str(b.email, { name: "Email", max: 120 });
  if (email && !/^\S+@\S+\.\S+$/.test(email)) throw bad("Email doesn't look right");
  return {
    name: str(b.name, { name: "Name", max: 100, required: true }),
    email,
    phone: str(b.phone, { name: "Phone", max: 40 }),
    type: oneOf(b.type || "Student", MEMBER_TYPES, "Member type"),
    memberNo: str(b.memberNo, { name: "Member number", max: 30 }) || current?.memberNo || "",
    active: b.active === undefined ? (current ? current.active : true) : !!b.active
  };
}


export function validateInventory(d) {
  if (!d || typeof d !== 'object' || Array.isArray(d)) throw Error('Inventory must be an object');
  const kinds = ['titles','copies','members','loans','reservations'];
  for (const k of kinds) if (!Array.isArray(d[k]) || d[k].length > 200000) throw Error(`Invalid ${k} collection`);
  if (!d.seq || typeof d.seq !== 'object') throw Error('Missing sequence counters');
  const ids = {};
  for (const k of kinds) {
    ids[k] = new Set();
    for (const r of d[k]) {
      if (!r || !Number.isSafeInteger(r.id) || r.id < 1 || ids[k].has(r.id)) throw Error(`Invalid or duplicate ${k} ID`);
      ids[k].add(r.id);
    }
  }
  for (const [counter, kind] of Object.entries({title:'titles',copy:'copies',member:'members',loan:'loans',res:'reservations'})) {
    if (!Number.isSafeInteger(d.seq[counter]) || d.seq[counter] < Math.max(0,...ids[kind])) throw Error(`Invalid ${counter} sequence`);
  }
  const accession = new Set(), memberNos = new Set(), activeCopies = new Set();
  for (const t of d.titles) if (typeof t.title !== 'string' || !t.title.trim()) throw Error('Book title is missing');
  for (const m of d.members) {
    if (typeof m.name !== 'string' || !m.name.trim()) throw Error('Member name is missing');
    if (m.memberNo) { const key=String(m.memberNo).toLowerCase(); if(memberNos.has(key)) throw Error('Duplicate member number'); memberNos.add(key); }
  }
  for (const c of d.copies) {
    if (!ids.titles.has(c.titleId)) throw Error('Book copy references a missing title');
    if (!['available','on_loan','lost','damaged'].includes(c.status)) throw Error('Invalid book condition');
    if (typeof c.accessionNumber !== 'string' || !c.accessionNumber.trim()) throw Error('Missing accession number');
    const key=c.accessionNumber.toLowerCase(); if(accession.has(key)) throw Error('Duplicate accession number'); accession.add(key);
  }
  for (const l of d.loans) {
    if (!ids.copies.has(l.copyId) || !ids.members.has(l.memberId)) throw Error('Loan references missing copy/member');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(l.dueAt || '') || !isDate(l.dueAt)) throw Error('Invalid loan due date');
    if (!l.returnedAt) { if(activeCopies.has(l.copyId)) throw Error('Multiple active loans for a copy'); activeCopies.add(l.copyId); }
  }
  for (const c of d.copies) if ((c.status==='on_loan') !== activeCopies.has(c.id)) throw Error('Copy/loan status mismatch');
  for (const r of d.reservations) if (!ids.titles.has(r.titleId) || !ids.members.has(r.memberId)) throw Error('Reservation references missing title/member');
  if (d.settings !== undefined) validateSettings(d.settings);
  return d;
}
export function validateSettings(v) {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw Error('Invalid settings');
  for (const [key,min,max] of [['loanDays',1,365],['renewDays',1,365],['maxRenewals',0,20],['maxLoansPerMember',1,100],['finePerDay',0,10000]]) {
    if (!Number.isFinite(v[key]) || v[key] < min || v[key] > max || (key!=='finePerDay' && !Number.isInteger(v[key]))) throw Error(`Invalid setting: ${key}`);
  }
  return v;
}

/* ---------- The backend ---------- */
export function createBackend(storage, { sample = true } = {}) {
  const CONFIG = { ...DEFAULT_CONFIG };
  const info = { migrated: 0 };
  let data;
  const blank = () => ({ version: 3, seq: { title: 0, copy: 0, member: 0, loan: 0, res: 0 }, titles: [], copies: [], members: [], loans: [], reservations: [], settings: {...CONFIG}, activity: [] });
  const nid = (k) => ++data.seq[k];
  const stamp = () => new Date().toISOString();

  function persist() {
    validateInventory(data);
    try { storage.setItem(STORAGE_KEY, JSON.stringify(data)); }
    catch (e) { throw new HttpError(507, `Unable to save inventory: ${e.message || "Unknown file error"}`); }
  }
  // Runs fn; saves on success, rolls everything back if it throws.
  let currentAction = "change";
  function mutate(fn) {
    const snapshot = JSON.stringify(data);
    try { const r = fn(); data.activity ||= []; data.activity.push({at:stamp(),action:currentAction}); if(data.activity.length>10000) data.activity.splice(0,data.activity.length-10000); persist(); Object.assign(CONFIG, data.settings); return r; }
    catch (e) { data = JSON.parse(snapshot); throw e; }
  }

  /* ----- ids ----- */
  const accTaken = (a) => data.copies.some((c) => lower(c.accessionNumber) === lower(a));
  function nextAccession() {
    const year = new Date().getFullYear();
    for (let n = data.copies.length + 1; ; n++) {
      const a = `ACC-${year}-${String(n).padStart(4, "0")}`;
      if (!accTaken(a)) return a;
    }
  }
  const memberNoTaken = (m) => data.members.some((x) => lower(x.memberNo) === lower(m));
  function nextMemberNo() {
    for (let n = data.members.length + 1; ; n++) {
      const m = `MEM-${String(n).padStart(4, "0")}`;
      if (!memberNoTaken(m)) return m;
    }
  }

  /* ----- row inserts ----- */
  function insertTitle(v, cover) {
    const id = nid("title"), now = stamp();
    data.titles.push({ id, ...v, cover: cover || null, createdAt: now, updatedAt: now });
    return id;
  }
  function insertCopy(titleId, accessionNumber, location, status = "available") {
    const c = { id: nid("copy"), titleId, accessionNumber, location, status, createdAt: stamp() };
    data.copies.push(c);
    return c;
  }
  function insertMember(v) {
    const m = { id: nid("member"), memberNo: v.memberNo || nextMemberNo(), name: v.name, email: v.email || "", phone: v.phone || "", type: v.type || "Student", active: v.active !== false, createdAt: stamp() };
    data.members.push(m);
    return m;
  }

  /* ----- lookups and derived values ----- */
  const find = (list, id) => list.find((x) => x.id === id);
  const openLoans = () => data.loans.filter((l) => !l.returnedAt);
  const unpaidOf = (memberId) => data.loans.reduce((s, l) => s + (l.memberId === memberId && l.fine > 0 && !l.finePaid ? l.fine : 0), 0);
  const availableCount = (titleId) => data.copies.filter((c) => c.titleId === titleId && c.status === "available").length;
  const activeQueue = (titleId) => data.reservations.filter((r) => r.titleId === titleId && r.status === "active").sort((a, b) => a.id - b.id);

  // Per-title counts, computed once per request.
  function index() {
    const now = today(), byTitle = new Map(), res = new Map(), over = new Map(), copyTitle = new Map();
    for (const c of data.copies) {
      copyTitle.set(c.id, c.titleId);
      if (!byTitle.has(c.titleId)) byTitle.set(c.titleId, []);
      byTitle.get(c.titleId).push(c);
    }
    for (const r of data.reservations) if (r.status === "active") res.set(r.titleId, (res.get(r.titleId) || 0) + 1);
    for (const l of data.loans) if (!l.returnedAt && l.dueAt < now) { const t = copyTitle.get(l.copyId); over.set(t, (over.get(t) || 0) + 1); }
    return { byTitle, res, over };
  }

  function titleRow(t, ix) {
    const copies = ix.byTitle.get(t.id) || [];
    const available = copies.filter((c) => c.status === "available").length;
    const reservations = ix.res.get(t.id) || 0;
    return {
      id: t.id, title: t.title, subtitle: t.subtitle, author: t.author, isbn: t.isbn, publisher: t.publisher, year: t.year,
      edition: t.edition, language: t.language, type: t.type, subjects: splitSubjects(t.subjects), keywords: t.keywords,
      callNumber: t.callNumber, description: t.description, hasCover: !!t.cover, coverUrl: t.cover || "",
      createdAt: t.createdAt, updatedAt: t.updatedAt,
      copiesTotal: copies.length, copiesAvailable: available, copiesOnLoan: copies.filter((c) => c.status === "on_loan").length,
      reservations, overdue: ix.over.get(t.id) || 0, free: Math.max(0, available - reservations),
      _accessions: copies.map((c) => c.accessionNumber).join(" "), _locations: copies.map((c) => c.location).join(" ")
    };
  }
  const publicRow = ({ _accessions, _locations, ...row }) => row;

  function memberStats() {
    const now = today(), s = new Map();
    const get = (id) => { if (!s.has(id)) s.set(id, { activeLoans: 0, overdueLoans: 0, unpaidFines: 0, accruingFines: 0 }); return s.get(id); };
    for (const l of data.loans) {
      const m = get(l.memberId);
      if (!l.returnedAt) {
        m.activeLoans++;
        if (l.dueAt < now) { m.overdueLoans++; m.accruingFines += daysBetween(l.dueAt, now) * CONFIG.finePerDay; }
      } else if (l.fine > 0 && !l.finePaid) m.unpaidFines += l.fine;
    }
    return (id) => s.get(id) || { activeLoans: 0, overdueLoans: 0, unpaidFines: 0, accruingFines: 0 };
  }
  const memberRow = (m, stats) => ({ id: m.id, memberNo: m.memberNo, name: m.name, email: m.email, phone: m.phone, type: m.type, active: m.active, createdAt: m.createdAt, ...stats(m.id) });

  function loanRow(l, maps) {
    const copy = maps.copy.get(l.copyId), title = maps.title.get(copy.titleId), member = maps.member.get(l.memberId);
    const now = today(), days = !l.returnedAt && l.dueAt < now ? daysBetween(l.dueAt, now) : 0;
    return {
      id: l.id, borrowedAt: l.borrowedAt, dueAt: l.dueAt, returnedAt: l.returnedAt, renewals: l.renewals, fine: l.fine, finePaid: l.finePaid,
      copyId: copy.id, accessionNumber: copy.accessionNumber,
      titleId: title.id, titleName: title.title, author: title.author, hasCover: !!title.cover, coverUrl: title.cover || "", titleUpdatedAt: title.updatedAt,
      memberId: member.id, memberName: member.name, memberNo: member.memberNo,
      daysOverdue: days, accruingFine: days * CONFIG.finePerDay
    };
  }
  const loanMaps = () => ({
    copy: new Map(data.copies.map((c) => [c.id, c])),
    title: new Map(data.titles.map((t) => [t.id, t])),
    member: new Map(data.members.map((m) => [m.id, m]))
  });
  const oneLoan = (id) => loanRow(find(data.loans, id), loanMaps());
  const oneTitle = (id) => { const t = find(data.titles, id); return t && publicRow(titleRow(t, index())); };
  const oneMember = (id) => { const m = find(data.members, id); return m && memberRow(m, memberStats()); };

  /* ---------- Import / sample data ---------- */
  const cleanTitle = (t) => {
    const year = Number(t.year);
    return {
      title: String(t.title ?? "").trim().slice(0, 120), subtitle: String(t.subtitle ?? "").trim().slice(0, 120),
      author: String(t.author ?? "").trim().slice(0, 100), isbn: String(t.isbn ?? "").trim().slice(0, 30),
      publisher: String(t.publisher ?? "").trim().slice(0, 100),
      year: Number.isInteger(year) && year >= 1000 && year <= 2100 ? year : new Date().getFullYear(),
      edition: String(t.edition ?? "").trim().slice(0, 50), language: String(t.language ?? "").trim().slice(0, 50) || "English",
      type: TYPES.includes(t.type) ? t.type : "Book", subjects: splitSubjects(t.subjects ?? t.subject).join(", "),
      keywords: String(t.keywords ?? "").trim().slice(0, 300), callNumber: String(t.callNumber ?? "").trim().slice(0, 50),
      description: String(t.description ?? "").trim().slice(0, 1000)
    };
  };
  const goodCover = (c) => (typeof c === "string" && c.length < 1_000_000 && COVER_RE.test(c) ? c : null);
  const findOrCreateMember = (name) => {
    const clean = String(name).trim().slice(0, 100);
    return (data.members.find((m) => lower(m.name) === lower(clean)) || insertMember({ name: clean })).id;
  };

  function importLegacy(items, out) {
    for (const it of items) {
      if (!it || !String(it.title ?? "").trim() || !String(it.author ?? "").trim()) { out.skipped++; continue; }
      const acc = String(it.accessionNumber ?? "").trim().slice(0, 40);
      if (acc && accTaken(acc)) { out.skipped++; continue; }
      const titleId = insertTitle(cleanTitle(it), goodCover(it.cover));
      out.titles++;
      const n = Math.max(1, Math.min(200, Number(it.copies) || 1)), copies = [];
      for (let i = 0; i < n; i++) {
        let a = i === 0 && acc ? acc : acc ? `${acc}-${i + 1}` : nextAccession();
        if (accTaken(a)) a = nextAccession();
        copies.push(insertCopy(titleId, a, String(it.location ?? "").trim().slice(0, 80)));
        out.copies++;
      }
      const who = String(it.borrower ?? "").trim();
      if (it.status === "Checked Out" && who) {
        const borrowed = isDate(it.borrowDate) ? it.borrowDate : today();
        const due = isDate(it.dueDate) ? it.dueDate : addDays(borrowed, CONFIG.loanDays);
        data.loans.push({ id: nid("loan"), copyId: copies[0].id, memberId: findOrCreateMember(who), borrowedAt: borrowed, dueAt: due < borrowed ? borrowed : due, returnedAt: null, renewals: 0, fine: 0, finePaid: false });
        copies[0].status = "on_loan";
      } else if (it.status === "Reserved" && who) {
        data.reservations.push({ id: nid("res"), titleId, memberId: findOrCreateMember(who), status: "active", createdAt: stamp() });
      }
    }
  }

  function importV2(b, out) {
    for (const m of Array.isArray(b.members) ? b.members : []) {
      if (!m || !String(m.name ?? "").trim()) { out.skipped++; continue; }
      const no = String(m.memberNo ?? "").trim().slice(0, 30);
      if (no && memberNoTaken(no)) { out.skipped++; continue; }
      insertMember({ memberNo: no, name: String(m.name).trim().slice(0, 100), email: String(m.email ?? "").slice(0, 120), phone: String(m.phone ?? "").slice(0, 40), type: MEMBER_TYPES.includes(m.type) ? m.type : "Student", active: m.active !== false });
      out.members++;
    }
    for (const t of Array.isArray(b.titles) ? b.titles : []) {
      if (!t || !String(t.title ?? "").trim() || !String(t.author ?? "").trim()) { out.skipped++; continue; }
      const copies = Array.isArray(t.copies) ? t.copies : [];
      if (copies.some((c) => c && accTaken(String(c.accessionNumber ?? "")))) { out.skipped++; continue; }
      const titleId = insertTitle(cleanTitle(t), goodCover(t.cover));
      out.titles++;
      for (const c of copies) {
        const a = String(c?.accessionNumber ?? "").trim().slice(0, 40) || nextAccession();
        if (accTaken(a)) continue;
        insertCopy(titleId, a, String(c?.location ?? "").slice(0, 80), ["lost", "damaged"].includes(c?.status) ? c.status : "available");
        out.copies++;
      }
    }
  }

  function seedSample() {
    const now = today();
    importLegacy([
      { title: "Introduction to Computing", subtitle: "Explorations in Language, Logic, and Machines", author: "David Evans", isbn: "978-0986977571", accessionNumber: "ACC-2026-001", publisher: "University of Virginia", year: 2024, edition: "2nd Edition", subject: ["Computer Science", "Programming"], keywords: "algorithms computing software beginner", callNumber: "QA76.6 E93 2024", status: "Available", type: "Book", location: "Shelf A-03", copies: 3, description: "An introductory resource covering computing, programming, and problem solving." },
      { title: "Database System Concepts", author: "Abraham Silberschatz", isbn: "978-0078022159", accessionNumber: "ACC-2026-002", publisher: "McGraw-Hill", year: 2020, edition: "7th Edition", subject: ["Databases", "Information Systems"], keywords: "sql database design normalization data", callNumber: "QA76.9.D3 S55 2020", status: "Checked Out", type: "Book", location: "Shelf A-07", copies: 2, borrower: "Juan Dela Cruz", borrowDate: addDays(now, -20), dueDate: addDays(now, -6), description: "A comprehensive textbook on database design, SQL, transactions, and data management." },
      { title: "The Philippine Islands", author: "Antonio de Morga", accessionNumber: "DIG-2026-003", publisher: "Digital Collection", year: 2018, subject: ["Philippine History", "Southeast Asia"], keywords: "philippines history culture colonial", callNumber: "DS674 M67 2018", status: "Available", type: "E-book", location: "Digital Collection", copies: 1, description: "A historical work about the early colonial Philippines." },
      { title: "Fundamentals of Computer Networks", author: "Larry Peterson", isbn: "978-0123850591", accessionNumber: "ACC-2026-004", publisher: "Morgan Kaufmann", year: 2022, edition: "6th Edition", subject: ["Networking", "Technology"], keywords: "tcp ip routing network protocols", callNumber: "TK5105.5 P48 2022", status: "Reserved", type: "Book", location: "Shelf B-02", copies: 2, borrower: "Maria Santos", description: "Covers network architecture, protocols, routing, transport, and applications." }
    ], { titles: 0, copies: 0, members: 0, skipped: 0 });
    insertMember({ name: "Ana Reyes", email: "ana.reyes@example.com", type: "Faculty" });
    insertMember({ name: "Paolo Garcia", email: "paolo.garcia@example.com", type: "Student" });
  }

  /* ---------- Start up: load saved data, or migrate the old version, or add samples ---------- */
  function readLegacy() {
    for (const k of LEGACY_KEYS) {
      try { const v = JSON.parse(storage.getItem(k)); if (Array.isArray(v) && v.length) return v; } catch { /* ignore */ }
    }
    return null;
  }
  // A locked or unreadable file must never be replaced with sample records.
  const saved = storage.getItem(STORAGE_KEY);
  if (saved) { data = JSON.parse(saved); validateInventory(data); }
  if (!data || !Array.isArray(data.titles)) {
    data = blank();
    const legacy = readLegacy(), out = { titles: 0, copies: 0, members: 0, skipped: 0 };
    if (legacy) { importLegacy(legacy, out); info.migrated = out.titles; }
    else if (sample) seedSample();
    persist();
  }

  /* ---------- Routes ---------- */
  const routes = [];
  const route = (method, pattern, fn) => routes.push({ method, re: new RegExp("^" + pattern.replace(/:(\w+)/g, "(?<$1>[^/]+)") + "$"), fn });

  route("GET", "/config", () => ({ ...CONFIG, ...data.settings }));
  route("PUT", "/config", ({body}) => mutate(() => { data.settings=validateSettings({...CONFIG,...body}); return {...data.settings}; }));
  route("GET", "/activity", () => (data.activity || []).slice(-500).reverse());
  route("GET", "/report", () => ({generatedAt:stamp(), titles:data.titles, copies:data.copies, members:data.members, loans:data.loans, reservations:data.reservations}));

  route("GET", "/stats", () => {
    const ix = index(), now = today();
    let free = 0, allOut = 0, reserved = 0;
    for (const t of data.titles) {
      const row = titleRow(t, ix);
      if (row.free > 0) free++;
      if (row.copiesTotal > 0 && row.copiesAvailable === 0) allOut++;
      if (row.reservations > 0) reserved++;
    }
    const open = openLoans();
    return {
      titles: data.titles.length, titlesAvailable: free, titlesAllOut: allOut, titlesReserved: reserved,
      copies: data.copies.length, availableCopies: data.copies.filter(c => c.status === "available").length, onLoan: data.copies.filter((c) => c.status === "on_loan").length,
      overdue: open.filter((l) => l.dueAt < now).length, members: data.members.filter((m) => m.active).length,
      unpaidFines: data.loans.reduce((s, l) => s + (l.fine > 0 && !l.finePaid ? l.fine : 0), 0)
    };
  });

  /* ----- Titles ----- */
  const SEARCH = {
    all: ["title", "subtitle", "author", "isbn", "publisher", "subjects", "keywords", "callNumber", "_accessions", "_locations"],
    title: ["title", "subtitle"], author: ["author"], isbn: ["isbn"], subject: ["subjects"], keywords: ["keywords"],
    callNumber: ["callNumber"], accessionNumber: ["_accessions"]
  };
  const collator = new Intl.Collator(undefined, { sensitivity: "base", numeric: true });
  const SORTS = {
    newest: (a, b) => b.id - a.id,
    titleAsc: (a, b) => collator.compare(a.title, b.title), titleDesc: (a, b) => collator.compare(b.title, a.title),
    authorAsc: (a, b) => collator.compare(a.author, b.author),
    yearDesc: (a, b) => b.year - a.year, yearAsc: (a, b) => a.year - b.year,
    callAsc: (a, b) => collator.compare(a.callNumber, b.callNumber)
  };
  const STATUS = {
    available: (r) => r.free > 0,
    checked_out: (r) => r.copiesTotal > 0 && r.copiesAvailable === 0,
    reserved: (r) => r.reservations > 0
  };

  route("GET", "/titles", ({ query }) => {
    const { q = "", field = "all", status, type, sort = "newest" } = query;
    const cols = SEARCH[field] || SEARCH.all, terms = words(q);
    if (status && !STATUS[status]) throw bad("Unknown status filter");
    const ix = index();
    return data.titles.map((t) => titleRow(t, ix))
      .filter((r) => {
        if (terms.length) { const hay = lower(cols.map((c) => r[c] instanceof Array ? r[c].join(" ") : r[c]).join(" ")); if (!terms.every((w) => hay.includes(w))) return false; }
        if (status && !STATUS[status](r)) return false;
        return !(type && type !== "all" && r.type !== type);
      })
      .sort(SORTS[sort] || SORTS.newest)
      .map(publicRow);
  });

  route("GET", "/titles/:id", ({ p }) => {
    const title = oneTitle(p.id);
    if (!title) throw notFound("Title");
    const now = today();
    const loanOf = new Map(openLoans().map((l) => [l.copyId, l]));
    const copies = data.copies.filter((c) => c.titleId === p.id).sort((a, b) => collator.compare(a.accessionNumber, b.accessionNumber)).map((c) => {
      const l = loanOf.get(c.id), m = l && find(data.members, l.memberId);
      return { id: c.id, accessionNumber: c.accessionNumber, location: c.location, status: c.status, loanId: l?.id ?? null, dueAt: l?.dueAt ?? null, borrowedAt: l?.borrowedAt ?? null, renewals: l?.renewals ?? null, memberId: m?.id ?? null, memberName: m?.name ?? null, daysOverdue: l && l.dueAt < now ? daysBetween(l.dueAt, now) : 0 };
    });
    const queue = activeQueue(p.id).map((r, i) => { const m = find(data.members, r.memberId); return { id: r.id, memberId: m.id, memberName: m.name, memberNo: m.memberNo, createdAt: r.createdAt, position: i + 1 }; });
    const copyIds = new Set(data.copies.filter((c) => c.titleId === p.id).map((c) => c.id));
    const maps = loanMaps();
    const history = data.loans.filter((l) => copyIds.has(l.copyId)).sort((a, b) => b.id - a.id).slice(0, 15).map((l) => {
      const r = loanRow(l, maps);
      return { id: r.id, borrowedAt: r.borrowedAt, dueAt: r.dueAt, returnedAt: r.returnedAt, fine: r.fine, accessionNumber: r.accessionNumber, memberId: r.memberId, memberName: r.memberName };
    });
    return { ...title, copies, queue, history };
  });

  route("POST", "/titles", ({ body }) => mutate(() => {
    const v = parseTitle(body);
    const cover = parseCover(body.cover) ?? null;
    const n = body.copies === undefined ? 1 : int(body.copies, { name: "Copies", min: 0, max: 200 });
    const location = str(body.location, { name: "Location", max: 80 });
    const id = insertTitle(v, cover);
    for (let i = 0; i < n; i++) insertCopy(id, nextAccession(), location);
    return oneTitle(id);
  }));

  route("PUT", "/titles/:id", ({ p, body }) => mutate(() => {
    const t = find(data.titles, p.id);
    if (!t) throw notFound("Title");
    const v = parseTitle(body), cover = parseCover(body.cover);
    Object.assign(t, v, { updatedAt: stamp() });
    if (cover !== undefined) t.cover = cover;
    return oneTitle(p.id);
  }));

  route("DELETE", "/titles/:id", ({ p }) => mutate(() => {
    if (!find(data.titles, p.id)) throw notFound("Title");
    const copies = data.copies.filter((c) => c.titleId === p.id), out = copies.filter((c) => c.status === "on_loan").length;
    if (out) throw conflict(`${out} ${out === 1 ? "copy is" : "copies are"} on loan. Return them before deleting this title.`);
    const ids = new Set(copies.map((c) => c.id));
    data.loans = data.loans.filter((l) => !ids.has(l.copyId));
    data.copies = data.copies.filter((c) => c.titleId !== p.id);
    data.reservations = data.reservations.filter((r) => r.titleId !== p.id);
    data.titles = data.titles.filter((t) => t.id !== p.id);
    return null;
  }));

  /* ----- Copies ----- */
  route("POST", "/titles/:id/copies", ({ p, body }) => mutate(() => {
    if (!find(data.titles, p.id)) throw notFound("Title");
    const acc = str(body.accessionNumber, { name: "Accession number", max: 40 }) || nextAccession();
    const location = str(body.location, { name: "Location", max: 80 });
    if (accTaken(acc)) throw conflict("That accession number is already in use.");
    const c = insertCopy(p.id, acc, location);
    return { id: c.id, accessionNumber: acc, location, status: "available" };
  }));

  route("PATCH", "/copies/:id", ({ p, body }) => mutate(() => {
    const c = find(data.copies, p.id);
    if (!c) throw notFound("Copy");
    const acc = body.accessionNumber === undefined ? c.accessionNumber : str(body.accessionNumber, { name: "Accession number", max: 40, required: true });
    const location = body.location === undefined ? c.location : str(body.location, { name: "Location", max: 80 });
    let status = c.status;
    if (body.status !== undefined && body.status !== c.status) {
      if (c.status === "on_loan") throw conflict("This copy is on loan. Return it first.");
      status = oneOf(body.status, ["available", "lost", "damaged"], "Status");
    }
    if (data.copies.some((x) => x.id !== c.id && lower(x.accessionNumber) === lower(acc))) throw conflict("That accession number is already in use.");
    Object.assign(c, { accessionNumber: acc, location, status });
    return { id: c.id, accessionNumber: acc, location, status };
  }));

  route("DELETE", "/copies/:id", ({ p }) => mutate(() => {
    const c = find(data.copies, p.id);
    if (!c) throw notFound("Copy");
    if (c.status === "on_loan") throw conflict("This copy is on loan. Return it first.");
    data.loans = data.loans.filter((l) => l.copyId !== c.id);
    data.copies = data.copies.filter((x) => x.id !== c.id);
    return null;
  }));

  /* ----- Members ----- */
  route("GET", "/members", ({ query }) => {
    const terms = words(query.q, 6), stats = memberStats();
    return data.members
      .filter((m) => (query.active !== "1" || m.active) && terms.every((w) => lower([m.name, m.memberNo, m.email, m.phone].join(" ")).includes(w)))
      .sort((a, b) => collator.compare(a.name, b.name))
      .map((m) => memberRow(m, stats));
  });

  route("GET", "/members/:id", ({ p }) => {
    const member = oneMember(p.id);
    if (!member) throw notFound("Member");
    const maps = loanMaps();
    const loans = data.loans.filter((l) => l.memberId === p.id)
      .sort((a, b) => (!!a.returnedAt - !!b.returnedAt) || b.id - a.id).slice(0, 100)
      .map((l) => { const r = loanRow(l, maps); return { id: r.id, borrowedAt: r.borrowedAt, dueAt: r.dueAt, returnedAt: r.returnedAt, renewals: r.renewals, fine: r.fine, finePaid: r.finePaid, accessionNumber: r.accessionNumber, titleId: r.titleId, titleName: r.titleName, author: r.author, daysOverdue: r.daysOverdue, accruingFine: r.accruingFine }; });
    const reservations = data.reservations.filter((r) => r.memberId === p.id && r.status === "active").sort((a, b) => a.id - b.id)
      .map((r) => ({ id: r.id, titleId: r.titleId, titleName: find(data.titles, r.titleId).title, createdAt: r.createdAt }));
    return { ...member, loans, reservations };
  });

  route("POST", "/members", ({ body }) => mutate(() => {
    const v = parseMember(body);
    if (v.memberNo && memberNoTaken(v.memberNo)) throw conflict("That member number is already in use.");
    return oneMember(insertMember(v).id);
  }));

  route("PUT", "/members/:id", ({ p, body }) => mutate(() => {
    const m = find(data.members, p.id);
    if (!m) throw notFound("Member");
    const v = parseMember(body, m);
    if (data.members.some((x) => x.id !== m.id && lower(x.memberNo) === lower(v.memberNo))) throw conflict("That member number is already in use.");
    if (!v.active && m.active && openLoans().some((l) => l.memberId === m.id)) throw conflict("This member still has items on loan. Collect them before deactivating.");
    Object.assign(m, v);
    return oneMember(m.id);
  }));

  route("DELETE", "/members/:id", ({ p }) => mutate(() => {
    if (!find(data.members, p.id)) throw notFound("Member");
    if (data.loans.some((l) => l.memberId === p.id)) throw conflict("This member has loan history. Deactivate them instead to keep the records.");
    data.reservations = data.reservations.filter((r) => r.memberId !== p.id);
    data.members = data.members.filter((m) => m.id !== p.id);
    return null;
  }));

  route("POST", "/members/:id/fines/pay", ({ p }) => mutate(() => {
    if (!find(data.members, p.id)) throw notFound("Member");
    let paid = 0;
    for (const l of data.loans) if (l.memberId === p.id && l.fine > 0 && !l.finePaid) { paid += l.fine; l.finePaid = true; }
    return { paid };
  }));

  /* ----- Loans ----- */
  route("GET", "/loans", ({ query }) => {
    const { status = "active", memberId, q = "" } = query, now = today();
    if (!["active", "overdue", "returned", "all"].includes(status)) throw bad("Unknown loan status");
    const maps = loanMaps(), terms = words(q, 6);
    return data.loans
      .filter((l) => (status === "active" ? !l.returnedAt : status === "overdue" ? !l.returnedAt && l.dueAt < now : status === "returned" ? !!l.returnedAt : true))
      .filter((l) => !memberId || l.memberId === Number(memberId))
      .map((l) => loanRow(l, maps))
      .filter((r) => { const hay = lower([r.titleName, r.memberName, r.memberNo, r.accessionNumber].join(" ")); return terms.every((w) => hay.includes(w)); })
      .sort(status === "returned" ? (a, b) => b.returnedAt.localeCompare(a.returnedAt) || b.id - a.id : status === "all" ? (a, b) => b.id - a.id : (a, b) => a.dueAt.localeCompare(b.dueAt) || a.id - b.id)
      .slice(0, 500);
  });

  // Check out: pass copyId (a specific copy) or titleId (the first free copy).
  route("POST", "/loans", ({ body }) => mutate(() => {
    const memberId = int(body.memberId, { name: "Member" }), now = today();
    const dueAt = body.dueAt ? dateStr(body.dueAt, "Due date") : addDays(now, CONFIG.loanDays);
    if (dueAt < now) throw bad("Due date can't be in the past");

    const member = find(data.members, memberId);
    if (!member) throw notFound("Member");
    if (!member.active) throw conflict(`${member.name} is deactivated and can't borrow.`);
    const unpaid = unpaidOf(memberId);
    if (unpaid > 0) throw conflict(`${member.name} has unpaid fines of ${CONFIG.currency}${unpaid}. Collect payment first.`);
    const open = openLoans().filter((l) => l.memberId === memberId);
    if (open.length >= CONFIG.maxLoansPerMember) throw conflict(`${member.name} already has ${open.length} items out (limit ${CONFIG.maxLoansPerMember}).`);

    let copy;
    if (body.copyId) {
      copy = find(data.copies, Number(body.copyId));
      if (!copy) throw notFound("Copy");
      if (copy.status !== "available") throw conflict("That copy isn't available.");
    } else if (body.titleId) {
      const titleId = Number(body.titleId);
      if (!find(data.titles, titleId)) throw notFound("Title");
      copy = data.copies.filter((c) => c.titleId === titleId && c.status === "available").sort((a, b) => collator.compare(a.accessionNumber, b.accessionNumber))[0];
      if (!copy) throw conflict("No copies of this title are available.");
    } else throw bad("Choose a copy or a title");

    const titleId = copy.titleId;
    const copiesOfTitle = new Set(data.copies.filter((c) => c.titleId === titleId).map((c) => c.id));
    if (open.some((l) => copiesOfTitle.has(l.copyId))) throw conflict(`${member.name} already has a copy of this title.`);

    // Reservation queue: free copies are held for the people waiting, in order.
    const queue = activeQueue(titleId), free = availableCount(titleId), mine = queue.findIndex((r) => r.memberId === memberId);
    if (mine >= 0 ? mine >= free : queue.length >= free) throw conflict("The available copies are held for members in the reservation queue.");

    const loan = { id: nid("loan"), copyId: copy.id, memberId, borrowedAt: now, dueAt, returnedAt: null, renewals: 0, fine: 0, finePaid: false };
    data.loans.push(loan);
    copy.status = "on_loan";
    if (mine >= 0) queue[mine].status = "fulfilled";
    return oneLoan(loan.id);
  }));

  route("POST", "/loans/:id/return", ({ p }) => mutate(() => {
    const loan = find(data.loans, p.id);
    if (!loan) throw notFound("Loan");
    if (loan.returnedAt) throw conflict("This loan was already returned.");
    const now = today(), days = loan.dueAt < now ? daysBetween(loan.dueAt, now) : 0, fine = days * CONFIG.finePerDay;
    Object.assign(loan, { returnedAt: now, fine, finePaid: fine === 0 });
    const copy = find(data.copies, loan.copyId);
    if (copy.status === "on_loan") copy.status = "available";
    return { loan: oneLoan(loan.id), fine, daysOverdue: days };
  }));

  route("POST", "/loans/:id/renew", ({ p }) => mutate(() => {
    const loan = find(data.loans, p.id);
    if (!loan) throw notFound("Loan");
    if (loan.returnedAt) throw conflict("This loan was already returned.");
    if (loan.dueAt < today()) throw conflict("Overdue items can't be renewed. Return the item first.");
    if (loan.renewals >= CONFIG.maxRenewals) throw conflict(`This loan has reached the renewal limit (${CONFIG.maxRenewals}).`);
    if (activeQueue(find(data.copies, loan.copyId).titleId).length) throw conflict("Someone is waiting for this title, so it can't be renewed.");
    loan.dueAt = addDays(loan.dueAt, CONFIG.renewDays);
    loan.renewals++;
    return oneLoan(loan.id);
  }));

  /* ----- Reservations ----- */
  route("POST", "/reservations", ({ body }) => mutate(() => {
    const titleId = int(body.titleId, { name: "Title" }), memberId = int(body.memberId, { name: "Member" });
    if (!find(data.titles, titleId)) throw notFound("Title");
    const member = find(data.members, memberId);
    if (!member) throw notFound("Member");
    if (!member.active) throw conflict(`${member.name} is deactivated.`);
    const queue = activeQueue(titleId);
    if (queue.some((r) => r.memberId === memberId)) throw conflict(`${member.name} is already in the queue for this title.`);
    const copiesOfTitle = new Set(data.copies.filter((c) => c.titleId === titleId).map((c) => c.id));
    if (openLoans().some((l) => l.memberId === memberId && copiesOfTitle.has(l.copyId))) throw conflict(`${member.name} already has this title on loan.`);
    if (availableCount(titleId) > queue.length) throw conflict("A copy is available now. Check it out instead.");
    const r = { id: nid("res"), titleId, memberId, status: "active", createdAt: stamp() };
    data.reservations.push(r);
    return { id: r.id };
  }));

  route("DELETE", "/reservations/:id", ({ p }) => mutate(() => {
    const r = find(data.reservations, p.id);
    if (!r) throw notFound("Reservation");
    if (r.status !== "active") throw conflict("This reservation is no longer active.");
    r.status = "cancelled";
    return null;
  }));

  /* ----- Backup, restore, reset ----- */
  route("GET", "/export", () => ({ format: "library-catalog-full", version: 3, exportedAt: stamp(), data: JSON.parse(JSON.stringify(data)) }));

  // Merge titles/members from a backup (this app's earlier formats or the original version's records).
  route("POST", "/import", ({ body }) => mutate(() => {
    if (typeof body !== "object" || body === null) throw bad("Send a JSON backup file");
    const out = { titles: 0, copies: 0, members: 0, skipped: 0 };
    if (Array.isArray(body)) importLegacy(body, out); else importV2(body, out);
    return out;
  }));

  // Replace everything with a full backup made by Export.
  route("POST", "/restore", ({ body }) => mutate(() => {
    const d = body?.format === "library-catalog-full" && body.data;
    if (!d || !["titles", "copies", "members", "loans", "reservations"].every((k) => Array.isArray(d[k])) || !d.seq) throw bad("That isn't a full backup file");
    validateInventory(d);
    data = { ...blank(), ...d, settings: {...CONFIG,...d.settings}, activity: Array.isArray(d.activity) ? d.activity : [], version: 3 };
    return { titles: data.titles.length, members: data.members.length, loans: data.loans.length };
  }));

  route("POST", "/reset", ({ body }) => mutate(() => {
    data = blank();
    if (body?.sample) seedSample();
    return null;
  }));

  async function handle(method, url, body) {
    const [path, qs] = url.split("?");
    const query = Object.fromEntries(new URLSearchParams(qs || ""));
    for (const r of routes) {
      if (r.method !== method) continue;
      const m = r.re.exec(path);
      if (!m) continue;
      const p = Object.fromEntries(Object.entries(m.groups || {}).map(([k, v]) => [k, Number(v)]));
      currentAction = `${method} ${path}`;
      return r.fn({ p, query, body: body ?? {} });
    }
    throw notFound("Route");
  }
  if(data.settings) Object.assign(CONFIG,data.settings);
  handle.info = info;
  handle._data = () => data;   // for tests
  return handle;
}
