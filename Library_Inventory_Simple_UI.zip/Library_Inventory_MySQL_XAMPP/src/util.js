export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
export const EASE = "cubic-bezier(.2,.8,.2,1)";

export const esc = (v) => String(v ?? "").replace(/[&<>'"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[c]));

/* Dates (all local, YYYY-MM-DD, same as the server) */
import { iso, today, addDays as calendarAddDays } from './dates.js';
export { iso, today };
export const addDays = (n, from = new Date()) => calendarAddDays(iso(from), n);
export const fmtDate = (s) => {
  const d = new Date(s + "T00:00");
  return isNaN(d) ? s : d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
};

/* Server settings (loan length, fine rate, currency) filled in at startup */
export const config = { currency: "₱", loanDays: 14, finePerDay: 5 };
export const money = (n) => `${config.currency}${Number(n).toLocaleString()}`;

export function debounce(fn, ms = 150) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export const hue = (str) => { let h = 0; for (const c of String(str)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
export const initials = (name) => String(name).split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("");

const ICON = (p) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
export const TYPE_ICON = {
  "Book": ICON('<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>'),
  "E-book": ICON('<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>'),
  "DVD": ICON('<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>'),
  "Audiobook": ICON('<path d="M3 14v-2a9 9 0 0 1 18 0v2"/><path d="M21 15a2 2 0 0 1-2 2h-1v-6h1a2 2 0 0 1 2 2zM3 15a2 2 0 0 0 2 2h1v-6H5a2 2 0 0 0-2 2z"/>'),
  "Journal": ICON('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>'),
  "Other": ICON('<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3.3 7L12 12l8.7-5M12 22V12"/>')
};
export const X_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>';
export const BOOK_ICON_LG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>';

/* Book-style cover. `t` needs: title, author, type, coverUrl (a data URL or empty) */
export function coverHtml(t, mini = false) {
  const h = hue(t.title);
  const cls = mini ? "cover mini" : "cover";
  if (t.coverUrl) {
    return `<div class="${cls}" style="--h:${h}"><img src="${esc(t.coverUrl)}" alt="Cover of ${esc(t.title)}"></div>`;
  }
  return `<div class="${cls}" style="--h:${h}" aria-hidden="true"><span class="cover-type">${TYPE_ICON[t.type] || TYPE_ICON.Other}</span><span class="cover-title">${esc(t.title)}</span><span class="cover-author">${esc(t.author)}</span></div>`;
}

/* Shrinks an image file so covers stay small in the database. Resolves to a JPEG data URL. */
export function shrinkImage(file, max = 480) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("That image couldn't be read. Try another file.")); };
    img.src = url;
  });
}

/* Tiny pub/sub so views refresh when anything changes */
export const store = { stats: null };
export const emit = (name) => document.dispatchEvent(new CustomEvent(name));
export const on = (name, fn) => document.addEventListener(name, fn);
export const changed = () => emit("data-changed");
