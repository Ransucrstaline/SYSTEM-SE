import { $, $$, esc, reduced, X_ICON, BOOK_ICON_LG } from "./util.js";

/* ---------- Toast ---------- */
let toastTimer;
export function toast(message, action) {
  clearTimeout(toastTimer);
  const el = $("#toast"), btn = $("#toastAction");
  $("#toastText").textContent = message;
  btn.hidden = !action;
  btn.onclick = null;
  if (action) { btn.textContent = action.label; btn.onclick = () => { action.run(); el.classList.remove("show"); }; }
  el.classList.add("show");
  toastTimer = setTimeout(() => el.classList.remove("show"), action ? 6000 : 3200);
}

/* ---------- Small animations ---------- */
export function shake(el) {
  if (!el) return;
  el.focus?.();
  if (!reduced) el.animate([{ transform: "translateX(0)" }, { transform: "translateX(-6px)" }, { transform: "translateX(6px)" }, { transform: "translateX(0)" }], { duration: 280 });
}

export function countTo(el, to) {
  const from = Number(el.textContent) || 0;
  if (from === to || reduced) { el.textContent = to; return; }
  const t0 = performance.now(), dur = 500;
  const step = (t) => {
    const p = Math.min((t - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(from + (to - from) * e);
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

/* Segmented control with a sliding pill. Returns { move, set }. */
export function segmented(container, onChange) {
  const pill = $(".seg-pill", container);
  const move = () => {
    const a = $(".seg.active", container);
    if (!a || !a.offsetWidth) return;
    pill.style.width = a.offsetWidth + "px";
    pill.style.transform = `translateX(${a.offsetLeft}px)`;
    if (!pill.classList.contains("ready")) requestAnimationFrame(() => pill.classList.add("ready"));
  };
  const set = (value) => {
    $$(".seg", container).forEach((b) => b.classList.toggle("active", b.dataset.value === value));
    move();
  };
  container.addEventListener("click", (e) => {
    const b = e.target.closest(".seg");
    if (!b || b.classList.contains("active")) return;
    set(b.dataset.value);
    onChange?.(b.dataset.value);
  });
  addEventListener("resize", move);
  document.fonts?.ready.then(move);
  move();
  return { move, set };
}

/* ---------- Layers: animated open/close, focus handling ---------- */
export function openLayer(el, focusSel) {
  clearTimeout(el._t);
  el._last = document.activeElement;
  el.hidden = false;
  document.body.classList.add("locked");
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("open")));
  setTimeout(() => (focusSel ? $(focusSel, el) : $("[data-autofocus],input,select,textarea,button", el))?.focus({ preventScroll: true }), 80);
}

export function closeLayer(el) {
  if (el.hidden || !el.classList.contains("open")) return;
  el.classList.remove("open");
  el._t = setTimeout(() => {
    el.hidden = true;
    if (el.dataset.temp) el.remove();
    if (!$$(".layer.open").length) document.body.classList.remove("locked");
  }, reduced ? 0 : 220);
  el._onClose?.();
  el._onClose = null;
  el._last?.focus?.({ preventScroll: true });
}

function makeLayer(kind, inner) {
  const el = document.createElement("div");
  el.className = `layer layer-${kind}`;
  el.dataset.temp = "1";
  el.hidden = true;
  el.innerHTML = `<div class="scrim" data-close></div>${inner}`;
  el.addEventListener("click", (e) => { if (e.target.closest("[data-close]")) closeLayer(el); });
  document.body.appendChild(el);
  return el;
}

export function initLayers() {
  $("#drawer").addEventListener("click", (e) => { if (e.target.closest("[data-close]")) closeLayer($("#drawer")); });
  document.addEventListener("keydown", (e) => {
    const top = $$(".layer.open").pop();
    if (e.key === "Escape" && top) { closeLayer(top); return; }
    if (e.key === "Tab" && top) {   // keep focus inside the open layer
      const f = $$('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])', top)
        .filter((n) => !n.disabled && !n.closest("[inert]") && n.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
}

/* ---------- Side drawer (shared by titles and members) ---------- */
const drawer = () => $("#drawer");
export const drawerContent = () => $("#drawerContent");
export function openDrawer(html) {
  drawerContent().innerHTML = html;
  openLayer(drawer(), ".drawer-close");
}
export function setDrawer(html) {   // update in place, keep scroll position
  const box = $(".drawer", drawer()), y = box.scrollTop;
  drawerContent().innerHTML = html;
  box.scrollTop = y;
}
export const closeDrawer = () => closeLayer(drawer());
export const drawerIsOpen = () => drawer().classList.contains("open");

/* ---------- Form dialog built from a field list ---------- */
function fieldHtml(f, values) {
  const val = values[f.name] ?? f.value ?? "";
  const attrs = `name="${f.name}"${f.required ? " required" : ""}${f.maxlength ? ` maxlength="${f.maxlength}"` : ""}${f.min != null ? ` min="${f.min}"` : ""}${f.max != null ? ` max="${f.max}"` : ""}${f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : ""}${f.autofocus ? " data-autofocus" : ""}`;
  let control;
  if (f.type === "select") {
    control = `<select ${attrs}>${f.options.map((o) => `<option value="${esc(o.value)}"${String(o.value) === String(val) ? " selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`;
  } else if (f.type === "textarea") {
    control = `<textarea ${attrs} rows="${f.rows || 4}">${esc(val)}</textarea>`;
  } else if (f.type === "file") {
    control = `<div class="image-upload"><input type="file" ${attrs} accept="image/png,image/jpeg,image/webp,image/gif" class="image-upload-input" id="upload-${f.name}"><label for="upload-${f.name}" class="image-upload-button">＋ Choose book picture</label><div class="image-upload-preview" aria-live="polite"><span class="image-upload-placeholder">📖 No picture selected</span></div><button type="button" class="image-upload-clear" hidden>Remove picture</button></div>`;
  } else {
    control = `<input type="${f.type || "text"}" ${attrs} value="${esc(val)}">`;
  }
  return `<label${f.span ? ` class="span-${f.span}"` : ""}>${esc(f.label)}${f.hint ? `<small>${esc(f.hint)}</small>` : ""}${control}</label>`;
}

/**
 * formDialog({ title, fields, values, note, submitLabel, narrow, secondary, onSubmit })
 * fields: [{ group: "Basics" }, { name, label, type, required, span, options, ... }]
 * onSubmit(data) may throw (message is shown in the dialog) or return false to stay open.
 * secondary: [{ label, danger, run }] extra buttons on the left of the footer.
 */
export function formDialog({ title, fields = [], values = {}, note = "", submitLabel = "Save", narrow = false, secondary = [], onSubmit, onClose }) {
  let body = "", open = false;
  for (const f of fields) {
    if (f.group) { if (open) body += "</div>"; body += `<h3 class="group-title">${esc(f.group)}</h3><div class="fields">`; open = true; continue; }
    if (!open) { body += '<div class="fields">'; open = true; }
    body += fieldHtml(f, values);
  }
  if (open) body += "</div>";
  if (note) body += `<p class="form-note">${esc(note)}</p>`;

  const left = secondary.length ? `<div class="foot-left">${secondary.map((s, i) => `<button class="btn${s.danger ? " btn-danger" : ""}" type="button" data-sec="${i}">${esc(s.label)}</button>`).join("")}</div>` : "";
  const el = makeLayer("center", `
    <section class="sheet${narrow ? " narrow" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="sheet-head"><h2>${esc(title)}</h2><button class="icon-btn" type="button" data-close aria-label="Close">${X_ICON}</button></div>
      <form novalidate>
        <div class="form-body">${body}</div>
        <div class="sheet-foot">${left}<p class="form-error" role="alert"></p><button class="btn" type="button" data-close>Cancel</button><button class="btn btn-primary" type="submit">${esc(submitLabel)}</button></div>
      </form>
    </section>`);
  el._onClose = onClose;
  el.querySelectorAll(".image-upload").forEach((widget) => {
    const input = widget.querySelector("input"), preview = widget.querySelector(".image-upload-preview");
    const clear = widget.querySelector(".image-upload-clear");
    let objectUrl;
    const reset = () => { if (objectUrl) URL.revokeObjectURL(objectUrl); objectUrl = null; preview.innerHTML = '<span class="image-upload-placeholder">📖 No picture selected</span>'; clear.hidden = true; };
    input.addEventListener("change", () => {
      reset(); const file = input.files?.[0]; if (!file) return;
      if (!file.type.startsWith("image/")) { input.value = ""; return; }
      objectUrl = URL.createObjectURL(file);
      const img = document.createElement("img"); img.src = objectUrl; img.alt = "Selected book cover preview";
      preview.replaceChildren(img); clear.hidden = false;
    });
    clear.addEventListener("click", () => { input.value = ""; reset(); });
    el.addEventListener("transitionend", () => { if (el.hidden && objectUrl) URL.revokeObjectURL(objectUrl); });
  });

  const form = $("form", el), err = $(".form-error", el), submit = $("button[type=submit]", el);
  const fail = (msg) => { err.textContent = msg; shake(submit); };

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!form.checkValidity()) { form.classList.add("validated"); form.querySelector(":invalid")?.focus(); return; }
    submit.disabled = true; err.textContent = "";
    const data = {};
    new FormData(form).forEach((v, k) => { data[k] = v; });
    try {
      const keep = await onSubmit(data);
      if (keep !== false) closeLayer(el);
    } catch (ex) { fail(ex.message); }
    finally { submit.disabled = false; }
  });

  $$("[data-sec]", el).forEach((b) => b.addEventListener("click", async () => {
    const s = secondary[Number(b.dataset.sec)];
    b.disabled = true; err.textContent = "";
    try { if ((await s.run()) !== false) closeLayer(el); }
    catch (ex) { fail(ex.message); }
    finally { b.disabled = false; }
  }));

  openLayer(el, "[data-autofocus]");
  return el;
}

/* Yes/no question. Resolves to true or false. */
export function confirmDialog({ title, message, confirmLabel = "Confirm", danger = false }) {
  return new Promise((resolve) => {
    let answered = false;
    const el = formDialog({
      title, note: message, narrow: true, submitLabel: confirmLabel,
      onSubmit: () => { answered = true; resolve(true); },
      onClose: () => { if (!answered) resolve(false); }
    });
    if (danger) $("button[type=submit]", el).classList.replace("btn-primary", "btn-danger");
  });
}

/* Open the drawer, or swap its content if it is already open. */
export function showDrawer(html, keepScroll = false) {
  if (drawerIsOpen()) {
    const box = $(".drawer", drawer()), y = box.scrollTop;
    drawerContent().innerHTML = html;
    box.scrollTop = keepScroll ? y : 0;
  } else openDrawer(html);
}

/* Fill an empty-state block (or hide it). */
export function setEmpty(el, show, { title = "", text = "", label = "", run } = {}) {
  el.hidden = !show;
  if (!show) return;
  el.innerHTML = `${BOOK_ICON_LG}<h2>${esc(title)}</h2><p>${esc(text)}</p>${label ? `<button class="btn" type="button">${esc(label)}</button>` : ""}`;
  const b = $("button", el);
  if (b) b.onclick = run;
}
