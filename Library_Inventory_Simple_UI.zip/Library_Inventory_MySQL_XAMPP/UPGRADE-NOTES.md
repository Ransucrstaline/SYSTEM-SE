# Library Inventory 3.1 — Offline desktop edition

## Run on Windows (VS Code terminal)
1. Install Node.js LTS.
2. Open this extracted project folder.
3. Run `npm install`, then `npm start`.
4. On first launch, create an administrator password of at least 8 characters. **Remember it**: no recovery bypass is included.
5. Records save automatically to `inventory.json` under the Electron user-data `library-records` folder. Password salt/hash are stored separately in `admin-auth.json`. No SQL server or internet is required.

## New features
- Dashboard: counts and latest recorded actions.
- Password gate: first-run administrator setup, sign in/out, salted scrypt password hash. Single administrator account only; not role-based.
- Reports: date-filtered borrowing history and CSV download, plus existing printable inventory report.
- Barcode: USB keyboard-style scanner / typed accession number lookup, with jump to catalog. This is not camera scanning or barcode label generation.
- Backups: existing verified restore snapshots, previous snapshot, up to 30 daily snapshots, JSON export/import.
- Existing catalog, member, circulation, reservations, renewals, fines and settings remain.

## Important
- Use **Electron**, not opening `index.html` in a browser.
- Back up your exported JSON files to a USB drive or another safe location. Automatic snapshots are stored on the same computer and are not protection against disk failure.
- To reset a forgotten administrator password, contact a trusted technical administrator; do not delete inventory records.
- The administrator gate protects normal app use; it does not encrypt inventory files or protect against a person with access to the Windows user account.
- Date filters use the borrowing date.
