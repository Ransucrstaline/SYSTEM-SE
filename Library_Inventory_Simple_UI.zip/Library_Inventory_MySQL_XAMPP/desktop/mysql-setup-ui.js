const fields=['host','port','user','password','database'];
const params=new URLSearchParams(location.search);
const settings=JSON.parse(params.get('settings'));
for(const key of fields)document.getElementById(key).value=settings[key];
const status=document.getElementById('status'),button=document.getElementById('connect');
status.textContent=params.get('error');
document.getElementById('form').addEventListener('submit',async event=>{
 event.preventDefault();button.disabled=true;status.textContent='Testing connection…';
 try{const config=Object.fromEntries(fields.map(key=>[key,document.getElementById(key).value]));
 const result=await window.mysqlSetup.test(config);status.textContent=result.message;if(!result.ok)button.disabled=false;
 }catch{status.textContent='Could not complete the test. Close this window and restart the app.';button.disabled=false;}
});

document.getElementById('reset').addEventListener('click',()=>{
 if(button.disabled)return;
 for(const [key,value] of Object.entries({host:'127.0.0.1',port:3307,user:'',password:'',database:'library_inventory'}))document.getElementById(key).value=value;
 status.textContent='Enter an existing MySQL account. To create a new account, follow NEW_MYSQL_ACCOUNT.txt. Settings are saved only after a successful test.';
 document.getElementById('user').focus();
});
