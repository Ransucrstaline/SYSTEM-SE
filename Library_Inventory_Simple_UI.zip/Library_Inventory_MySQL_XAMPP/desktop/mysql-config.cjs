const fs = require('node:fs');
const path = require('node:path');
const defaults = {host:'127.0.0.1',port:3307,user:'',password:'',database:'library_inventory'};
function normalize(value) {
 if (!value || typeof value !== 'object') throw Error('Connection settings must be an object');
 const c = {...defaults,...value};
 c.port=Number(c.port);
 if(typeof c.host!=='string'||!c.host.trim())throw Error('Enter a host');
 if(typeof c.user!=='string'||!c.user.trim())throw Error('Enter a username');
 if(!Number.isInteger(c.port)||c.port<1||c.port>65535)throw Error('Port must be 1–65535');
 if(typeof c.password!=='string')throw Error('Password must be text');
 if(typeof c.database!=='string'||!/^[a-zA-Z0-9_]+$/.test(c.database))throw Error('Database name may contain only letters, numbers and underscores');
 return {host:c.host.trim(),port:c.port,user:c.user.trim(),password:c.password,database:c.database};
}
function configPath(directory){return path.join(directory,'mysql-config.json');}
function loadConfig(directory){const saved=configPath(directory);return normalize(JSON.parse(fs.readFileSync(fs.existsSync(saved)?saved:path.join(__dirname,'..','mysql-config.json'),'utf8').replace(/^\uFEFF/,'')));}
function connectionError(error,config){
 const target=config?`${config.host}:${config.port} (user: ${config.user})`:'the configured server';
 let advice='Check the database settings and try again.';
 if(error.code==='ER_ACCESS_DENIED_ERROR')advice='The server rejected this username/password. Use the credentials for this server. An empty password works only if that account has no password.';
 else if(['ECONNREFUSED','ETIMEDOUT','EHOSTUNREACH','ENOTFOUND'].includes(error.code))advice='Start MySQL in XAMPP and enter the exact port shown in XAMPP. Check the host if connecting to another computer.';
 else if(/caching_sha2_password|authentication plugin/i.test(error.message))advice='Authentication compatibility error. This app uses mysql2 directly; it does not need the XAMPP command-line DLL. Verify that this is the intended MySQL server and that dependencies are installed.';
 else if(['ER_DBACCESS_DENIED_ERROR','ER_TABLEACCESS_DENIED_ERROR'].includes(error.code))advice='This account needs permission to create/use the selected database and its tables.';
 const result=Error(`Cannot open MySQL at ${target}.\n${advice}\nDatabase error: ${error.code||'ERROR'}`);
 result.code=error.code;return result;
}
module.exports={defaults,normalize,loadConfig,configPath,connectionError};
