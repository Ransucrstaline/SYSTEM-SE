const fs = require('node:fs');
const path = require('node:path');
const initSqlJs = require('sql.js');
const collections = ['titles','copies','members','loans','reservations','activity'];
const quote = name => '"' + name.replaceAll('"','""') + '"';
// Each record has its own SQL row and each property its own column. JSON scalar
// encoding preserves null, booleans, numbers and future structured fields exactly.
async function openDatabase(directory, validate, atomicWrite) {
 const SQL = await initSqlJs({locateFile:file=>require.resolve('sql.js/dist/'+file)});
 const file=path.join(directory,'library.sqlite');
 const existed=fs.existsSync(file);
 let db=new SQL.Database(existed?fs.readFileSync(file):undefined);
 db.run('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
 for(const table of collections)db.run(`CREATE TABLE IF NOT EXISTS ${table} (id INTEGER PRIMARY KEY)`);
 const flush=()=>atomicWrite(file,Buffer.from(db.export()));
 const get=key=>{const s=db.prepare('SELECT value FROM metadata WHERE key=?');try{s.bind([key]);return s.step()?JSON.parse(s.get()[0]):null;}finally{s.free();}};
 const put=(key,value)=>db.run('INSERT OR REPLACE INTO metadata VALUES (?,?)',[key,JSON.stringify(value)]);
 function commit(fn){const before=db.export();try{db.run('BEGIN');fn();db.run('COMMIT');flush();}catch(e){db.close();db=new SQL.Database(before);throw e;}}
 function readInventory(){const meta=get('inventory');if(!meta)return null;const data={...meta};for(const table of collections){const rows=db.exec(`SELECT * FROM ${table} ORDER BY id`)[0];data[table]=rows?rows.values.map(row=>Object.fromEntries(rows.columns.flatMap((key,i)=>key==='id'?(table==='activity'?[]:[[key,row[i]]]):row[i]===null?[]:[[key,JSON.parse(row[i])]]))):[];}return JSON.stringify(data);}
 function writeInventory(raw,backup=true){const data=validate(raw);if(backup&&get('inventory'))snapshot();commit(()=>{for(const table of collections){const records=data[table]||[];db.run(`DELETE FROM ${table}`);const columns=new Set(db.exec(`PRAGMA table_info(${table})`)[0].values.map(r=>r[1]));for(const record of records)for(const key of Object.keys(record))if(key!=='id'&&!columns.has(key)){db.run(`ALTER TABLE ${table} ADD COLUMN ${quote(key)} TEXT`);columns.add(key);}records.forEach((record,index)=>{const fields=Object.keys(record).filter(k=>k!=='id');db.run(`INSERT INTO ${table} (id${fields.map(k=>','+quote(k)).join('')}) VALUES (?${fields.map(()=>',?').join('')})`,[table==='activity'?index+1:record.id,...fields.map(k=>JSON.stringify(record[k]))]);});}put('inventory',Object.fromEntries(Object.entries(data).filter(([key])=>!collections.includes(key))));});}
 function snapshot(){const dir=path.join(directory,'backups');fs.mkdirSync(dir,{recursive:true});const bytes=Buffer.from(db.export());atomicWrite(path.join(dir,'previous.sqlite'),bytes);const day=new Date().toISOString().slice(0,10);const daily=path.join(dir,`inventory-${day}.sqlite`);if(!fs.existsSync(daily))atomicWrite(daily,bytes);const names=fs.readdirSync(dir).filter(n=>/^inventory-\d{4}-\d{2}-\d{2}\.sqlite$/.test(n)).sort();for(const name of names.slice(0,-30))fs.unlinkSync(path.join(dir,name));}
 function backupRaw(name){if(!/^(previous|inventory-\d{4}-\d{2}-\d{2})\.(sqlite|json)$/.test(name))throw Error('Invalid backup name');const bytes=fs.readFileSync(path.join(directory,'backups',name));if(name.endsWith('.json')){validate(bytes.toString());return bytes.toString();}const other=new SQL.Database(bytes);try{const result=other.exec("SELECT value FROM metadata WHERE key='inventory'")[0];if(!result)throw Error('Missing inventory');const data=JSON.parse(result.values[0][0]);for(const table of collections){const rows=other.exec(`SELECT * FROM ${table} ORDER BY id`)[0];data[table]=rows?rows.values.map(row=>Object.fromEntries(rows.columns.flatMap((key,i)=>key==='id'?(table==='activity'?[]:[[key,row[i]]]):row[i]===null?[]:[[key,JSON.parse(row[i])]]))):[];}const raw=JSON.stringify(data);validate(raw);return raw;}finally{other.close();}}
 try{const legacy=path.join(directory,'inventory.json');const auth=path.join(directory,'admin-auth.json');if(!get('inventory')&&fs.existsSync(legacy))writeInventory(fs.readFileSync(legacy,'utf8'),false);if(!get('account')&&fs.existsSync(auth))commit(()=>put('account',JSON.parse(fs.readFileSync(auth,'utf8'))));if(!existed)flush();for(const old of [legacy,auth])if(fs.existsSync(old))fs.renameSync(old,old+'.migrated');}catch(e){db.close();throw e;}
 return {readInventory,writeInventory,getAccount:()=>get('account'),setAccount:value=>commit(()=>put('account',value)),listBackups:()=>{const dir=path.join(directory,'backups');return fs.existsSync(dir)?fs.readdirSync(dir).filter(n=>/^(previous|inventory-\d{4}-\d{2}-\d{2})\.(sqlite|json)$/.test(n)).map(name=>{try{backupRaw(name);return{name,valid:true};}catch(e){return{name,valid:false,error:e.message};}}):[];},restoreBackup:name=>writeInventory(backupRaw(name)),close:()=>db.close()};
}
module.exports={openDatabase};
