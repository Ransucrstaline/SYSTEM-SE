const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { pathToFileURL } = require('node:url');
const { updateAccount } = require('./account.cjs');
let nextAccountAttempt=0;
let dataDir;
let database;
let configuringDatabase=false;
let mainWindow=null;
app.disableHardwareAcceleration();
function startupError(error){
 const message=error?.stack||String(error);
 console.error(message);
 try{fs.appendFileSync(path.join(app.getPath("userData"),"startup-error.log"),new Date().toISOString()+"\n"+message+"\n");}catch{}
 dialog.showErrorBox("Library Inventory could not start",message);
}
process.on("uncaughtException",startupError);
process.on("unhandledRejection",startupError);
let authenticated=false;
let phone=null;let phoneQueue=Promise.resolve();let phoneId=0;const pendingPhone=new Map();

function hashPassword(password,salt){return crypto.scryptSync(password,salt,64).toString("hex");}
async function authState(){return {setupRequired:!(await database.getAccount()),authenticated};}
async function verifyPassword(password){const d=await database.getAccount();const expected=Buffer.from(d.hash,"hex");const actual=Buffer.from(hashPassword(password,d.salt),"hex");return expected.length===actual.length&&crypto.timingSafeEqual(expected,actual);}

const hasLock = app.requestSingleInstanceLock();
if (!hasLock) app.quit();
else app.on('second-instance',()=>{ const w=BrowserWindow.getAllWindows()[0]; if(w){if(w.isMinimized())w.restore();w.focus();} });
const key = 'libraryCatalogDB_v3';
function atomicWrite(file, content) {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  const temp = file + '.' + process.pid + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
  try {
    const fd = fs.openSync(temp, 'wx', 0o600);
    try { fs.writeFileSync(fd, content, 'utf8'); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(temp, file);
  } finally { if (fs.existsSync(temp)) fs.unlinkSync(temp); }
}
function validateRaw(raw) {
  const data=JSON.parse(raw);
  if (!data || typeof data!=='object' || !Array.isArray(data.titles) || !Array.isArray(data.copies) || !Array.isArray(data.members) || !Array.isArray(data.loans) || !Array.isArray(data.reservations) || !data.seq) throw Error('Invalid inventory structure');
  const names=['titles','copies','members','loans','reservations'];
  for(const n of names) { const ids=new Set(); for(const x of data[n]) {if(!x || !Number.isSafeInteger(x.id) || x.id<1 || ids.has(x.id)) throw Error('Invalid or duplicate '+n+' ID'); ids.add(x.id);} }
  const titles=new Set(data.titles.map(x=>x.id)), copies=new Set(data.copies.map(x=>x.id)), members=new Set(data.members.map(x=>x.id));
  const acc=new Set(), active=new Set();
  for(const c of data.copies){if(!titles.has(c.titleId)||!['available','on_loan','lost','damaged'].includes(c.status)||typeof c.accessionNumber!=='string')throw Error('Invalid copy'); const a=c.accessionNumber.toLowerCase();if(acc.has(a))throw Error('Duplicate accession');acc.add(a);}
  for(const l of data.loans){if(!copies.has(l.copyId)||!members.has(l.memberId))throw Error('Invalid loan reference');if(!l.returnedAt){if(active.has(l.copyId))throw Error('Duplicate active loan');active.add(l.copyId);}}
  for(const c of data.copies)if((c.status==='on_loan')!==active.has(c.id))throw Error('Loan status mismatch');
  for(const r of data.reservations)if(!titles.has(r.titleId)||!members.has(r.memberId))throw Error('Invalid reservation');
  for(const [k,n] of Object.entries({title:'titles',copy:'copies',member:'members',loan:'loans',res:'reservations'}))if(!Number.isSafeInteger(data.seq[k])||data.seq[k]<Math.max(0,...data[n].map(x=>x.id)))throw Error('Invalid sequence');
  return data;
}
async function save(raw) { await database.writeInventory(raw); }
if (hasLock) app.whenReady().then(async()=>{
  dataDir=path.join(app.getPath('userData'),'library-records');
  fs.mkdirSync(dataDir,{recursive:true});
  const resetMysql=process.argv.includes('--reset-mysql');
  if(resetMysql){
    // Only the app connection settings are cleared; inventory and accounts stay intact.
    const {defaults,configPath}=require('./mysql-config.cjs');
    atomicWrite(configPath(dataDir),JSON.stringify({...defaults,user:'',password:''},null,2)+'\n');
  }
  if(resetMysql || process.argv.includes('--configure-mysql')){
    configuringDatabase=true;
    const saved=await require('./mysql-setup.cjs').showSetup(dataDir,Error('Enter the connection settings for your MySQL server.'),atomicWrite);
    configuringDatabase=false;
    if(!saved){app.quit();return;}
  }
  while(!database){
    try{database=await require('./database.cjs').openDatabase(dataDir,validateRaw,atomicWrite);}
    catch(error){
      configuringDatabase=true;
      const saved=await require('./mysql-setup.cjs').showSetup(dataDir,error,atomicWrite);
      configuringDatabase=false;
      if(!saved){app.quit();return;}
    }
  }
  ipcMain.on('library-storage',async(event, {operation,key:requested,value})=>{
    try {
      if(!authenticated) throw Error('Please log in first');
      if(requested!==key) throw Error('Unsupported storage key');
      if(operation==='get') {
        event.returnValue={ok:true,value:await database.readInventory()};
      } else if(operation==='set') { await save(value); event.returnValue={ok:true}; }
      else if(operation==='remove') { throw Error('Deleting inventory directly is disabled'); }
      else throw Error('Unsupported operation');
    } catch(e) { event.returnValue={ok:false,error:e.message}; }
  });
  ipcMain.handle('library-account',async(_e,action,details)=>{
    if(Date.now()<nextAccountAttempt)throw Error('Please wait a moment before trying again');
    nextAccountAttempt=Date.now()+1500;
    const record=await database.getAccount();
    const updated=updateAccount(record,action,details||{},authenticated);
    await database.setAccount(updated.record);
    if(action==='reset')authenticated=true;
    return updated.result;
  });
  ipcMain.handle('library-auth-state',()=>authState());
  ipcMain.handle('library-auth',async(_e,action,password)=>{
    if(action==='logout'){if(phone){phone.server.close();phone=null;}authenticated=false;return authState();}
    if(typeof password!=='string'||password.length<8||password.length>256)throw Error('Password must be 8–256 characters');
    if(action==='setup'){
      if(!!(await database.getAccount()))throw Error('Administrator already configured');
      const salt=crypto.randomBytes(32).toString('hex');
      await database.setAccount({version:1,salt,hash:hashPassword(password,salt)});
      authenticated=true;return authState();
    }
    if(action==='login'){
      if(!(await database.getAccount()))throw Error('Set up an administrator first');
      if(!(await verifyPassword(password)))throw Error('Incorrect password');
      authenticated=true;return authState();
    }
    throw Error('Unknown authentication action');
  });
  ipcMain.handle('library-data-folder',()=>{if(!authenticated)throw Error('Please log in');return dataDir;});
  ipcMain.handle('library-backups',()=>{
    if(!authenticated)throw Error('Please log in');
    return database.listBackups();
  });
  ipcMain.handle('library-restore-backup',async(_e,name)=>{
    if(!authenticated)throw Error('Please log in');
    await database.restoreBackup(name);return true;
  });
  ipcMain.on('phone-result',(event,result)=>{const item=pendingPhone.get(result.id);if(item&&event.sender===item.sender){pendingPhone.delete(result.id);clearTimeout(item.timer);result.error?item.reject(Error(result.error)):item.resolve(result.value);}});
  ipcMain.handle('phone-toggle',async()=>{
    if(!authenticated)throw Error('Sign in first');
    if(phone){phone.server.close();phone=null;return {urls:[]};}
    phone=await require('./phone.cjs').startPhone({tlsDirectory:path.join(dataDir,'phone-certificates'),root:path.join(__dirname,'..'),allowed:()=>authenticated&&!!phone,request:(method,route,body)=>{
      const job=()=>new Promise((resolve,reject)=>{const sender=BrowserWindow.getAllWindows()[0]?.webContents;if(!sender)return reject(Error('Desktop closed'));const id=++phoneId;const timer=setTimeout(()=>{pendingPhone.delete(id);reject(Error('Desktop did not respond'));},20000);pendingPhone.set(id,{resolve,reject,sender,timer});sender.send('phone-request',{id,method,route,body});});
      const result=phoneQueue.then(job);phoneQueue=result.catch(()=>{});return result;
    }});return {urls:phone.urls,connections:phone.connections,port:phone.port};
  });
  const win=mainWindow=new BrowserWindow({width:1250,height:850,minWidth:900,minHeight:600,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:false}});
  win.on('closed',()=>{mainWindow=null;});
  win.webContents.on('render-process-gone',(_event,details)=>startupError(Error('The interface stopped: '+details.reason)));
  win.webContents.on('preload-error',(_event,_file,error)=>startupError(error));
  win.loadFile(path.join(__dirname,'../index.html')).catch(startupError);
  win.webContents.setWindowOpenHandler(({url})=>({action:url==='about:blank'?'allow':'deny'}));
}).catch(startupError);
app.on('before-quit',()=>{database?.close();if(phone){phone.server.close();phone=null;}});
app.on('window-all-closed',()=>{if(!configuringDatabase)app.quit();});
