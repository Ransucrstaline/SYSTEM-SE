const crypto = require('node:crypto');
const hash = (value,salt) => crypto.scryptSync(value,salt,64).toString('hex');
function matches(value,salt,expected){if(typeof value!=='string'||typeof salt!=='string'||typeof expected!=='string')return false;const a=Buffer.from(hash(value,salt),'hex'),b=Buffer.from(expected,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b);}
function passwordRecord(password){if(typeof password!=='string'||password.length<8||password.length>256)throw Error('Password must be 8–256 characters');const salt=crypto.randomBytes(32).toString('hex');return {salt,hash:hash(password,salt)};}
function updateAccount(record,action,details,authenticated){
  if(!record)throw Error('Set up an administrator first');
  if(action==='reset'){
    const key=String(details.key||'').trim().toUpperCase();
    if(key.length>100||!matches(key,record.recoverySalt,record.recoveryHash))throw Error('Invalid recovery key. Use the key generated in Settings.');
    const next={...record,...passwordRecord(details.password)};
    delete next.recoverySalt;delete next.recoveryHash;
    return {record:next,result:{reset:true}};
  }
  if(!authenticated)throw Error('Please log in first');
  if(typeof details.current!=='string'||details.current.length>256||!matches(details.current,record.salt,record.hash))throw Error('Incorrect current password');
  if(action==='change')return {record:{...record,...passwordRecord(details.password)},result:{changed:true}};
  if(action==='recovery'){
    const recoveryKey=crypto.randomBytes(24).toString('hex').toUpperCase().match(/.{1,8}/g).join('-');
    const recoverySalt=crypto.randomBytes(32).toString('hex');
    return {record:{...record,recoverySalt,recoveryHash:hash(recoveryKey,recoverySalt)},result:{recoveryKey}};
  }
  throw Error('Unknown account action');
}
module.exports={updateAccount,matches,passwordRecord};
