const fs = require('node:fs');
const path = require('node:path');
const mysql = require('mysql2/promise');
const {loadConfig,normalize,connectionError}=require('./mysql-config.cjs');
const tables=['titles','copies','members','loans','reservations','activity'];
async function openDatabase(directory,validate,atomicWrite,override){
 const config=override?normalize(override):loadConfig(directory);
 if(!/^[a-zA-Z0-9_]+$/.test(config.database))throw Error('Invalid database name');
 let connection;try{connection=await mysql.createConnection({...config, database:undefined,connectTimeout:10000});}catch(e){throw connectionError(e,config);}
 try{
 await connection.query(`CREATE DATABASE IF NOT EXISTS \`${config.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
 await connection.query(`USE \`${config.database}\``);
 await connection.query('CREATE TABLE IF NOT EXISTS metadata (`key` VARCHAR(80) PRIMARY KEY, value LONGTEXT NOT NULL) ENGINE=InnoDB');
 for(const t of tables)await connection.query(`CREATE TABLE IF NOT EXISTS ${t} (id BIGINT PRIMARY KEY, record LONGTEXT NOT NULL) ENGINE=InnoDB`);
 await connection.query('CREATE TABLE IF NOT EXISTS inventory_backups (name VARCHAR(80) PRIMARY KEY, inventory LONGTEXT NOT NULL) ENGINE=InnoDB');
 let queue=Promise.resolve();
 const serial=fn=>{const job=queue.then(fn);queue=job.catch(()=>{});return job;};
 const get=async key=>{const [rows]=await connection.execute('SELECT value FROM metadata WHERE `key`=?',[key]);return rows.length?JSON.parse(rows[0].value):null;};
 const put=async(key,value)=>connection.execute('INSERT INTO metadata (`key`,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[key,JSON.stringify(value)]);
 async function read(){const data=await get('inventory');if(!data)return null;for(const t of tables){const [rows]=await connection.query(`SELECT record FROM ${t} ORDER BY id`);data[t]=rows.map(r=>JSON.parse(r.record));}return JSON.stringify(data);}
 async function transaction(fn){await connection.beginTransaction();try{await fn();await connection.commit();}catch(e){await connection.rollback();throw e;}}
 async function write(raw){const data=validate(raw);await transaction(async()=>{
 const before=await read();if(before){for(const name of ['previous.mysql','inventory-'+new Date().toISOString().slice(0,10)+'.mysql'])await connection.execute('INSERT INTO inventory_backups (name,inventory) VALUES (?,?) ON DUPLICATE KEY UPDATE inventory=IF(name=\'previous.mysql\',VALUES(inventory),inventory)',[name,before]);
 const [old]=await connection.query("SELECT name FROM inventory_backups WHERE name <> 'previous.mysql' ORDER BY name DESC");for(const row of old.slice(30))await connection.execute('DELETE FROM inventory_backups WHERE name=?',[row.name]);}
 for(const t of tables){await connection.query(`DELETE FROM ${t}`);for(const [index,r] of (data[t]||[]).entries())await connection.execute(`INSERT INTO ${t} (id,record) VALUES (?,?)`,[t==='activity'?index+1:r.id,JSON.stringify(r)]);}
 await put('inventory',Object.fromEntries(Object.entries(data).filter(([k])=>!tables.includes(k))));
 });}
 // Legacy sources are left untouched. Import only into an empty MySQL inventory/account.
 if(!await get('inventory')||!await get('account')){
 if(fs.existsSync(path.join(directory,'library.sqlite'))){const legacy=await require('./sqlite-legacy.cjs').openDatabase(directory,validate,atomicWrite);try{const raw=legacy.readInventory();if(raw&&!await get('inventory'))await write(raw);if(!await get('account')&&legacy.getAccount())await transaction(()=>put('account',legacy.getAccount()));}finally{legacy.close();}}
 else if(!await get('inventory')&&fs.existsSync(path.join(directory,'inventory.json')))await write(fs.readFileSync(path.join(directory,'inventory.json'),'utf8'));
 }
 if(!await get('account')&&fs.existsSync(path.join(directory,'admin-auth.json')))await transaction(()=>put('account',JSON.parse(fs.readFileSync(path.join(directory,'admin-auth.json'),'utf8'))));
 return {readInventory:()=>serial(read),writeInventory:raw=>serial(()=>write(raw)),getAccount:()=>serial(()=>get('account')),setAccount:value=>serial(()=>transaction(()=>put('account',value))),listBackups:()=>serial(async()=>{const [rows]=await connection.query('SELECT name,inventory FROM inventory_backups ORDER BY name DESC');return rows.map(r=>{try{validate(r.inventory);return {name:r.name,valid:true};}catch(e){return {name:r.name,valid:false,error:e.message};}});}),restoreBackup:name=>serial(async()=>{const [rows]=await connection.execute('SELECT inventory FROM inventory_backups WHERE name=?',[name]);if(!rows.length)throw Error('Backup not found');await write(rows[0].inventory);}),close:()=>serial(()=>connection.end())};
 }catch(e){await connection.end();throw connectionError(e,config);}
}
module.exports={openDatabase};
