const {BrowserWindow,ipcMain}=require('electron');
const path=require('node:path');
const {defaults,normalize,loadConfig,configPath,connectionError}=require('./mysql-config.cjs');
async function showSetup(directory,error,atomicWrite){
 let config;try{config=loadConfig(directory);}catch{config={...defaults};}
 return new Promise(resolve=>{
 const win=new BrowserWindow({width:620,height:720,resizable:true,webPreferences:{preload:path.join(__dirname,'mysql-setup-preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
 let saved=false,busy=false;
 ipcMain.handle('mysql-setup-test',async(event,value)=>{
 if(event.sender!==win.webContents)throw Error('Unauthorized window');
 if(busy)return {ok:false,message:'A connection test is already running.'};
 busy=true;let connection,c;
 try{
 c=normalize(value);
 connection=await require('mysql2/promise').createConnection({...c,database:undefined,connectTimeout:7000});
 const [rows]=await connection.query('SELECT VERSION() AS version, @@port AS port');
 // Verify the same database permissions needed at app startup before saving.
 await connection.query(`CREATE DATABASE IF NOT EXISTS \`${c.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
 await connection.query(`USE \`${c.database}\``);
 if(win.isDestroyed())return {ok:false,message:'Setup window was closed.'};
 atomicWrite(configPath(directory),JSON.stringify(c,null,2)+'\n');
 saved=true;
 setTimeout(()=>{if(!win.isDestroyed())win.close();},800);
 return {ok:true,message:`Connected to ${rows[0].version} on port ${rows[0].port}. Opening your library…`};
 }catch(e){return {ok:false,message:c?connectionError(e,c).message:e.message};}
 finally{busy=false;if(connection)await connection.end().catch(()=>{});}
 });
 win.on('closed',()=>{ipcMain.removeHandler('mysql-setup-test');resolve(saved);});
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.loadFile(path.join(__dirname,'mysql-setup.html'),{query:{settings:JSON.stringify({...config,password:''}),error:error.message}}).catch(()=>win.close());
 });
}
module.exports={showSetup};
