const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('mysqlSetup',{test:config=>ipcRenderer.invoke('mysql-setup-test',config)});
