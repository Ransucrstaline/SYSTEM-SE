const { contextBridge, ipcRenderer } = require('electron');
let saveListener;
const KEY='libraryCatalogDB_v3';
function request(operation,key,value) {
  const r=ipcRenderer.sendSync('library-storage',{operation,key,value});
  if(operation==='set') saveListener?.({ok:!!r?.ok,error:r?.error});
  if(!r?.ok) throw Error(r?.error || 'Unable to save inventory file');
  return r.value;
}
contextBridge.exposeInMainWorld('libraryDesktop',Object.freeze({
  phoneToggle(){return ipcRenderer.invoke('phone-toggle');},
  onPhoneRequest(callback){ipcRenderer.on('phone-request',async(_event,r)=>{try{ipcRenderer.send('phone-result',{id:r.id,value:await callback(r)});}catch(e){ipcRenderer.send('phone-result',{id:r.id,error:e.message});}});},
  onSaveStatus(callback){saveListener=callback;},
  account(action,details){return ipcRenderer.invoke('library-account',action,details);},
  authState(){return ipcRenderer.invoke("library-auth-state");},
  auth(action,password){return ipcRenderer.invoke("library-auth",action,password);},
  getItem(key){return request('get',key);},
  setItem(key,value){return request('set',key,value);},
  removeItem(key){return request('remove',key);},
  dataFolder(){return ipcRenderer.invoke('library-data-folder');},
  backups(){return ipcRenderer.invoke('library-backups');},
  restoreBackup(name){return ipcRenderer.invoke('library-restore-backup',name);}
}));
