const forge=require('node-forge'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
exports.credentials=function(directory){
 fs.mkdirSync(directory,{recursive:true});
 const keyPath=path.join(directory,'phone-ca-key.pem'),certPath=path.join(directory,'phone-ca.pem');
 const pki=forge.pki;
 let caKey,ca;
 function certificate(key,cn,days){const c=pki.createCertificate();c.publicKey=key.publicKey;c.serialNumber='01'+require('node:crypto').randomBytes(15).toString('hex');c.validity.notBefore=new Date(Date.now()-86400000);c.validity.notAfter=new Date(Date.now()+days*86400000);c.setSubject([{name:'commonName',value:cn}]);return c;}
 if(fs.existsSync(keyPath)&&fs.existsSync(certPath)){caKey=pki.privateKeyFromPem(fs.readFileSync(keyPath,'utf8'));ca=pki.certificateFromPem(fs.readFileSync(certPath,'utf8'));}
 else{const keys=pki.rsa.generateKeyPair(2048);caKey=keys.privateKey;ca=certificate(keys,'Library Inventory Local Camera CA',3650);ca.setIssuer(ca.subject.attributes);ca.setExtensions([{name:'basicConstraints',cA:true},{name:'keyUsage',keyCertSign:true,cRLSign:true}]);ca.sign(caKey,forge.md.sha256.create());fs.writeFileSync(keyPath,pki.privateKeyToPem(caKey),{mode:0o600});fs.writeFileSync(certPath,pki.certificateToPem(ca));}
 const keys=pki.rsa.generateKeyPair(2048),leaf=certificate(keys,'Library Inventory',365);
 let interfaces;try{interfaces=os.networkInterfaces();}catch{interfaces={};}const ips=new Set(['127.0.0.1']);for(const items of Object.values(interfaces))for(const i of items||[])if(i.family==='IPv4'||i.family===4)ips.add(i.address);
 leaf.setIssuer(ca.subject.attributes);leaf.setExtensions([{name:'basicConstraints',cA:false},{name:'keyUsage',digitalSignature:true,keyEncipherment:true},{name:'extKeyUsage',serverAuth:true},{name:'subjectAltName',altNames:[{type:2,value:'localhost'},...[...ips].map(ip=>({type:7,ip}))]}]);leaf.sign(caKey,forge.md.sha256.create());
 return {key:pki.privateKeyToPem(keys.privateKey),cert:pki.certificateToPem(leaf),ca:pki.certificateToPem(ca),publicCertificate:Buffer.from(forge.asn1.toDer(pki.certificateToAsn1(ca)).getBytes(),'binary')};
};
