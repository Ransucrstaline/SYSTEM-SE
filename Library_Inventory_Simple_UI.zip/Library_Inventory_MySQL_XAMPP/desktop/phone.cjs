const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
exports.startPhone=async function({root,allowed,request,port=3210,tlsDirectory}){
 const token=crypto.randomBytes(24).toString('hex');
 const files=new Map(['index.html','css/style.css','css/shelves.svg','js/app.js','js/qr-feature.js','js/qr-vendor.js','js/phone.js','js/motion.js','js/zxing.min.js'].map(x=>['/'+x,path.join(root,x)]));
 const tls=tlsDirectory?require('./phone-tls.cjs').credentials(tlsDirectory):null;
 const handler=async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Content-Type-Options','nosniff');
  const send=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));};
  try{
   const url=new URL(req.url,'http://localhost');
   if(url.pathname==='/camera-certificate.cer'&&tls){res.writeHead(200,{'Content-Type':'application/pkix-cert','Content-Disposition':'attachment; filename=Library-Camera-CA.cer'});return res.end(tls.publicCertificate);}
   if(url.pathname==='/phone-api'){
    if(req.method!=='POST'||req.headers['x-library-token']!==token||!allowed())return send(401,{error:'Pair again from the signed-in desktop.'});
    if(req.headers.origin&&req.headers.origin!==`${req.socket.encrypted?'https':'http'}://${req.headers.host}`)return send(403,{error:'Invalid origin'});
    let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>16000000)return send(413,{error:'Request too large'});}
    const {method,route,body}=JSON.parse(raw);
    if(!['GET','POST','PUT','PATCH','DELETE'].includes(method)||typeof route!=='string'||!route.startsWith('/')||route.length>2000)return send(400,{error:'Invalid request'});
    return send(200,{value:await request(method,route,body)});
   }
   const file=files.get(url.pathname==='/'?'/index.html':url.pathname);
   if(req.method!=='GET'||!file)return send(404,{error:'Not found'});
   res.setHeader('Content-Type',file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.css')?'text/css':file.endsWith('.svg')?'image/svg+xml':'text/javascript');
   fs.createReadStream(file).on('error',()=>{if(!res.headersSent)res.writeHead(404);res.end();}).pipe(res);
  }catch(e){send(400,{error:e.message});}
 };
 const server=http.createServer(handler);
 let secureServer;
 if(tls){secureServer=require('node:https').createServer(tls,handler);await new Promise((resolve,reject)=>{secureServer.once('error',reject);secureServer.listen(port===0?0:port+1,'0.0.0.0',resolve);});}
 server.on('close',()=>{secureServer?.closeAllConnections();secureServer?.close();});
 await new Promise((resolve,reject)=>{
  const fail=error=>{if(error.code==='EADDRINUSE')error.message='Phone sharing port '+port+' is already in use. Close the other Library app or free this port, then try again.';secureServer?.close();reject(error);};
  server.once('error',fail);
  server.listen(port,'0.0.0.0',()=>{server.removeListener('error',fail);resolve();});
 });
 const actualPort=server.address().port;
 let interfaces;try{interfaces=os.networkInterfaces();}catch{interfaces={};}
 const connections=[];const seen=new Set();
 for(const [name,entries] of Object.entries(interfaces))for(const item of entries||[]){
  if(!['IPv4',4].includes(item.family)||item.internal||item.address.startsWith('169.254.')||seen.has(item.address))continue;
  seen.add(item.address);
  connections.push({name,address:item.address,url:`${tls?'https':'http'}://${item.address}:${tls?secureServer.address().port:actualPort}/#phone=${token}`,setupUrl:`http://${item.address}:${actualPort}/camera-certificate.cer`});
 }
 connections.sort((a,b)=>Number(/virtual|vmware|vbox|wsl|vethernet/i.test(a.name))-Number(/virtual|vmware|vbox|wsl|vethernet/i.test(b.name)));
 const urls=connections.map(item=>item.url);
 return {server,securePort:secureServer?.address().port,urls,connections,port:actualPort,pairingPath:`/#phone=${token}`};
};
