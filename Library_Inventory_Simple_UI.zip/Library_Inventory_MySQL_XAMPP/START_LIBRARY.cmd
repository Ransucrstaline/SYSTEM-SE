@echo off
setlocal
cd /d "%~dp0"
set ELECTRON_RUN_AS_NODE=
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js is missing. Install Node.js LTS, then reopen this file.
 pause
 exit /b 1
)
call npm start
pause
