import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
const require=createRequire(import.meta.url);
const config=require('../desktop/mysql-config.cjs');
test('saved settings override defaults and preserve password characters',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mysql-config-'));
 try{
 assert.throws(()=>config.loadConfig(dir),/Enter a username/);
 assert.equal(config.defaults.port,3307);
 const value={host:'localhost',port:'3307',user:'librarian',password:' space " \\ pass ',database:'library_inventory'};
 fs.writeFileSync(config.configPath(dir),JSON.stringify(value));
 assert.equal(config.loadConfig(dir).port,3307);
 assert.equal(config.loadConfig(dir).password,value.password);
 assert.throws(()=>config.normalize({...value,port:0}),/Port/);
 assert.throws(()=>config.normalize({...value,database:'a`; DROP DATABASE x'}),/Database name/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('diagnostics distinguish refused connections and rejected credentials without exposing password',()=>{
 for(const [code,expected] of [['ECONNREFUSED',/exact port/],['ER_ACCESS_DENIED_ERROR',/rejected/]]){
 const error=config.connectionError({code,message:'sensitive password'},{host:'127.0.0.1',port:3307,user:'root'});
 assert.match(error.message,expected);assert.match(error.message,/3307/);assert.doesNotMatch(error.message,/sensitive password/);
 }
});
test('setup retries login and saves only a tested connection',async()=>{
 const handlers=new Map();let window,stored,closed=0,attempt=0;
 class Window{
 constructor(){window=this;this.webContents={setWindowOpenHandler(){}};}
 on(event,fn){if(event==='closed')this.onClosed=fn;}
 loadFile(){return Promise.resolve();}
 isDestroyed(){return false;}
 close(){closed++;this.onClosed();}
 }
 const fakeMysql={createConnection:async()=>{if(++attempt===1)throw Object.assign(Error('bad login'),{code:'ER_ACCESS_DENIED_ERROR'});return {query:async sql=>sql.startsWith('SELECT')?[[{version:'test-server',port:3307}]]:[[]],end:async()=>{}};}};
 const context=vm.createContext({module:{exports:{}},require:name=>name==='electron'?{BrowserWindow:Window,ipcMain:{handle:(key,fn)=>handlers.set(key,fn),removeHandler:key=>handlers.delete(key)}}:name==='mysql2/promise'?fakeMysql:name==='./mysql-config.cjs'?{...config,loadConfig:()=>config.defaults}:require(name),__dirname:path.resolve('desktop'),setTimeout:fn=>{queueMicrotask(fn);}});
 vm.runInContext(fs.readFileSync('desktop/mysql-setup.cjs','utf8'),context);
 const done=context.module.exports.showSetup('/unused',Error('access denied'),(file,value)=>{stored=JSON.parse(value);});
 const handler=handlers.get('mysql-setup-test');
 await assert.rejects(handler({sender:{}},{...config.defaults,user:'root'}),/Unauthorized/);
 const event={sender:window.webContents};
 assert.equal((await handler(event,{...config.defaults,user:'root'})).ok,false);assert.equal(stored,undefined);
 assert.equal((await handler(event,{...config.defaults,user:'librarian',port:3307,password:'correct'})).ok,true);
 assert.equal(await done,true);assert.equal(stored.password,'correct');assert.equal(stored.port,3307);assert.equal(closed,1);assert.equal(handlers.size,0);
});
