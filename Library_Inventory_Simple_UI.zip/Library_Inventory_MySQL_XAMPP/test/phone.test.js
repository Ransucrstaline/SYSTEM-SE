import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const {startPhone}=createRequire(import.meta.url)('../desktop/phone.cjs');
test('paired LAN API requires token and desktop login; serves only app assets',async()=>{
 let unlocked=true;
 const phone=await startPhone({root:process.cwd(),port:0,allowed:()=>unlocked,request:async(method,route,body)=>({method,route,body})});
 try{
 const port=phone.server.address().port, base=`http://127.0.0.1:${port}`;
 const token=new URL(phone.pairingPath,base).hash.slice(7);
 const call=(key,extra={})=>fetch(base+'/phone-api',{method:'POST',headers:{'Content-Type':'application/json','X-Library-Token':key,...extra},body:JSON.stringify({method:'POST',route:'/loans',body:{copyId:1}})});
 assert.equal((await call('wrong')).status,401);
 assert.equal((await call(token,{Origin:'http://evil.test'})).status,403);
 const r=await call(token);assert.equal(r.status,200);assert.equal((await r.json()).value.route,'/loans');
 unlocked=false;assert.equal((await call(token)).status,401);
 assert.equal((await fetch(base+'/desktop/main.cjs')).status,404);
 assert.equal((await fetch(base+'/')).status,200);
 }finally{phone.server.closeAllConnections();await new Promise(resolve=>phone.server.close(resolve));}
});
