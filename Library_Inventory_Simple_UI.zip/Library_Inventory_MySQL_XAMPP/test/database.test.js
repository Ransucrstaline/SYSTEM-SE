import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createRequire} from 'node:module';
import {createBackend,validateInventory} from '../src/backend.js';
const {openDatabase}=createRequire(import.meta.url)('../desktop/sqlite-legacy.cjs');
const validate=raw=>validateInventory(JSON.parse(raw));
const atomic=(file,bytes)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file+'.tmp',bytes);fs.renameSync(file+'.tmp',file);};
test('SQLite migrates records and account, survives reopen, restores and rolls back failed disk writes',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'library-sql-'));let db;
 try{
 const memory=new Map();const api=createBackend({getItem:k=>memory.get(k),setItem:(k,v)=>memory.set(k,v)},{sample:true});
 const original=JSON.stringify(api._data());fs.writeFileSync(path.join(dir,'inventory.json'),original);fs.writeFileSync(path.join(dir,'admin-auth.json'),JSON.stringify({salt:'old',hash:'old'}));
 let fail=false;const writer=(...args)=>{if(fail)throw Error('disk full');atomic(...args);};
 db=await openDatabase(dir,validate,writer);assert.deepEqual(JSON.parse(db.readInventory()),JSON.parse(original));assert.equal(db.getAccount().salt,'old');assert.ok(!fs.existsSync(path.join(dir,'inventory.json')));assert.equal(fs.readFileSync(path.join(dir,'library.sqlite')).subarray(0,15).toString(),'SQLite format 3');
 const backend=createBackend({getItem:()=>db.readInventory(),setItem:(_k,v)=>db.writeInventory(v)});
 await backend('POST','/members',{name:'SQL Member',type:'Student'});const saved=db.readInventory();assert.ok(JSON.parse(saved).members.some(m=>m.name==='SQL Member'));
 fail=true;await assert.rejects(backend('POST','/members',{name:'Failed Member',type:'Student'}),/disk full/);assert.equal(db.readInventory(),saved);fail=false;
 db.close();db=await openDatabase(dir,validate,writer);assert.equal(db.readInventory(),saved);assert.ok(db.listBackups().every(b=>b.valid));db.restoreBackup('previous.sqlite');assert.deepEqual(JSON.parse(db.readInventory()),JSON.parse(original));
 }finally{db?.close();fs.rmSync(dir,{recursive:true,force:true});}
});
