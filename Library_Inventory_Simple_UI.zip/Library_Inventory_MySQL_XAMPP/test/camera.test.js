import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
function harness(getUserMedia){
 const elements=new Map(),listeners=new Map();let callback,resets=0,stops=0;
 const element=s=>{if(!elements.has(s))elements.set(s,{hidden:false,disabled:false,value:'',textContent:'',innerHTML:'',dataset:{},querySelectorAll:()=>[],addEventListener(){},scrollIntoView(){},play:async()=>{}});return elements.get(s);};
 const track={stop(){stops++;}};const stream={getTracks:()=>[track]};
 const document={readyState:'complete',hidden:false,querySelector:element,addEventListener:(e,fn)=>listeners.set(e,fn)};
 const window={isSecureContext:true,libraryDesktop:{remote:true},addEventListener:(e,fn)=>listeners.set(e,fn),libraryAPI:async()=>({titles:[{id:1,title:'Computing'}],copies:[{titleId:1,accessionNumber:'BOOK001',status:'available'}]}),ZXing:{BrowserMultiFormatReader:class{async decodeFromStream(_stream,_video,fn){callback=fn;}reset(){resets++;}}}};
 const context=vm.createContext({window,document,navigator:{mediaDevices:{getUserMedia:()=>getUserMedia?getUserMedia(stream):Promise.resolve(stream)}},ZXing:window.ZXing,location:{hash:''},matchMedia:()=>({matches:true}),setTimeout,URL,console});
 vm.runInContext(fs.readFileSync('js/qr-feature.js','utf8'),context);
 return {element,listeners,stream,callback:()=>callback,stops:()=>stops,resets:()=>resets};
}
test('camera decodes with ZXing without BarcodeDetector and releases camera after finding copy',async()=>{
 const h=harness();await h.element('#qrCamera').onclick();assert.equal(h.element('#qrStop').hidden,false);assert.ok(h.callback());h.callback()({getText:()=> 'LIBRARY-COPY:BOOK001'});await new Promise(r=>setImmediate(r));assert.match(h.element('#scannerResult').innerHTML,/Computing/);assert.equal(h.element('#qrVideo').srcObject,null);assert.ok(h.stops()>0);assert.ok(h.resets()>0);
});
test('camera permission denial restores start button and explains how to allow camera',async()=>{
 const h=harness(()=>Promise.reject(Object.assign(Error('denied'),{name:'NotAllowedError'})));await h.element('#qrCamera').onclick();assert.equal(h.element('#qrCamera').disabled,false);assert.match(h.element('#qrMessage').textContent,/permission was blocked/);
});
test('camera granted after navigation is immediately released',async()=>{
 let grant;const h=harness(stream=>new Promise(resolve=>{grant=()=>resolve(stream);}));const starting=h.element('#qrCamera').onclick();h.listeners.get('hashchange')();grant();await starting;assert.equal(h.stops(),1);assert.equal(h.callback(),undefined);
});
