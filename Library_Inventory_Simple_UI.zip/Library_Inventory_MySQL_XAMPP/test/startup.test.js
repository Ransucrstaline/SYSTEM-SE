import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
test('desktop startup creates and retains its window and registers storage and phone handlers',async()=>{
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'library-start-'));
 const handlers=new Map();let window;let reported;
 class Window{constructor(){window=this;this.webContents={on(){},setWindowOpenHandler(){}};}on(){}loadFile(file){assert.ok(fs.existsSync(file));return Promise.resolve();}static getAllWindows(){return window?[window]:[];}}
 const app={disableHardwareAcceleration(){},requestSingleInstanceLock:()=>true,on(){},whenReady:()=>Promise.resolve(),getPath:()=>directory,quit(){}};
 const context=vm.createContext({require:name=>name==='./database.cjs'?{openDatabase:async()=>({getAccount:async()=>null})}:name==='electron'?{app,BrowserWindow:Window,ipcMain:{on:(name,fn)=>handlers.set(name,fn),handle:(name,fn)=>handlers.set(name,fn)},dialog:{showErrorBox:(_title,message)=>reported=message}}:name.startsWith('./')?require('../desktop/'+name.slice(2)):require(name),__dirname:path.resolve('desktop'),process:{on(){},pid:process.pid,argv:[]},console,setTimeout,clearTimeout,Buffer,URL});
 try{vm.runInContext(fs.readFileSync('desktop/main.cjs','utf8'),context);for(let i=0;i<100&&!window&&!reported;i++)await new Promise(resolve=>setTimeout(resolve,10));assert.equal(reported,undefined);assert.equal(vm.runInContext('mainWindow',context),window);assert.ok(handlers.has('library-storage'));assert.ok(handlers.has('phone-toggle'));assert.deepEqual(JSON.parse(JSON.stringify(await handlers.get('library-auth-state')())),{setupRequired:true,authenticated:false});}finally{fs.rmSync(directory,{recursive:true,force:true});}
});
