import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import https from 'node:https';
const require=createRequire(import.meta.url);
const {startPhone}=require('../desktop/phone.cjs');
test('phone HTTPS trusts persistent CA, protects API and keeps private files inaccessible',async()=>{
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'library-tls-'));
 const phone=await startPhone({root:process.cwd(),port:0,tlsDirectory:directory,allowed:()=>true,request:async()=>({ok:true})});
 try{
 const ca=fs.readFileSync(path.join(directory,'phone-ca.pem'));
 const port=phone.securePort,token=new URL(phone.pairingPath,'http://localhost').hash.slice(7);
 const request=(route,key)=>new Promise((resolve,reject)=>{const req=https.request({hostname:'127.0.0.1',port,path:route,ca,method:key?'POST':'GET',headers:key?{'X-Library-Token':key,Origin:`https://127.0.0.1:${port}`} :{}},res=>{let body='';res.on('data',b=>body+=b);res.on('end',()=>resolve({status:res.statusCode,body}));});req.on('error',reject);req.end(key?JSON.stringify({method:'GET',route:'/config'}):undefined);});
 assert.equal((await request('/')).status,200);
 assert.equal((await request('/phone-api','wrong')).status,401);
 const r=await request('/phone-api',token);assert.equal(r.status,200);assert.equal(JSON.parse(r.body).value.ok,true);
 assert.equal((await request('/desktop/phone-tls.cjs')).status,404);
 assert.equal((await request('/camera-certificate.cer')).status,200);
 require('../desktop/phone-tls.cjs').credentials(directory);assert.equal(fs.readFileSync(path.join(directory,'phone-ca.pem'),'utf8'),ca.toString());
 }finally{phone.server.closeAllConnections();await new Promise(resolve=>phone.server.close(resolve));fs.rmSync(directory,{recursive:true,force:true});}
});
