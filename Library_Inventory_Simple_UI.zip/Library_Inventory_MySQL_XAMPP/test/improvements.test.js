import test from 'node:test';
import assert from 'node:assert/strict';
import {createBackend,validateInventory,validateSettings} from '../src/backend.js';
const blank=()=>({version:3,seq:{title:0,copy:0,member:0,loan:0,res:0},titles:[],copies:[],members:[],loans:[],reservations:[]});
test('rejects duplicate identifiers',()=>{const d=blank();d.members=[{id:1,name:'A'},{id:1,name:'B'}];d.seq.member=1;assert.throws(()=>validateInventory(d),/duplicate/)});
test('rejects dangling copy',()=>{const d=blank();d.copies=[{id:1,titleId:2,accessionNumber:'A',status:'available'}];d.seq.copy=1;assert.throws(()=>validateInventory(d),/missing title/)});
test('rejects invalid rules',()=>assert.throws(()=>validateSettings({loanDays:-1}),/loanDays/));
test('activity and configurable rules persist',async()=>{const m=new Map();const storage={getItem:k=>m.get(k)||null,setItem:(k,v)=>m.set(k,v)};const a=createBackend(storage,{sample:false});await a('PUT','/config',{loanDays:21,renewDays:7,maxRenewals:2,maxLoansPerMember:5,finePerDay:5});assert.equal((await a('GET','/config')).loanDays,21);assert.ok((await a('GET','/activity')).length);const b=createBackend(storage,{sample:false});assert.equal((await b('GET','/config')).loanDays,21)});
