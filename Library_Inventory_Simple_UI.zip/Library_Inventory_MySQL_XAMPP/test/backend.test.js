import test from "node:test";
import assert from "node:assert/strict";
import { createBackend } from "../src/backend.js";
import { addDays, today } from "../src/dates.js";

const memoryStorage = () => { const m = new Map(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k), _m: m }; };
let storage, api;
test.beforeEach(() => { storage = memoryStorage(); api = createBackend(storage, { sample: false }); });

// Mimics an HTTP call: errors come back as { status, body: { error } }.
async function call(method, path, body) {
  try { return { status: 200, body: await api(method, path, body) }; }
  catch (e) { return { status: e.status || 500, body: { error: e.message } }; }
}
const newTitle = (extra = {}) => call("POST", "/titles", { title: "Database Systems", author: "A. Writer", year: 2020, subjects: "Databases, SQL", callNumber: "QA76 A1", copies: 2, location: "Shelf A", ...extra });
const newMember = async (name) => (await call("POST", "/members", { name })).body;

test("creating a title also creates its copies with unique accession numbers", async () => {
  const r = await newTitle();
  assert.equal(r.status, 200);
  assert.equal(r.body.copiesTotal, 2);
  assert.equal(r.body.free, 2);
  const detail = (await call("GET", `/titles/${r.body.id}`)).body;
  assert.equal(new Set(detail.copies.map((c) => c.accessionNumber)).size, 2);
});

test("validation errors are 400 with a message", async () => {
  const r = await newTitle({ title: "", year: "abc" });
  assert.equal(r.status, 400);
  assert.match(r.body.error, /required|whole number/);
});

test("search uses every word and the status filter works", async () => {
  await newTitle();
  await newTitle({ title: "Networks", author: "B. Author", subjects: "Networking", callNumber: "TK5105" });
  assert.equal((await call("GET", "/titles?q=database%20sql")).body.length, 1);
  assert.equal((await call("GET", "/titles?q=zzz")).body.length, 0);
  assert.equal((await call("GET", "/titles?status=available")).body.length, 2);
  assert.equal((await call("GET", "/titles?status=checked_out")).body.length, 0);
  assert.equal((await call("GET", "/titles?sort=titleAsc")).body[0].title, "Database Systems");
});

test("checkout, one copy per member, and running out of copies", async () => {
  const t = (await newTitle()).body;
  const [a, b, c] = [await newMember("Ana"), await newMember("Ben"), await newMember("Cy")];
  assert.equal((await call("POST", "/loans", { titleId: t.id, memberId: a.id })).status, 200);
  assert.equal((await call("POST", "/loans", { titleId: t.id, memberId: a.id })).status, 409);
  assert.equal((await call("POST", "/loans", { titleId: t.id, memberId: b.id })).status, 200);
  const none = await call("POST", "/loans", { titleId: t.id, memberId: c.id });
  assert.equal(none.status, 409);
  assert.match(none.body.error, /No copies/);
  assert.equal((await call("GET", "/titles?status=checked_out")).body.length, 1);
});

test("reservation queue holds returned copies for the person waiting", async () => {
  const t = (await newTitle({ copies: 1 })).body;
  const [a, b, c] = [await newMember("Ana"), await newMember("Ben"), await newMember("Cy")];
  assert.equal((await call("POST", "/reservations", { titleId: t.id, memberId: b.id })).status, 409);
  const loan = (await call("POST", "/loans", { titleId: t.id, memberId: a.id })).body;
  assert.equal((await call("POST", "/reservations", { titleId: t.id, memberId: b.id })).status, 200);
  assert.equal((await call("POST", "/reservations", { titleId: t.id, memberId: b.id })).status, 409);
  await call("POST", `/loans/${loan.id}/return`);
  const cut = await call("POST", "/loans", { titleId: t.id, memberId: c.id });
  assert.equal(cut.status, 409);
  assert.match(cut.body.error, /queue/);
  assert.equal((await call("POST", "/loans", { titleId: t.id, memberId: b.id })).status, 200);
  assert.equal((await call("GET", `/titles/${t.id}`)).body.queue.length, 0);
});

test("overdue returns create a fine that blocks borrowing until paid", async () => {
  const t = (await newTitle()).body;
  const a = await newMember("Ana");
  const loan = (await call("POST", "/loans", { titleId: t.id, memberId: a.id })).body;
  const row = api._data().loans.find((l) => l.id === loan.id);
  row.borrowedAt = addDays(today(), -20); row.dueAt = addDays(today(), -4);

  const ret = (await call("POST", `/loans/${loan.id}/return`)).body;
  assert.equal(ret.daysOverdue, 4);
  assert.equal(ret.fine, 20);
  assert.equal((await call("POST", `/loans/${loan.id}/return`)).status, 409);
  assert.equal((await call("GET", `/members/${a.id}`)).body.unpaidFines, 20);
  const blocked = await call("POST", "/loans", { titleId: t.id, memberId: a.id });
  assert.equal(blocked.status, 409);
  assert.match(blocked.body.error, /unpaid fines/);
  assert.equal((await call("POST", `/members/${a.id}/fines/pay`)).body.paid, 20);
  assert.equal((await call("POST", "/loans", { titleId: t.id, memberId: a.id })).status, 200);
});

test("renewal rules: limit, queue and overdue", async () => {
  const t = (await newTitle({ copies: 1 })).body;
  const [a, b] = [await newMember("Ana"), await newMember("Ben")];
  const loan = (await call("POST", "/loans", { titleId: t.id, memberId: a.id })).body;
  const r1 = await call("POST", `/loans/${loan.id}/renew`);
  assert.equal(r1.status, 200);
  assert.equal(r1.body.dueAt, addDays(loan.dueAt, 7));
  assert.equal((await call("POST", `/loans/${loan.id}/renew`)).status, 200);
  assert.match((await call("POST", `/loans/${loan.id}/renew`)).body.error, /limit/);

  const row = () => api._data().loans.find((l) => l.id === loan.id);   // re-read: a failed action reloads the data
  row().renewals = 0;
  await call("POST", "/reservations", { titleId: t.id, memberId: b.id });
  assert.match((await call("POST", `/loans/${loan.id}/renew`)).body.error, /waiting/);
  row().dueAt = addDays(today(), -1);
  assert.match((await call("POST", `/loans/${loan.id}/renew`)).body.error, /Overdue/);
});

test("records with history or open loans can't be deleted", async () => {
  const t = (await newTitle({ copies: 1 })).body;
  const a = await newMember("Ana");
  const loan = (await call("POST", "/loans", { titleId: t.id, memberId: a.id })).body;
  assert.equal((await call("DELETE", `/titles/${t.id}`)).status, 409);
  assert.equal((await call("DELETE", `/copies/${loan.copyId}`)).status, 409);
  assert.equal((await call("PUT", `/members/${a.id}`, { name: "Ana", active: false })).status, 409);
  await call("POST", `/loans/${loan.id}/return`);
  assert.equal((await call("DELETE", `/members/${a.id}`)).status, 409);
  assert.equal((await call("DELETE", `/titles/${t.id}`)).status, 200);
});

test("a failed action changes nothing (rolls back)", async () => {
  const t = (await newTitle({ copies: 1 })).body;
  const before = JSON.stringify(api._data());
  assert.equal((await call("POST", `/titles/${t.id}/copies`, { accessionNumber: "ACC-2026-0001" })).status, 409);
  assert.equal(JSON.stringify(api._data()), before);
});

test("data is saved and comes back after a reload", async () => {
  const t = (await newTitle()).body;
  const a = await newMember("Ana");
  await call("POST", "/loans", { titleId: t.id, memberId: a.id });
  const reloaded = createBackend(storage, { sample: false });   // same storage = same browser
  assert.equal((await reloaded("GET", "/titles")).length, 1);
  assert.equal((await reloaded("GET", "/loans?status=active")).length, 1);
  assert.equal((await reloaded("GET", "/members")).length, 1);
});

test("a full storage reports an error and keeps the previous data", async () => {
  await newTitle();
  storage.setItem = () => { throw new Error("QuotaExceededError"); };
  const r = await newTitle({ title: "Second" });
  assert.equal(r.status, 507);
  assert.match(r.body.error, /Unable to save inventory: QuotaExceededError/);
  assert.equal(api._data().titles.length, 1);
});

test("first run: sample data, or automatic migration from the original version", async () => {
  const seeded = createBackend(memoryStorage());
  assert.equal((await seeded("GET", "/stats")).titles, 4);

  const old = memoryStorage();
  old.setItem("libraryCatalogItemsV2", JSON.stringify([
    { title: "Old Book", author: "X", year: 2001, subject: ["A"], callNumber: "Q1", accessionNumber: "ACC-1", copies: 3, status: "Checked Out", borrower: "Juan", borrowDate: "2026-01-01", dueDate: "2026-01-15", location: "Shelf 1" }
  ]));
  const migrated = createBackend(old);
  assert.equal(migrated.info.migrated, 1);
  assert.equal((await migrated("GET", "/stats")).copies, 3);
  assert.equal((await migrated("GET", "/loans?status=overdue")).length, 1);
});

test("import merges records and skips duplicates", async () => {
  const legacy = [
    { title: "Old Book", author: "X", year: 2001, subject: ["A"], callNumber: "Q1", accessionNumber: "ACC-1", copies: 3, status: "Checked Out", borrower: "Juan", borrowDate: "2026-01-01", dueDate: "2026-01-15" },
    { title: "Waiting Book", author: "Y", year: 2002, subject: ["B"], callNumber: "Q2", accessionNumber: "ACC-2", copies: 1, status: "Reserved", borrower: "Maria" }
  ];
  const first = (await call("POST", "/import", legacy)).body;
  assert.deepEqual([first.titles, first.copies], [2, 4]);
  assert.equal((await call("GET", "/titles?status=reserved")).body.length, 1);
  assert.equal((await call("POST", "/import", legacy)).body.skipped, 2);
});

test("export then restore brings back everything, including loans", async () => {
  const t = (await newTitle()).body;
  const a = await newMember("Ana");
  await call("POST", "/loans", { titleId: t.id, memberId: a.id });
  const backup = (await call("GET", "/export")).body;

  const other = createBackend(memoryStorage(), { sample: false });
  const res = await other("POST", "/restore", backup);
  assert.deepEqual([res.titles, res.members, res.loans], [1, 1, 1]);
  assert.equal((await other("GET", "/loans?status=active")).length, 1);
  assert.equal((await other("POST", "/restore", { nope: true }).catch((e) => e.status)), 400);
});

test("reset clears the library", async () => {
  await newTitle();
  await call("POST", "/reset", { sample: false });
  assert.equal((await call("GET", "/stats")).body.titles, 0);
});

test('returned books remain off the outstanding list after a full restart', async () => {
  const t = (await newTitle()).body;
  const m = await newMember('Return persistence');
  const loan = (await call('POST', '/loans', { titleId: t.id, memberId: m.id })).body;
  assert.equal((await call('POST', `/loans/${loan.id}/return`)).status, 200);
  api = createBackend(storage, { sample: false });
  assert.equal((await call('GET', '/loans?status=active')).body.length, 0);
  assert.equal((await call('GET', '/loans?status=overdue')).body.length, 0);
  assert.equal((await call('GET', '/loans?status=returned')).body.length, 1);
  assert.equal((await call('GET', `/titles/${t.id}`)).body.free, 2);
});

test('locked or corrupt saved storage is never overwritten by startup samples', () => {
  let writes = 0;
  assert.throws(() => createBackend({getItem(){throw Error('Please log in first');},setItem(){writes++;}}), /log in/);
  assert.throws(() => createBackend({getItem(){return '{broken';},setItem(){writes++;}}));
  assert.equal(writes, 0);
});
