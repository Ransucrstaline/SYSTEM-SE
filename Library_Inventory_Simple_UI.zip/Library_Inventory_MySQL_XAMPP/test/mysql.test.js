import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createRequire} from 'node:module';
import {createBackend,validateInventory} from '../src/backend.js';
const require=createRequire(import.meta.url);
const {openDatabase}=require('../desktop/database.cjs');
const mysql=require('mysql2/promise');
test('MySQL migrates, persists across reopen, rolls back SQL failure and restores snapshots',{skip:!process.env.LIBRARY_MYSQL_TEST},async()=>{
 const config={...require('../mysql-config.json'),database:'library_test_'+Date.now()};
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mysql-test-'));
 let db,connection;
 const validate=raw=>validateInventory(JSON.parse(raw));
 const atomic=(file,data)=>fs.writeFileSync(file,data);
 try{
 const memory=new Map();const api=createBackend({getItem:k=>memory.get(k),setItem:(k,v)=>memory.set(k,v)},{sample:true});
 const raw=JSON.stringify(api._data());fs.writeFileSync(path.join(dir,'inventory.json'),raw);fs.writeFileSync(path.join(dir,'admin-auth.json'),JSON.stringify({salt:'s',hash:'h'}));
 db=await openDatabase(dir,validate,atomic,config);
 assert.deepEqual(JSON.parse(await db.readInventory()),JSON.parse(raw));assert.equal((await db.getAccount()).salt,'s');
 const changed=JSON.parse(raw);changed.members.push({id:++changed.seq.member,name:'MySQL Member',type:'Student'});await db.writeInventory(JSON.stringify(changed));
 await db.close();db=await openDatabase(dir,validate,atomic,config);assert.ok(JSON.parse(await db.readInventory()).members.some(m=>m.name==='MySQL Member'));
 connection=await mysql.createConnection(config);
 await connection.query("CREATE TRIGGER reject_test BEFORE INSERT ON members FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='test failure'");
 await assert.rejects(db.writeInventory(raw),/test failure/);assert.ok(JSON.parse(await db.readInventory()).members.some(m=>m.name==='MySQL Member'));
 await connection.query('DROP TRIGGER reject_test');await db.restoreBackup('previous.mysql');assert.deepEqual(JSON.parse(await db.readInventory()),JSON.parse(raw));assert.ok((await db.listBackups()).every(b=>b.valid));
 }finally{await db?.close();if(connection){await connection.query(`DROP DATABASE \`${config.database}\``);await connection.end();}fs.rmSync(dir,{recursive:true,force:true});}
});
