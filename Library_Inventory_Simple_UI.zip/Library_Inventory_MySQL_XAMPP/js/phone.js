(()=>{
const paired=location.protocol!=='file:';if(!paired)return;
const token=location.hash.startsWith('#phone=')?location.hash.slice(7):sessionStorage.getItem('libraryPhoneToken');
if(token){sessionStorage.setItem('libraryPhoneToken',token);history.replaceState(null,'','#scanner');}
let listener;
async function api(method,route,body){const r=await fetch('/phone-api',{method:'POST',headers:{'Content-Type':'application/json','X-Library-Token':token||''},body:JSON.stringify({method,route,body})});const d=await r.json();if(!r.ok||d.error)throw Error(d.error||'Connection failed');if(method!=='GET')listener?.({ok:true});return d.value;}
const unavailable=async()=>{throw Error('Use the desktop for account and backup management.');};
window.libraryDesktop={remote:true,api,authState:async()=>{await api('GET','/config');return {authenticated:true,setupRequired:false};},auth:async(action)=>{if(action==='logout'){sessionStorage.removeItem('libraryPhoneToken');location.reload();}return unavailable();},account:unavailable,dataFolder:unavailable,backups:unavailable,restoreBackup:unavailable,onSaveStatus:fn=>listener=fn};
})();
