(() => {
  // src/dates.js
  var iso = (d) => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
  var today = () => iso(/* @__PURE__ */ new Date());
  function addDays(value, n) {
    const d = /* @__PURE__ */ new Date(value + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }
  function isDate(s) {
    if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    const d = /* @__PURE__ */ new Date(s + "T00:00:00Z");
    return !isNaN(d) && d.toISOString().slice(0, 10) === s;
  }
  var daysBetween = (a, b) => Math.round((/* @__PURE__ */ new Date(b + "T00:00:00Z") - /* @__PURE__ */ new Date(a + "T00:00:00Z")) / 864e5);

  // src/backend.js
  var DEFAULT_CONFIG = {
    loanDays: 14,
    // default loan period
    renewDays: 7,
    // extra days per renewal
    maxRenewals: 2,
    // renewals allowed per loan
    maxLoansPerMember: 5,
    // simultaneous loans
    finePerDay: 5,
    // fine for each day a loan is overdue
    currency: "\u20B1"
  };
  var CONFIG = { ...DEFAULT_CONFIG };
  var TYPES = ["Book", "E-book", "DVD", "Audiobook", "Journal", "Other"];
  var MEMBER_TYPES = ["Student", "Faculty", "Staff", "Public"];
  var STORAGE_KEY = "libraryCatalogDB_v3";
  var LEGACY_KEYS = ["libraryCatalogItemsV2", "libraryCatalogItems"];
  var COVER_RE = /^data:image\/(?:png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/;
  var HttpError = class extends Error {
    constructor(status3, message) {
      super(message);
      this.status = status3;
    }
  };
  var bad = (m) => new HttpError(400, m);
  var notFound = (w) => new HttpError(404, `${w} not found`);
  var conflict = (m) => new HttpError(409, m);
  function str(v, { name = "Field", max = 200, required = false } = {}) {
    const s = v == null ? "" : String(v).trim();
    if (required && !s) throw bad(`${name} is required`);
    if (s.length > max) throw bad(`${name} must be at most ${max} characters`);
    return s;
  }
  function int(v, { name = "Field", min = -Infinity, max = Infinity } = {}) {
    const n = Number(v);
    if (v === "" || v == null || !Number.isInteger(n)) throw bad(`${name} must be a whole number`);
    if (n < min || n > max) throw bad(`${name} must be between ${min} and ${max}`);
    return n;
  }
  function oneOf(v, list3, name) {
    if (!list3.includes(v)) throw bad(`${name} must be one of: ${list3.join(", ")}`);
    return v;
  }
  function dateStr(v, name) {
    if (!isDate(v)) throw bad(`${name} must be a date (YYYY-MM-DD)`);
    return v;
  }
  var lower = (s) => String(s || "").toLowerCase();
  var words = (q, max = 8) => lower(q).split(/\s+/).filter(Boolean).slice(0, max);
  var splitSubjects = (v) => (Array.isArray(v) ? v : String(v || "").split(",")).map((x) => String(x).trim()).filter(Boolean);
  function parseCover(v) {
    if (v === void 0) return void 0;
    if (v === null || v === "") return null;
    if (typeof v !== "string" || !COVER_RE.test(v)) throw bad("Cover must be a PNG, JPEG, WebP or GIF image");
    if (v.length > 1e6) throw bad("Cover image is too large");
    return v;
  }
  function parseTitle(b) {
    const subjects = splitSubjects(b.subjects);
    if (!subjects.length) throw bad("At least one subject is required");
    return {
      title: str(b.title, { name: "Title", max: 120, required: true }),
      subtitle: str(b.subtitle, { name: "Subtitle", max: 120 }),
      author: str(b.author, { name: "Author", max: 100, required: true }),
      isbn: str(b.isbn, { name: "ISBN", max: 30 }),
      publisher: str(b.publisher, { name: "Publisher", max: 100 }),
      year: int(b.year, { name: "Year", min: 1e3, max: 2100 }),
      edition: str(b.edition, { name: "Edition", max: 50 }),
      language: str(b.language, { name: "Language", max: 50 }) || "English",
      type: oneOf(b.type || "Book", TYPES, "Type"),
      subjects: subjects.join(", "),
      keywords: str(b.keywords, { name: "Keywords", max: 300 }),
      callNumber: str(b.callNumber, { name: "Call number", max: 50, required: true }),
      description: str(b.description, { name: "Description", max: 1e3 })
    };
  }
  function parseMember(b, current3) {
    const email = str(b.email, { name: "Email", max: 120 });
    if (email && !/^\S+@\S+\.\S+$/.test(email)) throw bad("Email doesn't look right");
    return {
      name: str(b.name, { name: "Name", max: 100, required: true }),
      email,
      phone: str(b.phone, { name: "Phone", max: 40 }),
      type: oneOf(b.type || "Student", MEMBER_TYPES, "Member type"),
      memberNo: str(b.memberNo, { name: "Member number", max: 30 }) || current3?.memberNo || "",
      active: b.active === void 0 ? current3 ? current3.active : true : !!b.active
    };
  }
  function validateInventory(d) {
    if (!d || typeof d !== "object" || Array.isArray(d)) throw Error("Inventory must be an object");
    const kinds = ["titles", "copies", "members", "loans", "reservations"];
    for (const k of kinds) if (!Array.isArray(d[k]) || d[k].length > 2e5) throw Error(`Invalid ${k} collection`);
    if (!d.seq || typeof d.seq !== "object") throw Error("Missing sequence counters");
    const ids = {};
    for (const k of kinds) {
      ids[k] = /* @__PURE__ */ new Set();
      for (const r of d[k]) {
        if (!r || !Number.isSafeInteger(r.id) || r.id < 1 || ids[k].has(r.id)) throw Error(`Invalid or duplicate ${k} ID`);
        ids[k].add(r.id);
      }
    }
    for (const [counter, kind] of Object.entries({ title: "titles", copy: "copies", member: "members", loan: "loans", res: "reservations" })) {
      if (!Number.isSafeInteger(d.seq[counter]) || d.seq[counter] < Math.max(0, ...ids[kind])) throw Error(`Invalid ${counter} sequence`);
    }
    const accession = /* @__PURE__ */ new Set(), memberNos = /* @__PURE__ */ new Set(), activeCopies = /* @__PURE__ */ new Set();
    for (const t of d.titles) if (typeof t.title !== "string" || !t.title.trim()) throw Error("Book title is missing");
    for (const m of d.members) {
      if (typeof m.name !== "string" || !m.name.trim()) throw Error("Member name is missing");
      if (m.memberNo) {
        const key = String(m.memberNo).toLowerCase();
        if (memberNos.has(key)) throw Error("Duplicate member number");
        memberNos.add(key);
      }
    }
    for (const c of d.copies) {
      if (!ids.titles.has(c.titleId)) throw Error("Book copy references a missing title");
      if (!["available", "on_loan", "lost", "damaged"].includes(c.status)) throw Error("Invalid book condition");
      if (typeof c.accessionNumber !== "string" || !c.accessionNumber.trim()) throw Error("Missing accession number");
      const key = c.accessionNumber.toLowerCase();
      if (accession.has(key)) throw Error("Duplicate accession number");
      accession.add(key);
    }
    for (const l of d.loans) {
      if (!ids.copies.has(l.copyId) || !ids.members.has(l.memberId)) throw Error("Loan references missing copy/member");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(l.dueAt || "") || !isDate(l.dueAt)) throw Error("Invalid loan due date");
      if (!l.returnedAt) {
        if (activeCopies.has(l.copyId)) throw Error("Multiple active loans for a copy");
        activeCopies.add(l.copyId);
      }
    }
    for (const c of d.copies) if (c.status === "on_loan" !== activeCopies.has(c.id)) throw Error("Copy/loan status mismatch");
    for (const r of d.reservations) if (!ids.titles.has(r.titleId) || !ids.members.has(r.memberId)) throw Error("Reservation references missing title/member");
    if (d.settings !== void 0) validateSettings(d.settings);
    return d;
  }
  function validateSettings(v) {
    if (!v || typeof v !== "object" || Array.isArray(v)) throw Error("Invalid settings");
    for (const [key, min, max] of [["loanDays", 1, 365], ["renewDays", 1, 365], ["maxRenewals", 0, 20], ["maxLoansPerMember", 1, 100], ["finePerDay", 0, 1e4]]) {
      if (!Number.isFinite(v[key]) || v[key] < min || v[key] > max || key !== "finePerDay" && !Number.isInteger(v[key])) throw Error(`Invalid setting: ${key}`);
    }
    return v;
  }
  function createBackend(storage2, { sample = true } = {}) {
    const CONFIG2 = { ...DEFAULT_CONFIG };
    const info = { migrated: 0 };
    let data;
    const blank = () => ({ version: 3, seq: { title: 0, copy: 0, member: 0, loan: 0, res: 0 }, titles: [], copies: [], members: [], loans: [], reservations: [], settings: { ...CONFIG2 }, activity: [] });
    const nid = (k) => ++data.seq[k];
    const stamp = () => (/* @__PURE__ */ new Date()).toISOString();
    function persist() {
      validateInventory(data);
      try {
        storage2.setItem(STORAGE_KEY, JSON.stringify(data));
      } catch (e) {
        throw new HttpError(507, `Unable to save inventory: ${e.message || "Unknown file error"}`);
      }
    }
    let currentAction = "change";
    function mutate(fn) {
      const snapshot = JSON.stringify(data);
      try {
        const r = fn();
        data.activity ||= [];
        data.activity.push({ at: stamp(), action: currentAction });
        if (data.activity.length > 1e4) data.activity.splice(0, data.activity.length - 1e4);
        persist();
        Object.assign(CONFIG2, data.settings);
        return r;
      } catch (e) {
        data = JSON.parse(snapshot);
        throw e;
      }
    }
    const accTaken = (a) => data.copies.some((c) => lower(c.accessionNumber) === lower(a));
    function nextAccession() {
      const year = (/* @__PURE__ */ new Date()).getFullYear();
      for (let n = data.copies.length + 1; ; n++) {
        const a = `ACC-${year}-${String(n).padStart(4, "0")}`;
        if (!accTaken(a)) return a;
      }
    }
    const memberNoTaken = (m) => data.members.some((x) => lower(x.memberNo) === lower(m));
    function nextMemberNo() {
      for (let n = data.members.length + 1; ; n++) {
        const m = `MEM-${String(n).padStart(4, "0")}`;
        if (!memberNoTaken(m)) return m;
      }
    }
    function insertTitle(v, cover) {
      const id = nid("title"), now = stamp();
      data.titles.push({ id, ...v, cover: cover || null, createdAt: now, updatedAt: now });
      return id;
    }
    function insertCopy(titleId, accessionNumber, location2, status3 = "available") {
      const c = { id: nid("copy"), titleId, accessionNumber, location: location2, status: status3, createdAt: stamp() };
      data.copies.push(c);
      return c;
    }
    function insertMember(v) {
      const m = { id: nid("member"), memberNo: v.memberNo || nextMemberNo(), name: v.name, email: v.email || "", phone: v.phone || "", type: v.type || "Student", active: v.active !== false, createdAt: stamp() };
      data.members.push(m);
      return m;
    }
    const find = (list3, id) => list3.find((x) => x.id === id);
    const openLoans = () => data.loans.filter((l) => !l.returnedAt);
    const unpaidOf = (memberId) => data.loans.reduce((s, l) => s + (l.memberId === memberId && l.fine > 0 && !l.finePaid ? l.fine : 0), 0);
    const availableCount = (titleId) => data.copies.filter((c) => c.titleId === titleId && c.status === "available").length;
    const activeQueue = (titleId) => data.reservations.filter((r) => r.titleId === titleId && r.status === "active").sort((a, b) => a.id - b.id);
    function index() {
      const now = today(), byTitle = /* @__PURE__ */ new Map(), res = /* @__PURE__ */ new Map(), over = /* @__PURE__ */ new Map(), copyTitle = /* @__PURE__ */ new Map();
      for (const c of data.copies) {
        copyTitle.set(c.id, c.titleId);
        if (!byTitle.has(c.titleId)) byTitle.set(c.titleId, []);
        byTitle.get(c.titleId).push(c);
      }
      for (const r of data.reservations) if (r.status === "active") res.set(r.titleId, (res.get(r.titleId) || 0) + 1);
      for (const l of data.loans) if (!l.returnedAt && l.dueAt < now) {
        const t = copyTitle.get(l.copyId);
        over.set(t, (over.get(t) || 0) + 1);
      }
      return { byTitle, res, over };
    }
    function titleRow(t, ix) {
      const copies = ix.byTitle.get(t.id) || [];
      const available = copies.filter((c) => c.status === "available").length;
      const reservations = ix.res.get(t.id) || 0;
      return {
        id: t.id,
        title: t.title,
        subtitle: t.subtitle,
        author: t.author,
        isbn: t.isbn,
        publisher: t.publisher,
        year: t.year,
        edition: t.edition,
        language: t.language,
        type: t.type,
        subjects: splitSubjects(t.subjects),
        keywords: t.keywords,
        callNumber: t.callNumber,
        description: t.description,
        hasCover: !!t.cover,
        coverUrl: t.cover || "",
        createdAt: t.createdAt,
        updatedAt: t.updatedAt,
        copiesTotal: copies.length,
        copiesAvailable: available,
        copiesOnLoan: copies.filter((c) => c.status === "on_loan").length,
        reservations,
        overdue: ix.over.get(t.id) || 0,
        free: Math.max(0, available - reservations),
        _accessions: copies.map((c) => c.accessionNumber).join(" "),
        _locations: copies.map((c) => c.location).join(" ")
      };
    }
    const publicRow = ({ _accessions, _locations, ...row }) => row;
    function memberStats() {
      const now = today(), s = /* @__PURE__ */ new Map();
      const get2 = (id) => {
        if (!s.has(id)) s.set(id, { activeLoans: 0, overdueLoans: 0, unpaidFines: 0, accruingFines: 0 });
        return s.get(id);
      };
      for (const l of data.loans) {
        const m = get2(l.memberId);
        if (!l.returnedAt) {
          m.activeLoans++;
          if (l.dueAt < now) {
            m.overdueLoans++;
            m.accruingFines += daysBetween(l.dueAt, now) * CONFIG2.finePerDay;
          }
        } else if (l.fine > 0 && !l.finePaid) m.unpaidFines += l.fine;
      }
      return (id) => s.get(id) || { activeLoans: 0, overdueLoans: 0, unpaidFines: 0, accruingFines: 0 };
    }
    const memberRow = (m, stats) => ({ id: m.id, memberNo: m.memberNo, name: m.name, email: m.email, phone: m.phone, type: m.type, active: m.active, createdAt: m.createdAt, ...stats(m.id) });
    function loanRow(l, maps) {
      const copy = maps.copy.get(l.copyId), title = maps.title.get(copy.titleId), member = maps.member.get(l.memberId);
      const now = today(), days = !l.returnedAt && l.dueAt < now ? daysBetween(l.dueAt, now) : 0;
      return {
        id: l.id,
        borrowedAt: l.borrowedAt,
        dueAt: l.dueAt,
        returnedAt: l.returnedAt,
        renewals: l.renewals,
        fine: l.fine,
        finePaid: l.finePaid,
        copyId: copy.id,
        accessionNumber: copy.accessionNumber,
        titleId: title.id,
        titleName: title.title,
        author: title.author,
        hasCover: !!title.cover,
        coverUrl: title.cover || "",
        titleUpdatedAt: title.updatedAt,
        memberId: member.id,
        memberName: member.name,
        memberNo: member.memberNo,
        daysOverdue: days,
        accruingFine: days * CONFIG2.finePerDay
      };
    }
    const loanMaps = () => ({
      copy: new Map(data.copies.map((c) => [c.id, c])),
      title: new Map(data.titles.map((t) => [t.id, t])),
      member: new Map(data.members.map((m) => [m.id, m]))
    });
    const oneLoan = (id) => loanRow(find(data.loans, id), loanMaps());
    const oneTitle = (id) => {
      const t = find(data.titles, id);
      return t && publicRow(titleRow(t, index()));
    };
    const oneMember = (id) => {
      const m = find(data.members, id);
      return m && memberRow(m, memberStats());
    };
    const cleanTitle = (t) => {
      const year = Number(t.year);
      return {
        title: String(t.title ?? "").trim().slice(0, 120),
        subtitle: String(t.subtitle ?? "").trim().slice(0, 120),
        author: String(t.author ?? "").trim().slice(0, 100),
        isbn: String(t.isbn ?? "").trim().slice(0, 30),
        publisher: String(t.publisher ?? "").trim().slice(0, 100),
        year: Number.isInteger(year) && year >= 1e3 && year <= 2100 ? year : (/* @__PURE__ */ new Date()).getFullYear(),
        edition: String(t.edition ?? "").trim().slice(0, 50),
        language: String(t.language ?? "").trim().slice(0, 50) || "English",
        type: TYPES.includes(t.type) ? t.type : "Book",
        subjects: splitSubjects(t.subjects ?? t.subject).join(", "),
        keywords: String(t.keywords ?? "").trim().slice(0, 300),
        callNumber: String(t.callNumber ?? "").trim().slice(0, 50),
        description: String(t.description ?? "").trim().slice(0, 1e3)
      };
    };
    const goodCover = (c) => typeof c === "string" && c.length < 1e6 && COVER_RE.test(c) ? c : null;
    const findOrCreateMember = (name) => {
      const clean = String(name).trim().slice(0, 100);
      return (data.members.find((m) => lower(m.name) === lower(clean)) || insertMember({ name: clean })).id;
    };
    function importLegacy(items, out) {
      for (const it of items) {
        if (!it || !String(it.title ?? "").trim() || !String(it.author ?? "").trim()) {
          out.skipped++;
          continue;
        }
        const acc = String(it.accessionNumber ?? "").trim().slice(0, 40);
        if (acc && accTaken(acc)) {
          out.skipped++;
          continue;
        }
        const titleId = insertTitle(cleanTitle(it), goodCover(it.cover));
        out.titles++;
        const n = Math.max(1, Math.min(200, Number(it.copies) || 1)), copies = [];
        for (let i = 0; i < n; i++) {
          let a = i === 0 && acc ? acc : acc ? `${acc}-${i + 1}` : nextAccession();
          if (accTaken(a)) a = nextAccession();
          copies.push(insertCopy(titleId, a, String(it.location ?? "").trim().slice(0, 80)));
          out.copies++;
        }
        const who = String(it.borrower ?? "").trim();
        if (it.status === "Checked Out" && who) {
          const borrowed = isDate(it.borrowDate) ? it.borrowDate : today();
          const due = isDate(it.dueDate) ? it.dueDate : addDays(borrowed, CONFIG2.loanDays);
          data.loans.push({ id: nid("loan"), copyId: copies[0].id, memberId: findOrCreateMember(who), borrowedAt: borrowed, dueAt: due < borrowed ? borrowed : due, returnedAt: null, renewals: 0, fine: 0, finePaid: false });
          copies[0].status = "on_loan";
        } else if (it.status === "Reserved" && who) {
          data.reservations.push({ id: nid("res"), titleId, memberId: findOrCreateMember(who), status: "active", createdAt: stamp() });
        }
      }
    }
    function importV2(b, out) {
      for (const m of Array.isArray(b.members) ? b.members : []) {
        if (!m || !String(m.name ?? "").trim()) {
          out.skipped++;
          continue;
        }
        const no = String(m.memberNo ?? "").trim().slice(0, 30);
        if (no && memberNoTaken(no)) {
          out.skipped++;
          continue;
        }
        insertMember({ memberNo: no, name: String(m.name).trim().slice(0, 100), email: String(m.email ?? "").slice(0, 120), phone: String(m.phone ?? "").slice(0, 40), type: MEMBER_TYPES.includes(m.type) ? m.type : "Student", active: m.active !== false });
        out.members++;
      }
      for (const t of Array.isArray(b.titles) ? b.titles : []) {
        if (!t || !String(t.title ?? "").trim() || !String(t.author ?? "").trim()) {
          out.skipped++;
          continue;
        }
        const copies = Array.isArray(t.copies) ? t.copies : [];
        if (copies.some((c) => c && accTaken(String(c.accessionNumber ?? "")))) {
          out.skipped++;
          continue;
        }
        const titleId = insertTitle(cleanTitle(t), goodCover(t.cover));
        out.titles++;
        for (const c of copies) {
          const a = String(c?.accessionNumber ?? "").trim().slice(0, 40) || nextAccession();
          if (accTaken(a)) continue;
          insertCopy(titleId, a, String(c?.location ?? "").slice(0, 80), ["lost", "damaged"].includes(c?.status) ? c.status : "available");
          out.copies++;
        }
      }
    }
    function seedSample() {
      const now = today();
      importLegacy([
        { title: "Introduction to Computing", subtitle: "Explorations in Language, Logic, and Machines", author: "David Evans", isbn: "978-0986977571", accessionNumber: "ACC-2026-001", publisher: "University of Virginia", year: 2024, edition: "2nd Edition", subject: ["Computer Science", "Programming"], keywords: "algorithms computing software beginner", callNumber: "QA76.6 E93 2024", status: "Available", type: "Book", location: "Shelf A-03", copies: 3, description: "An introductory resource covering computing, programming, and problem solving." },
        { title: "Database System Concepts", author: "Abraham Silberschatz", isbn: "978-0078022159", accessionNumber: "ACC-2026-002", publisher: "McGraw-Hill", year: 2020, edition: "7th Edition", subject: ["Databases", "Information Systems"], keywords: "sql database design normalization data", callNumber: "QA76.9.D3 S55 2020", status: "Checked Out", type: "Book", location: "Shelf A-07", copies: 2, borrower: "Juan Dela Cruz", borrowDate: addDays(now, -20), dueDate: addDays(now, -6), description: "A comprehensive textbook on database design, SQL, transactions, and data management." },
        { title: "The Philippine Islands", author: "Antonio de Morga", accessionNumber: "DIG-2026-003", publisher: "Digital Collection", year: 2018, subject: ["Philippine History", "Southeast Asia"], keywords: "philippines history culture colonial", callNumber: "DS674 M67 2018", status: "Available", type: "E-book", location: "Digital Collection", copies: 1, description: "A historical work about the early colonial Philippines." },
        { title: "Fundamentals of Computer Networks", author: "Larry Peterson", isbn: "978-0123850591", accessionNumber: "ACC-2026-004", publisher: "Morgan Kaufmann", year: 2022, edition: "6th Edition", subject: ["Networking", "Technology"], keywords: "tcp ip routing network protocols", callNumber: "TK5105.5 P48 2022", status: "Reserved", type: "Book", location: "Shelf B-02", copies: 2, borrower: "Maria Santos", description: "Covers network architecture, protocols, routing, transport, and applications." }
      ], { titles: 0, copies: 0, members: 0, skipped: 0 });
      insertMember({ name: "Ana Reyes", email: "ana.reyes@example.com", type: "Faculty" });
      insertMember({ name: "Paolo Garcia", email: "paolo.garcia@example.com", type: "Student" });
    }
    function readLegacy() {
      for (const k of LEGACY_KEYS) {
        try {
          const v = JSON.parse(storage2.getItem(k));
          if (Array.isArray(v) && v.length) return v;
        } catch {
        }
      }
      return null;
    }
    const saved = storage2.getItem(STORAGE_KEY);
    if (saved) {
      data = JSON.parse(saved);
      validateInventory(data);
    }
    if (!data || !Array.isArray(data.titles)) {
      data = blank();
      const legacy = readLegacy(), out = { titles: 0, copies: 0, members: 0, skipped: 0 };
      if (legacy) {
        importLegacy(legacy, out);
        info.migrated = out.titles;
      } else if (sample) seedSample();
      persist();
    }
    const routes = [];
    const route = (method, pattern, fn) => routes.push({ method, re: new RegExp("^" + pattern.replace(/:(\w+)/g, "(?<$1>[^/]+)") + "$"), fn });
    route("GET", "/config", () => ({ ...CONFIG2, ...data.settings }));
    route("PUT", "/config", ({ body }) => mutate(() => {
      data.settings = validateSettings({ ...CONFIG2, ...body });
      return { ...data.settings };
    }));
    route("GET", "/activity", () => (data.activity || []).slice(-500).reverse());
    route("GET", "/report", () => ({ generatedAt: stamp(), titles: data.titles, copies: data.copies, members: data.members, loans: data.loans, reservations: data.reservations }));
    route("GET", "/stats", () => {
      const ix = index(), now = today();
      let free = 0, allOut = 0, reserved = 0;
      for (const t of data.titles) {
        const row = titleRow(t, ix);
        if (row.free > 0) free++;
        if (row.copiesTotal > 0 && row.copiesAvailable === 0) allOut++;
        if (row.reservations > 0) reserved++;
      }
      const open = openLoans();
      return {
        titles: data.titles.length,
        titlesAvailable: free,
        titlesAllOut: allOut,
        titlesReserved: reserved,
        copies: data.copies.length,
        availableCopies: data.copies.filter((c) => c.status === "available").length,
        onLoan: data.copies.filter((c) => c.status === "on_loan").length,
        overdue: open.filter((l) => l.dueAt < now).length,
        members: data.members.filter((m) => m.active).length,
        unpaidFines: data.loans.reduce((s, l) => s + (l.fine > 0 && !l.finePaid ? l.fine : 0), 0)
      };
    });
    const SEARCH = {
      all: ["title", "subtitle", "author", "isbn", "publisher", "subjects", "keywords", "callNumber", "_accessions", "_locations"],
      title: ["title", "subtitle"],
      author: ["author"],
      isbn: ["isbn"],
      subject: ["subjects"],
      keywords: ["keywords"],
      callNumber: ["callNumber"],
      accessionNumber: ["_accessions"]
    };
    const collator = new Intl.Collator(void 0, { sensitivity: "base", numeric: true });
    const SORTS = {
      newest: (a, b) => b.id - a.id,
      titleAsc: (a, b) => collator.compare(a.title, b.title),
      titleDesc: (a, b) => collator.compare(b.title, a.title),
      authorAsc: (a, b) => collator.compare(a.author, b.author),
      yearDesc: (a, b) => b.year - a.year,
      yearAsc: (a, b) => a.year - b.year,
      callAsc: (a, b) => collator.compare(a.callNumber, b.callNumber)
    };
    const STATUS = {
      available: (r) => r.free > 0,
      checked_out: (r) => r.copiesTotal > 0 && r.copiesAvailable === 0,
      reserved: (r) => r.reservations > 0
    };
    route("GET", "/titles", ({ query }) => {
      const { q = "", field = "all", status: status3, type, sort = "newest" } = query;
      const cols = SEARCH[field] || SEARCH.all, terms = words(q);
      if (status3 && !STATUS[status3]) throw bad("Unknown status filter");
      const ix = index();
      return data.titles.map((t) => titleRow(t, ix)).filter((r) => {
        if (terms.length) {
          const hay = lower(cols.map((c) => r[c] instanceof Array ? r[c].join(" ") : r[c]).join(" "));
          if (!terms.every((w) => hay.includes(w))) return false;
        }
        if (status3 && !STATUS[status3](r)) return false;
        return !(type && type !== "all" && r.type !== type);
      }).sort(SORTS[sort] || SORTS.newest).map(publicRow);
    });
    route("GET", "/titles/:id", ({ p }) => {
      const title = oneTitle(p.id);
      if (!title) throw notFound("Title");
      const now = today();
      const loanOf = new Map(openLoans().map((l) => [l.copyId, l]));
      const copies = data.copies.filter((c) => c.titleId === p.id).sort((a, b) => collator.compare(a.accessionNumber, b.accessionNumber)).map((c) => {
        const l = loanOf.get(c.id), m = l && find(data.members, l.memberId);
        return { id: c.id, accessionNumber: c.accessionNumber, location: c.location, status: c.status, loanId: l?.id ?? null, dueAt: l?.dueAt ?? null, borrowedAt: l?.borrowedAt ?? null, renewals: l?.renewals ?? null, memberId: m?.id ?? null, memberName: m?.name ?? null, daysOverdue: l && l.dueAt < now ? daysBetween(l.dueAt, now) : 0 };
      });
      const queue = activeQueue(p.id).map((r, i) => {
        const m = find(data.members, r.memberId);
        return { id: r.id, memberId: m.id, memberName: m.name, memberNo: m.memberNo, createdAt: r.createdAt, position: i + 1 };
      });
      const copyIds = new Set(data.copies.filter((c) => c.titleId === p.id).map((c) => c.id));
      const maps = loanMaps();
      const history = data.loans.filter((l) => copyIds.has(l.copyId)).sort((a, b) => b.id - a.id).slice(0, 15).map((l) => {
        const r = loanRow(l, maps);
        return { id: r.id, borrowedAt: r.borrowedAt, dueAt: r.dueAt, returnedAt: r.returnedAt, fine: r.fine, accessionNumber: r.accessionNumber, memberId: r.memberId, memberName: r.memberName };
      });
      return { ...title, copies, queue, history };
    });
    route("POST", "/titles", ({ body }) => mutate(() => {
      const v = parseTitle(body);
      const cover = parseCover(body.cover) ?? null;
      const n = body.copies === void 0 ? 1 : int(body.copies, { name: "Copies", min: 0, max: 200 });
      const location2 = str(body.location, { name: "Location", max: 80 });
      const id = insertTitle(v, cover);
      for (let i = 0; i < n; i++) insertCopy(id, nextAccession(), location2);
      return oneTitle(id);
    }));
    route("PUT", "/titles/:id", ({ p, body }) => mutate(() => {
      const t = find(data.titles, p.id);
      if (!t) throw notFound("Title");
      const v = parseTitle(body), cover = parseCover(body.cover);
      Object.assign(t, v, { updatedAt: stamp() });
      if (cover !== void 0) t.cover = cover;
      return oneTitle(p.id);
    }));
    route("DELETE", "/titles/:id", ({ p }) => mutate(() => {
      if (!find(data.titles, p.id)) throw notFound("Title");
      const copies = data.copies.filter((c) => c.titleId === p.id), out = copies.filter((c) => c.status === "on_loan").length;
      if (out) throw conflict(`${out} ${out === 1 ? "copy is" : "copies are"} on loan. Return them before deleting this title.`);
      const ids = new Set(copies.map((c) => c.id));
      data.loans = data.loans.filter((l) => !ids.has(l.copyId));
      data.copies = data.copies.filter((c) => c.titleId !== p.id);
      data.reservations = data.reservations.filter((r) => r.titleId !== p.id);
      data.titles = data.titles.filter((t) => t.id !== p.id);
      return null;
    }));
    route("POST", "/titles/:id/copies", ({ p, body }) => mutate(() => {
      if (!find(data.titles, p.id)) throw notFound("Title");
      const acc = str(body.accessionNumber, { name: "Accession number", max: 40 }) || nextAccession();
      const location2 = str(body.location, { name: "Location", max: 80 });
      if (accTaken(acc)) throw conflict("That accession number is already in use.");
      const c = insertCopy(p.id, acc, location2);
      return { id: c.id, accessionNumber: acc, location: location2, status: "available" };
    }));
    route("PATCH", "/copies/:id", ({ p, body }) => mutate(() => {
      const c = find(data.copies, p.id);
      if (!c) throw notFound("Copy");
      const acc = body.accessionNumber === void 0 ? c.accessionNumber : str(body.accessionNumber, { name: "Accession number", max: 40, required: true });
      const location2 = body.location === void 0 ? c.location : str(body.location, { name: "Location", max: 80 });
      let status3 = c.status;
      if (body.status !== void 0 && body.status !== c.status) {
        if (c.status === "on_loan") throw conflict("This copy is on loan. Return it first.");
        status3 = oneOf(body.status, ["available", "lost", "damaged"], "Status");
      }
      if (data.copies.some((x) => x.id !== c.id && lower(x.accessionNumber) === lower(acc))) throw conflict("That accession number is already in use.");
      Object.assign(c, { accessionNumber: acc, location: location2, status: status3 });
      return { id: c.id, accessionNumber: acc, location: location2, status: status3 };
    }));
    route("DELETE", "/copies/:id", ({ p }) => mutate(() => {
      const c = find(data.copies, p.id);
      if (!c) throw notFound("Copy");
      if (c.status === "on_loan") throw conflict("This copy is on loan. Return it first.");
      data.loans = data.loans.filter((l) => l.copyId !== c.id);
      data.copies = data.copies.filter((x) => x.id !== c.id);
      return null;
    }));
    route("GET", "/members", ({ query }) => {
      const terms = words(query.q, 6), stats = memberStats();
      return data.members.filter((m) => (query.active !== "1" || m.active) && terms.every((w) => lower([m.name, m.memberNo, m.email, m.phone].join(" ")).includes(w))).sort((a, b) => collator.compare(a.name, b.name)).map((m) => memberRow(m, stats));
    });
    route("GET", "/members/:id", ({ p }) => {
      const member = oneMember(p.id);
      if (!member) throw notFound("Member");
      const maps = loanMaps();
      const loans = data.loans.filter((l) => l.memberId === p.id).sort((a, b) => !!a.returnedAt - !!b.returnedAt || b.id - a.id).slice(0, 100).map((l) => {
        const r = loanRow(l, maps);
        return { id: r.id, borrowedAt: r.borrowedAt, dueAt: r.dueAt, returnedAt: r.returnedAt, renewals: r.renewals, fine: r.fine, finePaid: r.finePaid, accessionNumber: r.accessionNumber, titleId: r.titleId, titleName: r.titleName, author: r.author, daysOverdue: r.daysOverdue, accruingFine: r.accruingFine };
      });
      const reservations = data.reservations.filter((r) => r.memberId === p.id && r.status === "active").sort((a, b) => a.id - b.id).map((r) => ({ id: r.id, titleId: r.titleId, titleName: find(data.titles, r.titleId).title, createdAt: r.createdAt }));
      return { ...member, loans, reservations };
    });
    route("POST", "/members", ({ body }) => mutate(() => {
      const v = parseMember(body);
      if (v.memberNo && memberNoTaken(v.memberNo)) throw conflict("That member number is already in use.");
      return oneMember(insertMember(v).id);
    }));
    route("PUT", "/members/:id", ({ p, body }) => mutate(() => {
      const m = find(data.members, p.id);
      if (!m) throw notFound("Member");
      const v = parseMember(body, m);
      if (data.members.some((x) => x.id !== m.id && lower(x.memberNo) === lower(v.memberNo))) throw conflict("That member number is already in use.");
      if (!v.active && m.active && openLoans().some((l) => l.memberId === m.id)) throw conflict("This member still has items on loan. Collect them before deactivating.");
      Object.assign(m, v);
      return oneMember(m.id);
    }));
    route("DELETE", "/members/:id", ({ p }) => mutate(() => {
      if (!find(data.members, p.id)) throw notFound("Member");
      if (data.loans.some((l) => l.memberId === p.id)) throw conflict("This member has loan history. Deactivate them instead to keep the records.");
      data.reservations = data.reservations.filter((r) => r.memberId !== p.id);
      data.members = data.members.filter((m) => m.id !== p.id);
      return null;
    }));
    route("POST", "/members/:id/fines/pay", ({ p }) => mutate(() => {
      if (!find(data.members, p.id)) throw notFound("Member");
      let paid = 0;
      for (const l of data.loans) if (l.memberId === p.id && l.fine > 0 && !l.finePaid) {
        paid += l.fine;
        l.finePaid = true;
      }
      return { paid };
    }));
    route("GET", "/loans", ({ query }) => {
      const { status: status3 = "active", memberId, q = "" } = query, now = today();
      if (!["active", "overdue", "returned", "all"].includes(status3)) throw bad("Unknown loan status");
      const maps = loanMaps(), terms = words(q, 6);
      return data.loans.filter((l) => status3 === "active" ? !l.returnedAt : status3 === "overdue" ? !l.returnedAt && l.dueAt < now : status3 === "returned" ? !!l.returnedAt : true).filter((l) => !memberId || l.memberId === Number(memberId)).map((l) => loanRow(l, maps)).filter((r) => {
        const hay = lower([r.titleName, r.memberName, r.memberNo, r.accessionNumber].join(" "));
        return terms.every((w) => hay.includes(w));
      }).sort(status3 === "returned" ? (a, b) => b.returnedAt.localeCompare(a.returnedAt) || b.id - a.id : status3 === "all" ? (a, b) => b.id - a.id : (a, b) => a.dueAt.localeCompare(b.dueAt) || a.id - b.id).slice(0, 500);
    });
    route("POST", "/loans", ({ body }) => mutate(() => {
      const memberId = int(body.memberId, { name: "Member" }), now = today();
      const dueAt = body.dueAt ? dateStr(body.dueAt, "Due date") : addDays(now, CONFIG2.loanDays);
      if (dueAt < now) throw bad("Due date can't be in the past");
      const member = find(data.members, memberId);
      if (!member) throw notFound("Member");
      if (!member.active) throw conflict(`${member.name} is deactivated and can't borrow.`);
      const unpaid = unpaidOf(memberId);
      if (unpaid > 0) throw conflict(`${member.name} has unpaid fines of ${CONFIG2.currency}${unpaid}. Collect payment first.`);
      const open = openLoans().filter((l) => l.memberId === memberId);
      if (open.length >= CONFIG2.maxLoansPerMember) throw conflict(`${member.name} already has ${open.length} items out (limit ${CONFIG2.maxLoansPerMember}).`);
      let copy;
      if (body.copyId) {
        copy = find(data.copies, Number(body.copyId));
        if (!copy) throw notFound("Copy");
        if (copy.status !== "available") throw conflict("That copy isn't available.");
      } else if (body.titleId) {
        const titleId2 = Number(body.titleId);
        if (!find(data.titles, titleId2)) throw notFound("Title");
        copy = data.copies.filter((c) => c.titleId === titleId2 && c.status === "available").sort((a, b) => collator.compare(a.accessionNumber, b.accessionNumber))[0];
        if (!copy) throw conflict("No copies of this title are available.");
      } else throw bad("Choose a copy or a title");
      const titleId = copy.titleId;
      const copiesOfTitle = new Set(data.copies.filter((c) => c.titleId === titleId).map((c) => c.id));
      if (open.some((l) => copiesOfTitle.has(l.copyId))) throw conflict(`${member.name} already has a copy of this title.`);
      const queue = activeQueue(titleId), free = availableCount(titleId), mine = queue.findIndex((r) => r.memberId === memberId);
      if (mine >= 0 ? mine >= free : queue.length >= free) throw conflict("The available copies are held for members in the reservation queue.");
      const loan = { id: nid("loan"), copyId: copy.id, memberId, borrowedAt: now, dueAt, returnedAt: null, renewals: 0, fine: 0, finePaid: false };
      data.loans.push(loan);
      copy.status = "on_loan";
      if (mine >= 0) queue[mine].status = "fulfilled";
      return oneLoan(loan.id);
    }));
    route("POST", "/loans/:id/return", ({ p }) => mutate(() => {
      const loan = find(data.loans, p.id);
      if (!loan) throw notFound("Loan");
      if (loan.returnedAt) throw conflict("This loan was already returned.");
      const now = today(), days = loan.dueAt < now ? daysBetween(loan.dueAt, now) : 0, fine = days * CONFIG2.finePerDay;
      Object.assign(loan, { returnedAt: now, fine, finePaid: fine === 0 });
      const copy = find(data.copies, loan.copyId);
      if (copy.status === "on_loan") copy.status = "available";
      return { loan: oneLoan(loan.id), fine, daysOverdue: days };
    }));
    route("POST", "/loans/:id/renew", ({ p }) => mutate(() => {
      const loan = find(data.loans, p.id);
      if (!loan) throw notFound("Loan");
      if (loan.returnedAt) throw conflict("This loan was already returned.");
      if (loan.dueAt < today()) throw conflict("Overdue items can't be renewed. Return the item first.");
      if (loan.renewals >= CONFIG2.maxRenewals) throw conflict(`This loan has reached the renewal limit (${CONFIG2.maxRenewals}).`);
      if (activeQueue(find(data.copies, loan.copyId).titleId).length) throw conflict("Someone is waiting for this title, so it can't be renewed.");
      loan.dueAt = addDays(loan.dueAt, CONFIG2.renewDays);
      loan.renewals++;
      return oneLoan(loan.id);
    }));
    route("POST", "/reservations", ({ body }) => mutate(() => {
      const titleId = int(body.titleId, { name: "Title" }), memberId = int(body.memberId, { name: "Member" });
      if (!find(data.titles, titleId)) throw notFound("Title");
      const member = find(data.members, memberId);
      if (!member) throw notFound("Member");
      if (!member.active) throw conflict(`${member.name} is deactivated.`);
      const queue = activeQueue(titleId);
      if (queue.some((r2) => r2.memberId === memberId)) throw conflict(`${member.name} is already in the queue for this title.`);
      const copiesOfTitle = new Set(data.copies.filter((c) => c.titleId === titleId).map((c) => c.id));
      if (openLoans().some((l) => l.memberId === memberId && copiesOfTitle.has(l.copyId))) throw conflict(`${member.name} already has this title on loan.`);
      if (availableCount(titleId) > queue.length) throw conflict("A copy is available now. Check it out instead.");
      const r = { id: nid("res"), titleId, memberId, status: "active", createdAt: stamp() };
      data.reservations.push(r);
      return { id: r.id };
    }));
    route("DELETE", "/reservations/:id", ({ p }) => mutate(() => {
      const r = find(data.reservations, p.id);
      if (!r) throw notFound("Reservation");
      if (r.status !== "active") throw conflict("This reservation is no longer active.");
      r.status = "cancelled";
      return null;
    }));
    route("GET", "/export", () => ({ format: "library-catalog-full", version: 3, exportedAt: stamp(), data: JSON.parse(JSON.stringify(data)) }));
    route("POST", "/import", ({ body }) => mutate(() => {
      if (typeof body !== "object" || body === null) throw bad("Send a JSON backup file");
      const out = { titles: 0, copies: 0, members: 0, skipped: 0 };
      if (Array.isArray(body)) importLegacy(body, out);
      else importV2(body, out);
      return out;
    }));
    route("POST", "/restore", ({ body }) => mutate(() => {
      const d = body?.format === "library-catalog-full" && body.data;
      if (!d || !["titles", "copies", "members", "loans", "reservations"].every((k) => Array.isArray(d[k])) || !d.seq) throw bad("That isn't a full backup file");
      validateInventory(d);
      data = { ...blank(), ...d, settings: { ...CONFIG2, ...d.settings }, activity: Array.isArray(d.activity) ? d.activity : [], version: 3 };
      return { titles: data.titles.length, members: data.members.length, loans: data.loans.length };
    }));
    route("POST", "/reset", ({ body }) => mutate(() => {
      data = blank();
      if (body?.sample) seedSample();
      return null;
    }));
    async function handle(method, url, body) {
      const [path, qs] = url.split("?");
      const query = Object.fromEntries(new URLSearchParams(qs || ""));
      for (const r of routes) {
        if (r.method !== method) continue;
        const m = r.re.exec(path);
        if (!m) continue;
        const p = Object.fromEntries(Object.entries(m.groups || {}).map(([k, v]) => [k, Number(v)]));
        currentAction = `${method} ${path}`;
        return r.fn({ p, query, body: body ?? {} });
      }
      throw notFound("Route");
    }
    if (data.settings) Object.assign(CONFIG2, data.settings);
    handle.info = info;
    handle._data = () => data;
    return handle;
  }

  // src/api.js
  var desktop = typeof window !== "undefined" && window.libraryDesktop;
  if (!desktop) throw Error("Desktop file storage unavailable. Launch using npm run desktop; browser-only storage is disabled.");
  var { storage, persistent } = { storage: desktop, persistent: true };
  var backend;
  function getBackend() {
    return backend ||= createBackend(storage);
  }
  var storageInfo = { persistent, migrated: 0, desktop: !!desktop };
  var api = (path, { method = "GET", body } = {}) => desktop.remote ? desktop.api(method, path, body) : getBackend()(method, path, body);
  if (desktop.onPhoneRequest) desktop.onPhoneRequest(async ({ method, route, body }) => {
    const result = await api(route, { method, body });
    window.dispatchEvent(new Event("library-scan-refresh"));
    return result;
  });
  var get = (p) => api(p);
  var post = (p, body = {}) => api(p, { method: "POST", body });
  var put = (p, body) => api(p, { method: "PUT", body });
  var patch = (p, body) => api(p, { method: "PATCH", body });
  var del = (p) => api(p, { method: "DELETE" });
  window.libraryAPI = api;

  // src/util.js
  var $ = (s, r = document) => r.querySelector(s);
  var $$ = (s, r = document) => [...r.querySelectorAll(s)];
  var reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var EASE = "cubic-bezier(.2,.8,.2,1)";
  var esc = (v) => String(v ?? "").replace(/[&<>'"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[c]);
  var addDays2 = (n, from = /* @__PURE__ */ new Date()) => addDays(iso(from), n);
  var fmtDate = (s) => {
    const d = /* @__PURE__ */ new Date(s + "T00:00");
    return isNaN(d) ? s : d.toLocaleDateString(void 0, { month: "short", day: "numeric", year: "numeric" });
  };
  var config = { currency: "\u20B1", loanDays: 14, finePerDay: 5 };
  var money = (n) => `${config.currency}${Number(n).toLocaleString()}`;
  function debounce(fn, ms = 150) {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), ms);
    };
  }
  var hue = (str2) => {
    let h = 0;
    for (const c of String(str2)) h = (h * 31 + c.charCodeAt(0)) % 360;
    return h;
  };
  var initials = (name) => String(name).split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
  var ICON = (p) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
  var TYPE_ICON = {
    "Book": ICON('<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>'),
    "E-book": ICON('<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>'),
    "DVD": ICON('<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>'),
    "Audiobook": ICON('<path d="M3 14v-2a9 9 0 0 1 18 0v2"/><path d="M21 15a2 2 0 0 1-2 2h-1v-6h1a2 2 0 0 1 2 2zM3 15a2 2 0 0 0 2 2h1v-6H5a2 2 0 0 0-2 2z"/>'),
    "Journal": ICON('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>'),
    "Other": ICON('<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3.3 7L12 12l8.7-5M12 22V12"/>')
  };
  var X_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>';
  var BOOK_ICON_LG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>';
  function coverHtml(t, mini = false) {
    const h = hue(t.title);
    const cls = mini ? "cover mini" : "cover";
    if (t.coverUrl) {
      return `<div class="${cls}" style="--h:${h}"><img src="${esc(t.coverUrl)}" alt="Cover of ${esc(t.title)}"></div>`;
    }
    return `<div class="${cls}" style="--h:${h}" aria-hidden="true"><span class="cover-type">${TYPE_ICON[t.type] || TYPE_ICON.Other}</span><span class="cover-title">${esc(t.title)}</span><span class="cover-author">${esc(t.author)}</span></div>`;
  }
  function shrinkImage(file, max = 480) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file), img = new Image();
      img.onload = () => {
        const s = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * s);
        c.height = Math.round(img.height * s);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("That image couldn't be read. Try another file."));
      };
      img.src = url;
    });
  }
  var store = { stats: null };
  var emit = (name) => document.dispatchEvent(new CustomEvent(name));
  var on = (name, fn) => document.addEventListener(name, fn);
  var changed = () => emit("data-changed");

  // src/ui.js
  var toastTimer;
  function toast(message, action) {
    clearTimeout(toastTimer);
    const el4 = $("#toast"), btn = $("#toastAction");
    $("#toastText").textContent = message;
    btn.hidden = !action;
    btn.onclick = null;
    if (action) {
      btn.textContent = action.label;
      btn.onclick = () => {
        action.run();
        el4.classList.remove("show");
      };
    }
    el4.classList.add("show");
    toastTimer = setTimeout(() => el4.classList.remove("show"), action ? 6e3 : 3200);
  }
  function shake(el4) {
    if (!el4) return;
    el4.focus?.();
    if (!reduced) el4.animate([{ transform: "translateX(0)" }, { transform: "translateX(-6px)" }, { transform: "translateX(6px)" }, { transform: "translateX(0)" }], { duration: 280 });
  }
  function countTo(el4, to) {
    const from = Number(el4.textContent) || 0;
    if (from === to || reduced) {
      el4.textContent = to;
      return;
    }
    const t0 = performance.now(), dur = 500;
    const step = (t) => {
      const p = Math.min((t - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      el4.textContent = Math.round(from + (to - from) * e);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  function segmented(container, onChange) {
    const pill = $(".seg-pill", container);
    const move = () => {
      const a = $(".seg.active", container);
      if (!a || !a.offsetWidth) return;
      pill.style.width = a.offsetWidth + "px";
      pill.style.transform = `translateX(${a.offsetLeft}px)`;
      if (!pill.classList.contains("ready")) requestAnimationFrame(() => pill.classList.add("ready"));
    };
    const set = (value) => {
      $$(".seg", container).forEach((b) => b.classList.toggle("active", b.dataset.value === value));
      move();
    };
    container.addEventListener("click", (e) => {
      const b = e.target.closest(".seg");
      if (!b || b.classList.contains("active")) return;
      set(b.dataset.value);
      onChange?.(b.dataset.value);
    });
    addEventListener("resize", move);
    document.fonts?.ready.then(move);
    move();
    return { move, set };
  }
  function openLayer(el4, focusSel) {
    clearTimeout(el4._t);
    el4._last = document.activeElement;
    el4.hidden = false;
    document.body.classList.add("locked");
    requestAnimationFrame(() => requestAnimationFrame(() => el4.classList.add("open")));
    setTimeout(() => (focusSel ? $(focusSel, el4) : $("[data-autofocus],input,select,textarea,button", el4))?.focus({ preventScroll: true }), 80);
  }
  function closeLayer(el4) {
    if (el4.hidden || !el4.classList.contains("open")) return;
    el4.classList.remove("open");
    el4._t = setTimeout(() => {
      el4.hidden = true;
      if (el4.dataset.temp) el4.remove();
      if (!$$(".layer.open").length) document.body.classList.remove("locked");
    }, reduced ? 0 : 220);
    el4._onClose?.();
    el4._onClose = null;
    el4._last?.focus?.({ preventScroll: true });
  }
  function makeLayer(kind, inner) {
    const el4 = document.createElement("div");
    el4.className = `layer layer-${kind}`;
    el4.dataset.temp = "1";
    el4.hidden = true;
    el4.innerHTML = `<div class="scrim" data-close></div>${inner}`;
    el4.addEventListener("click", (e) => {
      if (e.target.closest("[data-close]")) closeLayer(el4);
    });
    document.body.appendChild(el4);
    return el4;
  }
  function initLayers() {
    $("#drawer").addEventListener("click", (e) => {
      if (e.target.closest("[data-close]")) closeLayer($("#drawer"));
    });
    document.addEventListener("keydown", (e) => {
      const top = $$(".layer.open").pop();
      if (e.key === "Escape" && top) {
        closeLayer(top);
        return;
      }
      if (e.key === "Tab" && top) {
        const f = $$('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])', top).filter((n) => !n.disabled && !n.closest("[inert]") && n.offsetParent !== null);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    });
  }
  var drawer = () => $("#drawer");
  var drawerContent = () => $("#drawerContent");
  function openDrawer(html) {
    drawerContent().innerHTML = html;
    openLayer(drawer(), ".drawer-close");
  }
  var closeDrawer = () => closeLayer(drawer());
  var drawerIsOpen = () => drawer().classList.contains("open");
  function fieldHtml(f, values) {
    const val2 = values[f.name] ?? f.value ?? "";
    const attrs = `name="${f.name}"${f.required ? " required" : ""}${f.maxlength ? ` maxlength="${f.maxlength}"` : ""}${f.min != null ? ` min="${f.min}"` : ""}${f.max != null ? ` max="${f.max}"` : ""}${f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : ""}${f.autofocus ? " data-autofocus" : ""}`;
    let control;
    if (f.type === "select") {
      control = `<select ${attrs}>${f.options.map((o) => `<option value="${esc(o.value)}"${String(o.value) === String(val2) ? " selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`;
    } else if (f.type === "textarea") {
      control = `<textarea ${attrs} rows="${f.rows || 4}">${esc(val2)}</textarea>`;
    } else if (f.type === "file") {
      control = `<div class="image-upload"><input type="file" ${attrs} accept="image/png,image/jpeg,image/webp,image/gif" class="image-upload-input" id="upload-${f.name}"><label for="upload-${f.name}" class="image-upload-button">\uFF0B Choose book picture</label><div class="image-upload-preview" aria-live="polite"><span class="image-upload-placeholder">\u{1F4D6} No picture selected</span></div><button type="button" class="image-upload-clear" hidden>Remove picture</button></div>`;
    } else {
      control = `<input type="${f.type || "text"}" ${attrs} value="${esc(val2)}">`;
    }
    return `<label${f.span ? ` class="span-${f.span}"` : ""}>${esc(f.label)}${f.hint ? `<small>${esc(f.hint)}</small>` : ""}${control}</label>`;
  }
  function formDialog({ title, fields = [], values = {}, note = "", submitLabel = "Save", narrow = false, secondary = [], onSubmit, onClose }) {
    let body = "", open = false;
    for (const f of fields) {
      if (f.group) {
        if (open) body += "</div>";
        body += `<h3 class="group-title">${esc(f.group)}</h3><div class="fields">`;
        open = true;
        continue;
      }
      if (!open) {
        body += '<div class="fields">';
        open = true;
      }
      body += fieldHtml(f, values);
    }
    if (open) body += "</div>";
    if (note) body += `<p class="form-note">${esc(note)}</p>`;
    const left = secondary.length ? `<div class="foot-left">${secondary.map((s, i) => `<button class="btn${s.danger ? " btn-danger" : ""}" type="button" data-sec="${i}">${esc(s.label)}</button>`).join("")}</div>` : "";
    const el4 = makeLayer("center", `
    <section class="sheet${narrow ? " narrow" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="sheet-head"><h2>${esc(title)}</h2><button class="icon-btn" type="button" data-close aria-label="Close">${X_ICON}</button></div>
      <form novalidate>
        <div class="form-body">${body}</div>
        <div class="sheet-foot">${left}<p class="form-error" role="alert"></p><button class="btn" type="button" data-close>Cancel</button><button class="btn btn-primary" type="submit">${esc(submitLabel)}</button></div>
      </form>
    </section>`);
    el4._onClose = onClose;
    el4.querySelectorAll(".image-upload").forEach((widget) => {
      const input = widget.querySelector("input"), preview = widget.querySelector(".image-upload-preview");
      const clear = widget.querySelector(".image-upload-clear");
      let objectUrl;
      const reset = () => {
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = null;
        preview.innerHTML = '<span class="image-upload-placeholder">\u{1F4D6} No picture selected</span>';
        clear.hidden = true;
      };
      input.addEventListener("change", () => {
        reset();
        const file = input.files?.[0];
        if (!file) return;
        if (!file.type.startsWith("image/")) {
          input.value = "";
          return;
        }
        objectUrl = URL.createObjectURL(file);
        const img = document.createElement("img");
        img.src = objectUrl;
        img.alt = "Selected book cover preview";
        preview.replaceChildren(img);
        clear.hidden = false;
      });
      clear.addEventListener("click", () => {
        input.value = "";
        reset();
      });
      el4.addEventListener("transitionend", () => {
        if (el4.hidden && objectUrl) URL.revokeObjectURL(objectUrl);
      });
    });
    const form = $("form", el4), err = $(".form-error", el4), submit = $("button[type=submit]", el4);
    const fail = (msg) => {
      err.textContent = msg;
      shake(submit);
    };
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!form.checkValidity()) {
        form.classList.add("validated");
        form.querySelector(":invalid")?.focus();
        return;
      }
      submit.disabled = true;
      err.textContent = "";
      const data = {};
      new FormData(form).forEach((v, k) => {
        data[k] = v;
      });
      try {
        const keep = await onSubmit(data);
        if (keep !== false) closeLayer(el4);
      } catch (ex) {
        fail(ex.message);
      } finally {
        submit.disabled = false;
      }
    });
    $$("[data-sec]", el4).forEach((b) => b.addEventListener("click", async () => {
      const s = secondary[Number(b.dataset.sec)];
      b.disabled = true;
      err.textContent = "";
      try {
        if (await s.run() !== false) closeLayer(el4);
      } catch (ex) {
        fail(ex.message);
      } finally {
        b.disabled = false;
      }
    }));
    openLayer(el4, "[data-autofocus]");
    return el4;
  }
  function confirmDialog({ title, message, confirmLabel = "Confirm", danger = false }) {
    return new Promise((resolve) => {
      let answered = false;
      const el4 = formDialog({
        title,
        note: message,
        narrow: true,
        submitLabel: confirmLabel,
        onSubmit: () => {
          answered = true;
          resolve(true);
        },
        onClose: () => {
          if (!answered) resolve(false);
        }
      });
      if (danger) $("button[type=submit]", el4).classList.replace("btn-primary", "btn-danger");
    });
  }
  function showDrawer(html, keepScroll = false) {
    if (drawerIsOpen()) {
      const box = $(".drawer", drawer()), y = box.scrollTop;
      drawerContent().innerHTML = html;
      box.scrollTop = keepScroll ? y : 0;
    } else openDrawer(html);
  }
  function setEmpty(el4, show, { title = "", text = "", label = "", run } = {}) {
    el4.hidden = !show;
    if (!show) return;
    el4.innerHTML = `${BOOK_ICON_LG}<h2>${esc(title)}</h2><p>${esc(text)}</p>${label ? `<button class="btn" type="button">${esc(label)}</button>` : ""}`;
    const b = $("button", el4);
    if (b) b.onclick = run;
  }

  // src/actions.js
  async function memberOptions() {
    const members = await get("/members?active=1");
    if (!members.length) {
      toast("Add a member first, in the Members tab.");
      return null;
    }
    return members.map((m) => ({ value: m.id, label: `${m.name} (${m.memberNo})` }));
  }
  var dueField = () => ({ name: "dueAt", label: "Due date", type: "date", required: true, value: addDays2(config.loanDays) });
  async function checkoutCopy(copy, titleName) {
    const options = await memberOptions();
    if (!options) return;
    formDialog({
      title: "Check out",
      narrow: true,
      submitLabel: "Check out",
      note: `${titleName}, copy ${copy.accessionNumber}`,
      fields: [{ name: "memberId", label: "Member", type: "select", options, required: true, autofocus: true }, dueField()],
      onSubmit: async (d) => {
        await post("/loans", { copyId: copy.id, memberId: Number(d.memberId), dueAt: d.dueAt });
        toast("Checked out");
        changed();
      }
    });
  }
  async function checkoutAny() {
    const [options, titles] = await Promise.all([memberOptions(), get("/titles?status=available&sort=titleAsc")]);
    if (!options) return;
    if (!titles.length) {
      toast("No titles have a copy on the shelf right now.");
      return;
    }
    formDialog({
      title: "Check out",
      narrow: true,
      submitLabel: "Check out",
      fields: [
        { name: "titleId", label: "Title", type: "select", required: true, autofocus: true, options: titles.map((t) => ({ value: t.id, label: `${t.title} (${t.free} on shelf)` })) },
        { name: "memberId", label: "Member", type: "select", options, required: true },
        dueField()
      ],
      onSubmit: async (d) => {
        await post("/loans", { titleId: Number(d.titleId), memberId: Number(d.memberId), dueAt: d.dueAt });
        toast("Checked out");
        changed();
      }
    });
  }
  async function reserveTitle(titleId, titleName) {
    const options = await memberOptions();
    if (!options) return;
    formDialog({
      title: "Reserve",
      narrow: true,
      submitLabel: "Reserve",
      note: `${titleName}. The member is added to the waiting list.`,
      fields: [{ name: "memberId", label: "Member", type: "select", options, required: true, autofocus: true }],
      onSubmit: async (d) => {
        await post("/reservations", { titleId, memberId: Number(d.memberId) });
        toast("Reserved");
        changed();
      }
    });
  }
  async function returnLoan(loanId) {
    const r = await post(`/loans/${loanId}/return`);
    await window.libraryMotion?.returned(loanId);
    toast(r.fine > 0 ? `Returned ${r.daysOverdue} ${r.daysOverdue === 1 ? "day" : "days"} late. Fine of ${money(r.fine)} added.` : "Returned");
    changed();
  }
  async function renewLoan(loanId) {
    const r = await post(`/loans/${loanId}/renew`);
    toast(`Renewed until ${(/* @__PURE__ */ new Date(r.dueAt + "T00:00")).toLocaleDateString(void 0, { month: "short", day: "numeric" })}`);
    changed();
  }
  async function cancelReservation(id) {
    await del(`/reservations/${id}`);
    toast("Reservation cancelled");
    changed();
  }
  async function askDelete({ title, message, run, done }) {
    if (!await confirmDialog({ title, message, confirmLabel: "Delete", danger: true })) return;
    await run();
    done?.();
    changed();
  }

  // src/catalog.js
  var TYPES2 = ["Book", "E-book", "DVD", "Audiobook", "Journal", "Other"];
  var el = $("#view-catalog");
  var grid = $("#catalogGrid");
  var status = "all";
  var reqId = 0;
  var current = null;
  var dirty = true;
  var nodes = /* @__PURE__ */ new Map();
  function titleState(t) {
    const wait = t.reservations ? `, ${t.reservations} waiting` : "";
    if (t.copiesTotal === 0) return { cls: "", label: "No copies" };
    if (t.copiesAvailable === 0 && t.copiesOnLoan === 0 && t.copiesTotal > 0) return { cls: "", label: "Missing or damaged" };
    if (t.free > 0) return { cls: "available", label: t.copiesTotal > 1 ? `${t.free} of ${t.copiesTotal} on shelf` : "On shelf" };
    if (t.copiesAvailable > 0) return { cls: "reserved", label: "Held for reservation" };
    if (t.overdue > 0) return { cls: "overdue", label: "Overdue" + wait };
    return { cls: "checked-out", label: "All out" + wait };
  }
  var cardSig = (t) => JSON.stringify([t.title, t.author, t.type, t.callNumber, t.copiesTotal, t.copiesAvailable, t.reservations, t.overdue, t.updatedAt]);
  function cardInner(t) {
    const st = titleState(t);
    return `${coverHtml(t)}<div class="card-body"><h3 class="card-title">${esc(t.title)}</h3><p class="card-author">${esc(t.author)}</p><p class="card-meta"><span class="state ${st.cls}"><i></i><span>${esc(st.label)}</span></span></p></div>`;
  }
  function render(arr) {
    const before = /* @__PURE__ */ new Map();
    nodes.forEach((n, id) => before.set(id, n.getBoundingClientRect()));
    const keep = new Set(arr.map((t) => t.id));
    nodes.forEach((n, id) => {
      if (!keep.has(id)) {
        n.remove();
        nodes.delete(id);
      }
    });
    let k = 0;
    arr.forEach((t) => {
      let n = nodes.get(t.id);
      if (!n) {
        n = document.createElement("article");
        n.className = "card enter";
        n.tabIndex = 0;
        n.setAttribute("role", "button");
        n.dataset.id = t.id;
        n.style.setProperty("--d", Math.min(k++, 14) * 30 + "ms");
        n.addEventListener("animationend", () => n.classList.remove("enter"), { once: true });
        nodes.set(t.id, n);
      }
      const sig = cardSig(t);
      if (n.dataset.sig !== sig) {
        n.innerHTML = cardInner(t);
        n.dataset.sig = sig;
        n.setAttribute("aria-label", `${t.title} by ${t.author}. ${titleState(t).label}`);
      }
      grid.appendChild(n);
    });
    if (!reduced) {
      nodes.forEach((n, id) => {
        const a = before.get(id);
        if (!a) return;
        const b = n.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
        if (dx || dy) n.animate([{ transform: `translate(${dx}px,${dy}px)` }, { transform: "none" }], { duration: 380, easing: EASE });
      });
    }
  }
  var val = (id) => $("#" + id).value;
  var filtersActive = () => val("searchInput").trim() || val("searchField") !== "all" || val("typeFilter") !== "all" || status !== "all";
  var lastCount = 0;
  function updateText() {
    const s = store.stats, n = lastCount;
    $("#resultText").textContent = !n ? "" : filtersActive() ? `${n} of ${s ? s.titles : n} ${n === 1 ? "title" : "titles"}` : s ? `${s.titles} titles, ${s.copies} copies, ${s.onLoan} on loan${s.overdue ? `, ${s.overdue} overdue` : ""}` : `${n} titles`;
    $("#resetButton").hidden = !filtersActive();
  }
  function updateCounts() {
    if (!store.stats) return;
    $$("[data-count]", $("#statusSeg")).forEach((b) => countTo(b, store.stats[b.dataset.count] ?? 0));
    seg.move();
    updateText();
  }
  async function reload() {
    const id = ++reqId;
    const p = new URLSearchParams({ q: val("searchInput").trim(), field: val("searchField"), type: val("typeFilter"), sort: val("sortSelect") });
    if (status !== "all") p.set("status", status);
    let arr;
    try {
      arr = await get("/titles?" + p);
    } catch (ex) {
      toast(ex.message);
      return;
    }
    if (id !== reqId) return;
    dirty = false;
    lastCount = arr.length;
    render(arr);
    updateText();
    if (!arr.length) {
      const q = val("searchInput").trim();
      if (!store.stats || store.stats.titles === 0) setEmpty($("#catalogEmpty"), true, { title: "Your inventory is empty", text: "Add your first title to start building the collection.", label: "New title", run: () => createTitle() });
      else setEmpty($("#catalogEmpty"), true, { title: q ? `No match for \u201C${q}\u201D` : "Nothing found", text: "Try a different word, or clear the filters.", label: "Clear filters", run: resetFilters });
    } else setEmpty($("#catalogEmpty"), false);
  }
  function resetFilters() {
    $("#searchInput").value = "";
    $("#searchField").value = "all";
    $("#typeFilter").value = "all";
    $("#sortSelect").value = "newest";
    status = "all";
    seg.set("all");
    reload();
  }
  var seg = segmented($("#statusSeg"), (v) => {
    status = v;
    reload();
  });
  function copyRow(c) {
    const over = c.daysOverdue > 0;
    const state = c.status === "available" ? ["available", "Available"] : c.status === "lost" ? ["", "Missing"] : c.status === "damaged" ? ["", "Damaged"] : [over ? "overdue" : "checked-out", over ? `Overdue ${c.daysOverdue}d` : "Borrowed"];
    const sub = c.status === "on_loan" ? `<button class="link" data-act="t-member" data-id="${c.memberId}">${esc(c.memberName)}</button>, due ${fmtDate(c.dueAt)}` : esc(c.location || "No location set");
    const buttons = c.status === "available" ? `<button class="btn btn-sm btn-primary" data-act="t-checkout" data-copy="${c.id}">Check out</button><button class="btn btn-sm" data-act="t-editcopy" data-copy="${c.id}">Edit</button>` : c.status === "on_loan" ? `<button class="btn btn-sm btn-primary" data-act="t-return" data-copy="${c.id}">Return</button><button class="btn btn-sm" data-act="t-renew" data-copy="${c.id}">Renew</button>` : `<button class="btn btn-sm" data-act="t-editcopy" data-copy="${c.id}">Edit</button>`;
    return `<div class="copy"><div><strong>${esc(c.accessionNumber)}</strong><span class="copy-sub">${sub}</span></div>
    <div class="copy-actions"><span class="state ${state[0]}"><i></i><span>${state[1]}</span></span>${buttons}</div></div>`;
  }
  function drawerHtml(t) {
    const st = titleState(t);
    const canReserve = t.copiesTotal > 0 && t.free === 0;
    const rows = [["Call number", t.callNumber], ["ISBN", t.isbn || "Not set"], ["Publisher", t.publisher || "Not set"], ["Year", t.year], ["Edition", t.edition || "Not set"], ["Language", t.language], ["Material", t.type]];
    return `<div class="d-hero">${coverHtml(t)}<div>
      <h2 class="d-title">${esc(t.title)}</h2>${t.subtitle ? `<p class="d-sub">${esc(t.subtitle)}</p>` : ""}
      <p class="d-author">${esc(t.author)}</p><span class="state pill ${st.cls}"><i></i><span>${esc(st.label)}</span></span></div></div>
    ${t.subjects.length ? `<div class="tags">${t.subjects.map((s) => `<span class="tag">${esc(s)}</span>`).join("")}</div>` : ""}
    <div class="d-section"><div class="d-head"><h3>Copies (${t.copiesTotal})</h3><button class="btn btn-sm" data-act="t-addcopy">Add copy</button></div>
      ${t.copies.length ? t.copies.map(copyRow).join("") : '<p class="empty-line">No copies yet. Add one to make this title borrowable.</p>'}</div>
    ${t.queue.length || canReserve ? `<div class="d-section"><div class="d-head"><h3>Waiting list</h3>${canReserve ? '<button class="btn btn-sm" data-act="t-reserve">Reserve</button>' : ""}</div>
      ${t.queue.length ? t.queue.map((q) => `<div class="li"><span>${q.position}. <button class="link" data-act="t-member" data-id="${q.memberId}">${esc(q.memberName)}</button> <span class="muted">${esc(q.memberNo)}</span></span><button class="btn btn-sm" data-act="t-cancelres" data-id="${q.id}">Cancel</button></div>`).join("") : '<p class="empty-line">Nobody is waiting.</p>'}</div>` : ""}
    <div class="d-section"><h3>Details</h3><dl>${rows.map(([a, b]) => `<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join("")}</dl></div>
    ${t.description ? `<div class="d-section"><h3>About</h3><p class="d-desc">${esc(t.description)}</p></div>` : ""}
    ${t.history.length ? `<div class="d-section"><h3>Recent loans</h3>${t.history.map((h) => `<div class="li"><button class="link" data-act="t-member" data-id="${h.memberId}">${esc(h.memberName)}</button><span class="muted">${fmtDate(h.borrowedAt)} to ${h.returnedAt ? fmtDate(h.returnedAt) : "now"}${h.fine > 0 ? `, fine ${money(h.fine)}` : ""}</span></div>`).join("")}</div>` : ""}
    <div class="d-foot"><button class="btn" data-act="t-edit">Edit title</button><button class="btn btn-danger" data-act="t-delete">Delete title</button></div>`;
  }
  async function openTitle(id, keepScroll = false) {
    try {
      current = await get(`/titles/${id}`);
      showDrawer(drawerHtml(current), keepScroll);
      Object.assign(drawerContent().dataset, { kind: "title", id });
    } catch (ex) {
      toast(ex.message);
    }
  }
  drawerContent().addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act^='t-']");
    if (!b || !current) return;
    const id = Number(b.dataset.id), copy = current.copies.find((c) => c.id === Number(b.dataset.copy));
    try {
      switch (b.dataset.act) {
        case "t-checkout":
          await checkoutCopy(copy, current.title);
          break;
        case "t-return":
          await returnLoan(copy.loanId);
          break;
        case "t-renew":
          await renewLoan(copy.loanId);
          break;
        case "t-addcopy":
          addCopy();
          break;
        case "t-editcopy":
          editCopy(copy);
          break;
        case "t-reserve":
          await reserveTitle(current.id, current.title);
          break;
        case "t-cancelres":
          await cancelReservation(id);
          break;
        case "t-member":
          document.dispatchEvent(new CustomEvent("open-member", { detail: id }));
          break;
        case "t-edit":
          editTitle();
          break;
        case "t-delete":
          await askDelete({
            title: "Delete this title?",
            message: `\u201C${current.title}\u201D and its ${current.copiesTotal} ${current.copiesTotal === 1 ? "copy" : "copies"} will be removed, along with their loan history. This can't be undone.`,
            run: () => del(`/titles/${current.id}`),
            done: () => {
              closeDrawer();
              toast("Title deleted");
            }
          });
          break;
      }
    } catch (ex) {
      toast(ex.message);
    }
  });
  function addCopy() {
    formDialog({
      title: "Add copy",
      narrow: true,
      submitLabel: "Add copy",
      fields: [
        { name: "accessionNumber", label: "Accession number", hint: "Leave blank to generate one", maxlength: 40, autofocus: true },
        { name: "location", label: "Shelf or location", maxlength: 80, value: current.copies.at(-1)?.location || "" }
      ],
      onSubmit: async (d) => {
        await post(`/titles/${current.id}/copies`, d);
        toast("Copy added");
        changed();
      }
    });
  }
  function editCopy(copy) {
    formDialog({
      title: `Copy ${copy.accessionNumber}`,
      narrow: true,
      values: copy,
      fields: [
        { name: "accessionNumber", label: "Accession number", required: true, maxlength: 40, autofocus: true },
        { name: "location", label: "Shelf or location", maxlength: 80 },
        { name: "status", label: "Condition", type: "select", options: [{ value: "available", label: "In the collection" }, { value: "lost", label: "Missing" }, { value: "damaged", label: "Damaged" }] }
      ],
      secondary: [{
        label: "Remove copy",
        danger: true,
        run: async () => {
          await del(`/copies/${copy.id}`);
          toast("Copy removed");
          changed();
        }
      }],
      onSubmit: async (d) => {
        await patch(`/copies/${copy.id}`, d);
        toast("Copy updated");
        changed();
      }
    });
  }
  function titleFields(creating) {
    const f = [
      { group: "Basics" },
      { name: "title", label: "Title", required: true, span: 2, maxlength: 120, autofocus: true },
      { name: "subtitle", label: "Subtitle", maxlength: 120 },
      { name: "author", label: "Author or creator", required: true, maxlength: 100 },
      { name: "type", label: "Material type", type: "select", options: TYPES2.map((t) => ({ value: t, label: t })) },
      { name: "subjects", label: "Category / Subject", required: true, placeholder: "Science, Technology" },
      { name: "keywords", label: "Keywords", span: 3, placeholder: "Separate with spaces" },
      { group: "Publication" },
      { name: "isbn", label: "ISBN", maxlength: 30, placeholder: "978-\u2026" },
      { name: "publisher", label: "Publisher", maxlength: 100 },
      { name: "year", label: "Year", type: "number", required: true, min: 1e3, max: 2100, value: (/* @__PURE__ */ new Date()).getFullYear() },
      { name: "edition", label: "Edition", maxlength: 50, placeholder: "3rd edition" },
      { name: "language", label: "Language", maxlength: 50, value: "English" },
      { name: "cover", label: "Book picture / cover", type: "file", hint: creating ? "Click Choose book picture to add a cover (optional)" : "Choose a new picture to replace the existing cover" },
      { group: creating ? "Shelf and copies" : "Shelf" },
      { name: "callNumber", label: "Call number", required: true, maxlength: 50 }
    ];
    if (creating) f.push(
      { name: "location", label: "Shelf or location", maxlength: 80 },
      { name: "copies", label: "Number of copies", type: "number", required: true, min: 0, max: 200, value: 1, hint: "Each copy gets its own accession number" }
    );
    f.push({ group: "Description" }, { name: "description", label: "Abstract", type: "textarea", span: 3, maxlength: 1e3 });
    return f;
  }
  async function titlePayload(d, creating) {
    const p = {
      title: d.title,
      subtitle: d.subtitle,
      author: d.author,
      type: d.type,
      subjects: d.subjects,
      keywords: d.keywords,
      isbn: d.isbn,
      publisher: d.publisher,
      year: Number(d.year),
      edition: d.edition,
      language: d.language,
      callNumber: d.callNumber,
      description: d.description
    };
    if (creating) {
      p.copies = Number(d.copies);
      p.location = d.location;
    }
    if (d.cover && d.cover.size) p.cover = await shrinkImage(d.cover);
    return p;
  }
  function createTitle() {
    formDialog({
      title: "New title",
      submitLabel: "Add title",
      fields: titleFields(true),
      onSubmit: async (d) => {
        const t = await post("/titles", await titlePayload(d, true));
        toast("Title added");
        changed();
        openTitle(t.id);
      }
    });
  }
  function editTitle() {
    formDialog({
      title: "Edit title",
      submitLabel: "Save changes",
      fields: titleFields(false),
      values: { ...current, subjects: current.subjects.join(", ") },
      onSubmit: async (d) => {
        await put(`/titles/${current.id}`, await titlePayload(d, false));
        toast("Changes saved");
        changed();
      }
    });
  }
  grid.addEventListener("click", (e) => {
    const c = e.target.closest(".card");
    if (c) openTitle(Number(c.dataset.id));
  });
  grid.addEventListener("keydown", (e) => {
    if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("card")) {
      e.preventDefault();
      openTitle(Number(e.target.dataset.id));
    }
  });
  $("#searchInput").addEventListener("input", debounce(reload, 160));
  ["searchField", "typeFilter", "sortSelect"].forEach((id) => $("#" + id).addEventListener("change", reload));
  $("#resetButton").addEventListener("click", resetFilters);
  on("stats-updated", updateCounts);
  on("open-title", (e) => openTitle(e.detail));
  on("data-changed", () => {
    dirty = true;
    if (!el.hidden) reload();
    if (drawerIsOpen() && drawerContent().dataset.kind === "title") openTitle(Number(drawerContent().dataset.id), true);
  });
  var catalog_default = {
    el,
    primary: { label: "New title", run: createTitle },
    searchInput: $("#searchInput"),
    show() {
      seg.move();
      if (dirty) reload();
    }
  };

  // src/loans.js
  var el2 = $("#view-loans");
  var list = $("#loanList");
  var status2 = "active";
  var dirty2 = true;
  var reqId2 = 0;
  function dueCell(l) {
    if (l.returnedAt) {
      return `<span>Returned ${fmtDate(l.returnedAt)}</span><span class="sub">${l.fine > 0 ? `Fine ${money(l.fine)}, ${l.finePaid ? "paid" : "unpaid"}` : "No fine"}</span>`;
    }
    if (l.daysOverdue > 0) {
      return `<span class="state overdue"><i></i><span>${l.daysOverdue} ${l.daysOverdue === 1 ? "day" : "days"} overdue</span></span><span class="sub">Due ${fmtDate(l.dueAt)}, fine so far ${money(l.accruingFine)}</span>`;
    }
    return `<span>Due ${fmtDate(l.dueAt)}</span><span class="sub">Borrowed ${fmtDate(l.borrowedAt)}${l.renewals ? `, renewed ${l.renewals}x` : ""}</span>`;
  }
  function rowHtml(l, i, animate) {
    const t = { id: l.titleId, title: l.titleName, author: l.author, coverUrl: l.coverUrl };
    const actions = l.returnedAt ? "" : `<button class="btn btn-sm btn-primary" data-act="l-return" data-id="${l.id}">Return</button><button class="btn btn-sm" data-act="l-renew" data-id="${l.id}">Renew</button>`;
    return `<div class="row loan${animate ? " enter" : ""}" style="--d:${Math.min(i, 12) * 30}ms">
    <div>${coverHtml(t, true)}</div>
    <div class="cell"><button class="link" data-act="l-title" data-id="${l.titleId}">${esc(l.titleName)}</button><span class="sub">${esc(l.accessionNumber)}, ${esc(l.author)}</span></div>
    <div class="cell"><button class="link" data-act="l-member" data-id="${l.memberId}">${esc(l.memberName)}</button><span class="sub">${esc(l.memberNo)}</span></div>
    <div class="cell">${dueCell(l)}</div>
    <div class="cell actions">${actions}</div></div>`;
  }
  async function reload2(animate = false) {
    const id = ++reqId2;
    let arr;
    try {
      arr = await get(`/loans?status=${status2}&q=${encodeURIComponent($("#loanSearch").value.trim())}`);
    } catch (ex) {
      toast(ex.message);
      return;
    }
    if (id !== reqId2) return;
    dirty2 = false;
    list.innerHTML = arr.map((l, i) => rowHtml(l, i, animate)).join("");
    $("#loanResult").textContent = arr.length ? `${arr.length} ${arr.length === 1 ? "loan" : "loans"}` : "";
    const q = $("#loanSearch").value.trim();
    const msg = { active: ["Nothing is on loan", "Check an item out to see it here."], overdue: ["Nothing is overdue", "Every borrowed item is within its due date."], returned: ["No returns yet", "Returned items will be listed here."] }[status2];
    setEmpty($("#loanEmpty"), !arr.length, q ? { title: `No match for \u201C${q}\u201D`, text: "Try a title, a member name or an accession number." } : { title: msg[0], text: msg[1], label: status2 === "active" ? "Check out" : "", run: checkoutAny });
  }
  function updateCounts2() {
    if (!store.stats) return;
    $$("[data-count]", $("#loanSeg")).forEach((b) => countTo(b, store.stats[b.dataset.count] ?? 0));
    seg2.move();
  }
  var seg2 = segmented($("#loanSeg"), (v) => {
    status2 = v;
    reload2(true);
  });
  list.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act^='l-']");
    if (!b) return;
    const id = Number(b.dataset.id);
    try {
      switch (b.dataset.act) {
        case "l-return":
          b.disabled = true;
          try {
            await returnLoan(id);
            await reload2();
          } finally {
            b.disabled = false;
          }
          break;
        case "l-renew":
          await renewLoan(id);
          break;
        case "l-title":
          document.dispatchEvent(new CustomEvent("open-title", { detail: id }));
          break;
        case "l-member":
          document.dispatchEvent(new CustomEvent("open-member", { detail: id }));
          break;
      }
    } catch (ex) {
      toast(ex.message);
    }
  });
  $("#loanSearch").addEventListener("input", debounce(() => reload2(), 160));
  on("stats-updated", updateCounts2);
  on("data-changed", () => {
    dirty2 = true;
    if (!el2.hidden) reload2();
  });
  var loans_default = {
    el: el2,
    primary: { label: "Check out", run: () => checkoutAny().catch((ex) => toast(ex.message)) },
    searchInput: $("#loanSearch"),
    show() {
      status2 = "active";
      seg2.set("active");
      seg2.move();
      updateCounts2();
      reload2(true);
    }
  };

  // src/members.js
  var MEMBER_TYPES2 = ["Student", "Faculty", "Staff", "Public"];
  var el3 = $("#view-members");
  var list2 = $("#memberList");
  var current2 = null;
  var dirty3 = true;
  var reqId3 = 0;
  var avatar = (m, lg = false) => `<div class="avatar${lg ? " lg" : ""}" style="--h:${hue(m.name)}" aria-hidden="true">${esc(initials(m.name))}</div>`;
  function standing(m) {
    const owed = m.unpaidFines + m.accruingFines;
    if (owed > 0) return `<span class="state overdue"><i></i><span>Owes ${money(owed)}</span></span>`;
    if (!m.active) return `<span class="state"><i></i><span>Inactive</span></span>`;
    return `<span class="state available"><i></i><span>Good standing</span></span>`;
  }
  function rowHtml2(m, i, animate) {
    const loans = m.activeLoans ? `${m.activeLoans} on loan` : "No loans";
    return `<div class="row member${animate ? " enter" : ""}" style="--d:${Math.min(i, 12) * 30}ms" data-id="${m.id}" tabindex="0" role="button" aria-label="${esc(m.name)}">
    ${avatar(m)}
    <div class="cell"><strong>${esc(m.name)}</strong><span class="sub">${esc(m.memberNo)}, ${esc(m.type)}</span></div>
    <div class="cell"><span>${loans}</span>${m.overdueLoans ? `<span class="sub">${m.overdueLoans} overdue</span>` : ""}</div>
    <div class="cell">${standing(m)}</div></div>`;
  }
  async function reload3(animate = true) {
    const id = ++reqId3, q = $("#memberSearch").value.trim();
    let arr;
    try {
      arr = await get(`/members?q=${encodeURIComponent(q)}`);
    } catch (ex) {
      toast(ex.message);
      return;
    }
    if (id !== reqId3) return;
    dirty3 = false;
    list2.innerHTML = arr.map((m, i) => rowHtml2(m, i, animate)).join("");
    $("#memberResult").textContent = arr.length ? `${arr.length} ${arr.length === 1 ? "member" : "members"}` : "";
    setEmpty($("#memberEmpty"), !arr.length, q ? { title: `No match for \u201C${q}\u201D`, text: "Try a name, member number, email or phone." } : { title: "No members yet", text: "Add the people who borrow from your library.", label: "New member", run: createMember });
  }
  function loanLine(l) {
    const late = l.daysOverdue > 0;
    return `<div class="li"><span><button class="link" data-act="m-title" data-id="${l.titleId}">${esc(l.titleName)}</button>
      <span class="copy-sub">${esc(l.accessionNumber)}, ${late ? `<span class="state overdue"><span>${l.daysOverdue}d overdue, ${money(l.accruingFine)} so far</span></span>` : `due ${fmtDate(l.dueAt)}`}</span></span>
    <span class="copy-actions"><button class="btn btn-sm btn-primary" data-act="m-return" data-id="${l.id}">Return</button><button class="btn btn-sm" data-act="m-renew" data-id="${l.id}">Renew</button></span></div>`;
  }
  function drawerHtml2(m) {
    const open = m.loans.filter((l) => !l.returnedAt);
    const past = m.loans.filter((l) => l.returnedAt).slice(0, 10);
    const owed = m.unpaidFines > 0 || m.accruingFines > 0;
    return `<div class="d-hero person">${avatar(m, true)}<div>
      <h2 class="d-title">${esc(m.name)}</h2><p class="d-sub">${esc(m.memberNo)}, ${esc(m.type)}</p>
      <p style="margin-top:10px"><span class="state pill ${m.active ? "available" : ""}"><i></i><span>${m.active ? "Active" : "Inactive"}</span></span></p></div></div>
    ${owed ? `<div class="notice"><div><strong>Unpaid fines ${money(m.unpaidFines)}</strong>${m.accruingFines > 0 ? `<small>${money(m.accruingFines)} more accruing on overdue items</small>` : ""}</div>${m.unpaidFines > 0 ? '<button class="btn btn-sm" data-act="m-pay">Mark as paid</button>' : ""}</div>` : ""}
    <div class="d-section"><h3>Contact</h3><dl><dt>Email</dt><dd>${esc(m.email || "Not set")}</dd><dt>Phone</dt><dd>${esc(m.phone || "Not set")}</dd><dt>Member since</dt><dd>${fmtDate(m.createdAt.slice(0, 10))}</dd></dl></div>
    <div class="d-section"><h3>Currently borrowed (${open.length})</h3>${open.length ? open.map(loanLine).join("") : '<p class="empty-line">Nothing on loan.</p>'}</div>
    ${m.reservations.length ? `<div class="d-section"><h3>Reservations</h3>${m.reservations.map((r) => `<div class="li"><button class="link" data-act="m-title" data-id="${r.titleId}">${esc(r.titleName)}</button><button class="btn btn-sm" data-act="m-cancelres" data-id="${r.id}">Cancel</button></div>`).join("")}</div>` : ""}
    ${past.length ? `<div class="d-section"><h3>History</h3>${past.map((l) => `<div class="li"><button class="link" data-act="m-title" data-id="${l.titleId}">${esc(l.titleName)}</button><span class="muted">${fmtDate(l.borrowedAt)} to ${fmtDate(l.returnedAt)}${l.fine > 0 ? `, fine ${money(l.fine)}${l.finePaid ? " paid" : ""}` : ""}</span></div>`).join("")}</div>` : ""}
    <div class="d-foot"><button class="btn" data-act="m-edit">Edit</button><button class="btn" data-act="m-toggle">${m.active ? "Deactivate" : "Reactivate"}</button><button class="btn btn-danger" data-act="m-delete">Delete</button></div>`;
  }
  async function openMember(id, keepScroll = false) {
    try {
      current2 = await get(`/members/${id}`);
      showDrawer(drawerHtml2(current2), keepScroll);
      Object.assign(drawerContent().dataset, { kind: "member", id });
    } catch (ex) {
      toast(ex.message);
    }
  }
  drawerContent().addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act^='m-']");
    if (!b || !current2) return;
    const id = Number(b.dataset.id);
    try {
      switch (b.dataset.act) {
        case "m-return":
          await returnLoan(id);
          break;
        case "m-renew":
          await renewLoan(id);
          break;
        case "m-cancelres":
          await cancelReservation(id);
          break;
        case "m-title":
          document.dispatchEvent(new CustomEvent("open-title", { detail: id }));
          break;
        case "m-pay": {
          const r = await post(`/members/${current2.id}/fines/pay`);
          toast(`${money(r.paid)} marked as paid`);
          changed();
          break;
        }
        case "m-edit":
          memberForm(current2);
          break;
        case "m-toggle": {
          const { name, email, phone, type, memberNo, active: active2 } = current2;
          await put(`/members/${current2.id}`, { name, email, phone, type, memberNo, active: !active2 });
          toast(active2 ? "Member deactivated" : "Member reactivated");
          changed();
          break;
        }
        case "m-delete":
          await askDelete({
            title: "Delete this member?",
            message: `${current2.name} will be removed. Members with loan history can't be deleted; deactivate them instead.`,
            run: () => del(`/members/${current2.id}`),
            done: () => {
              closeDrawer();
              toast("Member deleted");
            }
          });
          break;
      }
    } catch (ex) {
      toast(ex.message);
    }
  });
  function memberForm(m = null) {
    formDialog({
      title: m ? "Edit member" : "New member",
      narrow: true,
      submitLabel: m ? "Save changes" : "Add member",
      values: m || {},
      fields: [
        { name: "name", label: "Full name", required: true, maxlength: 100, autofocus: true },
        { name: "memberNo", label: "Member number", maxlength: 30, hint: m ? "" : "Leave blank to generate one" },
        { name: "type", label: "Member type", type: "select", options: MEMBER_TYPES2.map((t) => ({ value: t, label: t })), value: "Student" },
        { name: "email", label: "Email", type: "email", maxlength: 120 },
        { name: "phone", label: "Phone", maxlength: 40 }
      ],
      onSubmit: async (d) => {
        if (m) {
          await put(`/members/${m.id}`, d);
          toast("Changes saved");
          changed();
        } else {
          const created = await post("/members", d);
          toast("Member added");
          changed();
          openMember(created.id);
        }
      }
    });
  }
  var createMember = () => memberForm();
  list2.addEventListener("click", (e) => {
    const r = e.target.closest(".row");
    if (r) openMember(Number(r.dataset.id));
  });
  list2.addEventListener("keydown", (e) => {
    if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("row")) {
      e.preventDefault();
      openMember(Number(e.target.dataset.id));
    }
  });
  $("#memberSearch").addEventListener("input", debounce(() => reload3(false), 160));
  on("open-member", (e) => openMember(e.detail));
  on("data-changed", () => {
    dirty3 = true;
    if (!el3.hidden) reload3(false);
    if (drawerIsOpen() && drawerContent().dataset.kind === "member") openMember(Number(drawerContent().dataset.id), true);
  });
  var members_default = {
    el: el3,
    primary: { label: "New member", run: createMember },
    searchInput: $("#memberSearch"),
    show() {
      if (dirty3) reload3(true);
    }
  };

  // src/main.js
  var extraView = (id, label, show) => ({ el: document.querySelector("#view-" + id), primary: { label, run: show }, searchInput: document.querySelector("#scannerInput"), show });
  var views = { dashboard: extraView("dashboard", "Refresh", renderDashboard), catalog: catalog_default, loans: loans_default, members: members_default, reports: extraView("reports", "Refresh", renderReports), scanner: extraView("scanner", "Find book", () => document.querySelector("#scannerInput").focus()) };
  var active = "dashboard";
  var authUnlocked = false;
  initLayers();
  var tabs = segmented($("#tabs"), (v) => {
    location.hash = v;
  });
  function go(name) {
    if (!views[name]) name = "dashboard";
    if (!authUnlocked) return;
    active = name;
    Object.entries(views).forEach(([k, v]) => {
      v.el.hidden = k !== name;
    });
    tabs.set(name);
    $("#primaryLabel").textContent = views[name].primary.label;
    const label = name === "catalog" ? "Library Inventory" : name[0].toUpperCase() + name.slice(1);
    document.title = `${label} \xB7 Library Inventory`;
    views[name].show();
  }
  addEventListener("hashchange", () => go(location.hash.slice(1)));
  $("#primaryAction").addEventListener("click", async () => {
    try {
      await views[active].primary.run();
    } catch (ex) {
      toast(ex.message);
    }
  });
  async function refreshStats() {
    try {
      store.stats = await get("/stats");
      emit("stats-updated");
    } catch {
    }
  }
  on("data-changed", refreshStats);
  $("#themeToggle").addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try {
      localStorage.setItem("libraryCatalogTheme", next);
    } catch {
    }
  });
  var topbar = $("#topbar");
  var onScroll = () => topbar.classList.toggle("scrolled", scrollY > 8);
  addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  $("#exportButton").addEventListener("click", async () => {
    try {
      const blob = new Blob([JSON.stringify(await get("/export"))], { type: "application/json" });
      const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `library-catalog-${today()}.json` });
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
      toast("Backup downloaded");
    } catch (ex) {
      toast(ex.message);
    }
  });
  $("#importButton").addEventListener("click", () => $("#importFile").click());
  $("#importFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      const json = JSON.parse(await file.text());
      if (json && json.format === "library-catalog-full") {
        const ok = await confirmDialog({ title: "Restore this backup?", message: "Everything currently in the inventory will be replaced by the contents of the backup file.", confirmLabel: "Restore", danger: true });
        if (!ok) return;
        const r = await post("/restore", json);
        Object.assign(config, await get("/config"));
        toast(`Restored ${r.titles} titles, ${r.members} members and ${r.loans} loans`);
      } else {
        const r = await post("/import", json);
        const parts = [r.titles && `${r.titles} titles`, r.copies && `${r.copies} copies`, r.members && `${r.members} members`].filter(Boolean);
        toast(parts.length ? `Imported ${parts.join(", ")}${r.skipped ? `, skipped ${r.skipped}` : ""}` : "Nothing new to import");
      }
      changed();
    } catch (ex) {
      toast(ex instanceof SyntaxError ? "That file isn't valid JSON." : ex.message);
    }
  });
  $("#eraseButton").addEventListener("click", async () => {
    const ok = await confirmDialog({ title: "Erase all data?", message: "Every title, copy, member and loan will be deleted from this browser. Export a backup first if you might need it.", confirmLabel: "Erase everything", danger: true });
    if (!ok) return;
    try {
      await post("/reset", { sample: false });
      toast("All data erased");
      changed();
    } catch (ex) {
      toast(ex.message);
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector(".layer.open")) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)) return;
    if (e.key === "/" && views[active].searchInput) {
      e.preventDefault();
      views[active].searchInput.focus();
    } else if (e.key.toLowerCase() === "n") {
      e.preventDefault();
      $("#primaryAction").click();
    }
  });
  $("#footerYear").textContent = (/* @__PURE__ */ new Date()).getFullYear();
  $("#saveNote").textContent = storageInfo.desktop ? "Saved automatically to the MySQL database" : storageInfo.persistent ? "Saved automatically in this browser" : "Not saved: this browser is blocking storage";
  (async () => {
    if (storageInfo.migrated) toast(`Moved ${storageInfo.migrated} titles over from your previous inventory`);
    else if (!storageInfo.persistent) toast("Changes won't be kept. Use Export backup before closing this tab.");
  })();
  var toolsBtn = document.querySelector("#toolsButton");
  toolsBtn?.addEventListener("click", async () => {
    const old = document.querySelector("#desktopTools");
    if (old) {
      old.remove();
      return;
    }
    const box = document.createElement("section");
    box.id = "desktopTools";
    box.className = "tools-dialog";
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-labelledby", "toolsTitle");
    const previousFocus = document.activeElement;
    const closeTools = () => {
      box.remove();
      document.removeEventListener("keydown", toolsKeys);
      previousFocus?.focus();
    };
    const toolsKeys = (e) => {
      if (document.querySelector(".layer.open")) return;
      if (e.key === "Escape") closeTools();
      if (e.key === "Tab") {
        const items = [...box.querySelectorAll("button,input")].filter((x) => !x.disabled);
        if (e.shiftKey && document.activeElement === items[0]) {
          e.preventDefault();
          items.at(-1).focus();
        } else if (!e.shiftKey && document.activeElement === items.at(-1)) {
          e.preventDefault();
          items[0].focus();
        }
      }
    };
    document.addEventListener("keydown", toolsKeys);
    box.innerHTML = `<div class="tools-shell"><header class="tools-header"><div><span class="eyebrow">WORKSPACE PREFERENCES</span><h2 id="toolsTitle">Settings & backups</h2></div><button class="btn" id="toolClose" type="button" aria-label="Close settings">Close \u2715</button></header><div class="tools-body"><section class="tools-card"><h3>Borrowing rules</h3><div id="toolSettings"></div></section><section class="tools-card"><h3>Account security</h3><p>Keep your recovery key somewhere safe.</p><form id="securityForm" class="settings-grid"><label>Current password<input name="current" type="password" required autocomplete="current-password"></label><label>New password<input name="next" type="password" minlength="8" maxlength="256" autocomplete="new-password"></label><label>Confirm new password<input name="confirm" type="password" autocomplete="new-password"></label><button class="btn" name="change">Change password</button><button class="btn" name="recovery">Generate recovery key</button></form></section><section class="tools-card"><h3>Backups & recovery</h3><p>Save or restore a backup.</p><div class="tools-actions"><button class="btn btn-primary" id="toolExport">Export backup</button><button class="btn" id="toolImport">Import backup</button><button class="btn" id="toolBackups">View database snapshots</button></div></section><section class="tools-card"><h3>Reports & activity</h3><div class="tools-actions"><button class="btn" id="toolPrint">Print inventory</button><button class="btn" id="toolLogs">View activity log</button></div></section><div id="toolOutput" class="tools-output" role="status" aria-live="polite"></div></div></div>`;
    document.body.append(box);
    box.querySelector("#toolClose").onclick = closeTools;
    box.querySelector("#toolClose").focus();
    box.querySelector("#toolExport").onclick = () => $("#exportButton").click();
    box.querySelector("#toolImport").onclick = () => {
      closeTools();
      $("#importButton").click();
    };
    const output = box.querySelector("#toolOutput");
    box.querySelector("#securityForm").onsubmit = async (e) => {
      e.preventDefault();
      const f = e.currentTarget;
      try {
        if (e.submitter.name === "recovery") {
          const r = await window.libraryDesktop.account("recovery", { current: f.elements.current.value });
          output.textContent = "Save this recovery key offline. Generating another key invalidates this one: " + r.recoveryKey;
        } else {
          if (f.elements.next.value !== f.elements.confirm.value) throw Error("New passwords do not match");
          await window.libraryDesktop.account("change", { current: f.elements.current.value, password: f.elements.next.value });
          output.textContent = "Password changed.";
        }
        f.reset();
      } catch (err) {
        output.textContent = err.message;
      }
    };
    try {
      const cfg = await get("/config");
      const keys = ["loanDays", "renewDays", "maxRenewals", "maxLoansPerMember", "finePerDay"];
      const labels = ["Loan days", "Renewal days", "Maximum renewals", "Maximum active loans", "Fine per overdue day (\u20B1)"];
      const form = document.createElement("form");
      form.className = "settings-grid";
      keys.forEach((k, i) => {
        const label = document.createElement("label");
        label.textContent = labels[i] + " ";
        const input = document.createElement("input");
        input.type = "number";
        input.name = k;
        input.min = k === "maxRenewals" || k === "finePerDay" ? "0" : "1";
        input.max = k === "finePerDay" ? "10000" : "365";
        input.value = cfg[k];
        input.step = k === "finePerDay" ? "0.01" : "1";
        input.required = true;
        label.append(input);
        form.append(label);
      });
      const submit = document.createElement("button");
      submit.textContent = "Save rules";
      submit.className = "btn btn-primary";
      form.append(submit);
      box.querySelector("#toolSettings").append(form);
      form.onsubmit = async (e) => {
        e.preventDefault();
        try {
          const obj = Object.fromEntries(keys.map((k) => [k, Number(form.elements[k].value)]));
          Object.assign(config, await put("/config", obj));
          output.textContent = "Borrowing rules saved.";
          toast("Borrowing rules saved");
        } catch (err) {
          output.textContent = err.message;
        }
      };
    } catch (e) {
      output.textContent = e.message;
    }
    box.querySelector("#toolLogs").onclick = async () => {
      try {
        output.textContent = (await get("/activity")).map((x) => `${x.at}  ${x.action}`).join("\n") || "No transactions recorded yet.";
      } catch (e) {
        output.textContent = e.message;
      }
    };
    box.querySelector("#toolBackups").onclick = async () => {
      try {
        const backups = await window.libraryDesktop.backups();
        output.replaceChildren();
        for (const b of backups) {
          const line = document.createElement("div");
          line.className = "backup-row";
          line.textContent = b.name + (b.valid ? " \u2014 Verified" : " \u2014 CORRUPT: " + b.error) + " ";
          if (b.valid) {
            const btn = document.createElement("button");
            btn.textContent = "Restore";
            btn.className = "btn btn-sm";
            btn.onclick = async () => {
              if (!await confirmDialog({ title: "Restore snapshot?", message: "Replace current inventory with " + b.name + "? Current data is saved as a recovery snapshot.", confirmLabel: "Restore", danger: true })) return;
              try {
                await window.libraryDesktop.restoreBackup(b.name);
                location.reload();
              } catch (e) {
                alert(e.message);
              }
            };
            line.append(btn);
          }
          output.append(line);
        }
        if (!backups.length) output.textContent = "No backup snapshots yet.";
        const note = document.createElement("p");
        note.textContent = "Keep a backup on a USB drive.";
        output.append(note);
      } catch (e) {
        output.textContent = e.message;
      }
    };
    box.querySelector("#toolPrint").onclick = async () => {
      try {
        const r = await get("/report");
        const win = window.open("", "_blank");
        if (!win) {
          output.textContent = "Enable print popups in this app.";
          return;
        }
        const esc2 = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
        win.document.write(`<title>Library inventory report</title><style>body{font:14px Arial;margin:30px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #999;padding:5px;text-align:left}</style><h1>Library inventory report</h1><p>Generated ${esc2(r.generatedAt)} \xB7 Titles: ${r.titles.length} \xB7 Copies: ${r.copies.length} \xB7 Members: ${r.members.length} \xB7 Loans: ${r.loans.length}</p><table><tr><th>Accession / Barcode</th><th>Title</th><th>Location</th><th>Condition</th></tr>${r.copies.map((c) => `<tr><td>${esc2(c.accessionNumber)}</td><td>${esc2(r.titles.find((t) => t.id === c.titleId)?.title)}</td><td>${esc2(c.location)}</td><td>${esc2(c.status)}</td></tr>`).join("")}</table>`);
        win.document.close();
        win.focus();
        win.print();
      } catch (e) {
        output.textContent = e.message;
      }
    };
  });
  window.libraryQuickActions = {
    borrow(copy, title) {
      checkoutCopy(copy, title.title || "Book");
    },
    async returnCopy(copy) {
      try {
        const active2 = await get("/loans?status=active&q=" + encodeURIComponent(copy.accessionNumber));
        const loan = active2.find((l) => l.copyId === copy.id || l.accessionNumber === copy.accessionNumber);
        if (!loan) {
          toast("No active loan found for this copy");
          return;
        }
        if (!await confirmDialog({ title: "Return this book?", message: "Confirm return of " + copy.accessionNumber + "; any overdue fine will be calculated.", confirmLabel: "Return book" })) return;
        await returnLoan(loan.id);
      } catch (e) {
        toast(e.message);
      }
    }
  };
  on("data-changed", () => window.dispatchEvent(new Event("library-scan-refresh")));
  var escapeHtml = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  function cards(items) {
    return items.map(([name, value]) => `<article class="dash-card"><span>${escapeHtml(name)}</span><strong>${escapeHtml(value)}</strong></article>`).join("");
  }
  async function renderDashboard() {
    try {
      const [s, activity, report] = await Promise.all([get("/stats"), get("/activity"), get("/report")]);
      $("#dashboardCards").innerHTML = cards([["Book titles", s.titles], ["Physical copies", s.copies], ["Available copies", s.availableCopies], ["Currently borrowed", s.onLoan], ["Overdue loans", s.overdue], ["Active members", s.members], ["Unpaid fines", "\u20B1" + s.unpaidFines]]);
      renderDashboardInsights(report);
      $("#dashboardActivity").innerHTML = activity.length ? activity.slice(0, 15).map((a) => `<p><time>${escapeHtml(a.at)}</time> \u2014 ${escapeHtml(a.action)}</p>`).join("") : "No recent activity.";
    } catch (e) {
      $("#dashboardActivity").textContent = e.message;
    }
  }
  function renderDashboardInsights(r) {
    const host = $("#dashboardInsights");
    if (!host) return;
    const now = today(), soon = addDays(today(), 3);
    const overdue = r.loans.filter((l) => !l.returnedAt && l.dueAt < now), dueSoon = r.loans.filter((l) => !l.returnedAt && l.dueAt >= now && l.dueAt <= soon);
    const months = Array.from({ length: 6 }, (_, i) => {
      const d = /* @__PURE__ */ new Date(today().slice(0, 7) + "-01T00:00:00Z");
      d.setUTCMonth(d.getUTCMonth() - 5 + i);
      return { key: d.toISOString().slice(0, 7), label: d.toLocaleString(void 0, { month: "short", timeZone: "Asia/Manila" }) };
    });
    const counts = months.map((m) => r.loans.filter((l) => String(l.borrowedAt || "").startsWith(m.key)).length), max = Math.max(1, ...counts);
    host.innerHTML = `<div class="insight-alerts"><h3>Circulation alerts</h3><p><strong>${overdue.length}</strong> overdue loan${overdue.length === 1 ? "" : "s"} \xB7 <strong>${dueSoon.length}</strong> due in the next 3 days</p><button class="btn" id="alertsLoans">Review borrowing records \u2192</button></div><div class="insight-chart"><h3>Borrowing trend \xB7 last 6 months</h3><div class="chart-bars" role="img" aria-label="Monthly loans: ${months.map((m, i) => m.label + " " + counts[i]).join(", ")}">${months.map((m, i) => `<div class="chart-col"><b>${counts[i]}</b><span style="height:${Math.max(4, counts[i] / max * 112)}px"></span><small>${m.label}</small></div>`).join("")}</div></div>`;
    $("#alertsLoans").onclick = () => location.hash = "loans";
  }
  var reportRows = [];
  async function renderReports() {
    try {
      const from = $("#reportFrom").value, to = $("#reportTo").value;
      if (from && to && from > to) {
        toast("From date must be before the To date");
        return false;
      }
      const r = await get("/report");
      const titles = new Map(r.titles.map((t) => [t.id, t]));
      const copies = new Map(r.copies.map((c) => [c.id, c]));
      const members = new Map(r.members.map((m) => [m.id, m]));
      reportRows = r.loans.map((l) => {
        const c = copies.get(l.copyId) || {};
        return { borrowed: l.borrowedAt || l.loanedAt || l.createdAt || "", returned: l.returnedAt || "", due: l.dueAt || "", title: titles.get(c.titleId)?.title || "Unknown", accession: c.accessionNumber || "", member: members.get(l.memberId)?.name || "Unknown", status: l.returnedAt ? "Returned" : l.dueAt && l.dueAt < today() ? "Overdue" : "On loan" };
      }).filter((x) => (!from || x.borrowed.slice(0, 10) >= from) && (!to || x.borrowed.slice(0, 10) <= to)).reverse();
      $("#reportSummary").innerHTML = cards([["Transactions", reportRows.length], ["Active", reportRows.filter((x) => x.status === "On loan").length], ["Returned", reportRows.filter((x) => x.status === "Returned").length], ["Overdue", reportRows.filter((x) => x.status === "Overdue").length]]);
      const headers = ["Borrowed", "Book", "Accession", "Borrower", "Due", "Returned", "Status"];
      $("#reportHistory").innerHTML = reportRows.length ? '<div class="report-scroll"><table class="report-table"><thead><tr>' + headers.map((h) => "<th>" + h + "</th>").join("") + "</tr></thead><tbody>" + reportRows.slice(0, 500).map((r2) => "<tr>" + [r2.borrowed, r2.title, r2.accession, r2.member, r2.due, r2.returned, r2.status].map((x) => "<td>" + escapeHtml(x) + "</td>").join("") + "</tr>").join("") + "</tbody></table></div>" + (reportRows.length > 500 ? "<p>Showing first 500 rows; CSV contains all matching records.</p>" : "") : '<div class="report-empty"><h3>No circulation records</h3><p>No borrowing records match these dates. Change the date range or check out a book.</p></div>';
      return true;
    } catch (e) {
      $("#reportHistory").textContent = e.message;
      return false;
    }
  }
  $("#reportRefresh").onclick = renderReports;
  $("#reportCsv").onclick = async () => {
    if (!await renderReports()) return;
    const fields = ["borrowed", "title", "accession", "member", "due", "returned", "status"];
    const csv = [fields, ...reportRows.map((r) => fields.map((k) => r[k]))].map((row) => row.map((v) => '"' + String(v ?? "").replace(/"/g, '""') + '"').join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "library-circulation-" + today() + ".csv";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };
  $("#scannerForm").onsubmit = async (e) => {
    e.preventDefault();
    const code = $("#scannerInput").value.trim().toLowerCase();
    if (!code) return;
    try {
      const r = await get("/report"), c = r.copies.find((x) => String(x.accessionNumber).toLowerCase() === code);
      const target = $("#scannerResult");
      if (!c) {
        target.textContent = "No matching accession number found.";
        return;
      }
      const t = r.titles.find((x) => x.id === c.titleId);
      target.innerHTML = "<h2>" + escapeHtml(t?.title || "Unknown title") + "</h2><p>Accession: " + escapeHtml(c.accessionNumber) + "</p><p>Status: " + escapeHtml(c.status) + "</p><p>Location: " + escapeHtml(c.location || "Not specified") + '</p><button class="btn btn-primary" id="scanCatalog">Open catalog</button>';
      $("#scanCatalog").onclick = () => {
        location.hash = "catalog";
        setTimeout(() => {
          $("#searchInput").value = c.accessionNumber;
          $("#searchField").value = "accessionNumber";
          $("#searchInput").dispatchEvent(new Event("input", { bubbles: true }));
        }, 30);
      };
    } catch (err) {
      $("#scannerResult").textContent = err.message;
    }
  };
  var auth = $("#authScreen");
  var recovering = false;
  function setRecovery(value) {
    recovering = value;
    $("#recoveryFields").hidden = !value;
    $("#recoveryBack").hidden = !value;
    $("#recoverAccount").hidden = value;
    $("#authPasswordLabel").hidden = value;
    const password = $("#authPassword");
    password.required = !value;
    password.disabled = value;
    password.value = "";
    password.type = "password";
    password.closest(".password-wrap").hidden = value;
    $("#passwordToggle").textContent = "Show";
    $("#passwordToggle").setAttribute("aria-label", "Show password");
    for (const i of $("#recoveryFields").querySelectorAll("input")) {
      i.required = value;
      i.disabled = !value;
      i.value = "";
    }
    $("#authTitle").textContent = value ? "Recover your account" : "Welcome back";
    $("#authHelp").textContent = value ? "Use your offline recovery key to create a new administrator password." : "Enter your administrator password to unlock the library.";
    $("#authPasswordHint").textContent = value ? "Choose a new password with at least 8 characters." : "Your library data stays on this computer.";
    $("#authSubmit").textContent = value ? "Reset password" : "Sign in";
    $("#authError").textContent = "";
    (value ? $("#recoveryKey") : password).focus();
  }
  $("#recoverAccount").onclick = () => setRecovery(true);
  $("#recoveryBack").onclick = () => setRecovery(false);
  for (const input of $("#recoveryFields").querySelectorAll("input")) input.disabled = true;
  async function checkAuth() {
    try {
      const state = await window.libraryDesktop.authState();
      auth.hidden = state.authenticated;
      $("#recoverAccount").hidden = state.setupRequired;
      authUnlocked = state.authenticated;
      $("#authTitle").textContent = state.setupRequired ? "Create your account" : "Welcome back";
      $("#authPasswordHint").textContent = state.setupRequired ? "Choose a password with at least 8 characters." : "Your library data stays on this computer.";
      $("#authHelp").textContent = state.setupRequired ? "First launch: create an administrator password (8+ characters)." : "Enter your administrator password to unlock the library.";
      $("#authSubmit").textContent = state.setupRequired ? "Create administrator" : "Sign in";
      if (state.authenticated) {
        Object.assign(config, await get("/config"));
        await refreshStats();
        go(location.hash.slice(1) || "dashboard");
      }
    } catch (e) {
      $("#authError").textContent = e.message;
    }
  }
  $("#authForm").onsubmit = async (e) => {
    e.preventDefault();
    $("#authError").textContent = "";
    try {
      const state = await window.libraryDesktop.authState();
      if (recovering) {
        if ($("#recoveryPassword").value !== $("#recoveryConfirm").value) throw Error("New passwords do not match");
        await window.libraryDesktop.account("reset", { key: $("#recoveryKey").value, password: $("#recoveryPassword").value });
        setRecovery(false);
        toast("Password reset. Generate a new recovery key in Settings.");
      } else await window.libraryDesktop.auth(state.setupRequired ? "setup" : "login", $("#authPassword").value);
      $("#authPassword").value = "";
      await checkAuth();
    } catch (err) {
      $("#authError").textContent = err.message;
    }
  };
  $("#logoutButton").onclick = async () => {
    await window.libraryDesktop.auth("logout");
    await checkAuth();
  };
  checkAuth();
  on("data-changed", () => {
    if (active === "dashboard") renderDashboard();
    if (active === "reports") renderReports();
  });
  document.querySelector("#passwordToggle")?.addEventListener("click", () => {
    const i = document.querySelector("#authPassword"), b = document.querySelector("#passwordToggle");
    i.type = i.type === "password" ? "text" : "password";
    b.textContent = i.type === "password" ? "Show" : "Hide";
    b.setAttribute("aria-label", i.type === "password" ? "Show password" : "Hide password");
  });
  document.querySelector("#heroCatalog")?.addEventListener("click", () => {
    location.hash = "catalog";
  });
  document.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => {
    location.hash = b.dataset.go;
  }));
  window.libraryDesktop.onSaveStatus((detail) => {
    const e = { detail };
    const el4 = $("#saveStatus");
    el4.dataset.failed = String(!e.detail.ok);
    el4.textContent = e.detail.ok ? "Saved to MySQL \xB7 " + (/* @__PURE__ */ new Date()).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" }) : "Save failed: " + e.detail.error;
  });
})();
