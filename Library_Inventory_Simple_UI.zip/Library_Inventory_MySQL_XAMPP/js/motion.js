/* Shared lightweight motion. Transactions call this only after a successful save. */
(()=>{
 const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
 const play=async(el,frames,duration=200)=>{
  if(!el||reduced()||!el.animate)return;
  try{const a=el.animate(frames,{duration,easing:'cubic-bezier(.2,.8,.2,1)'});await a.finished;}catch{}
 };
 window.libraryMotion={
  async returned(id){
   const nodes=new Set([...document.querySelectorAll('[data-act="l-return"], [data-act="m-return"]')].filter(b=>Number(b.dataset.id)===Number(id)).map(b=>b.closest('.row,.li')));
   await Promise.all([...nodes].map(el=>play(el,[{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(-6px)'}],200)));
  },
  scan(el){return play(el,[{opacity:.4,transform:'translateY(5px)',boxShadow:'0 0 0 2px #39865b'},{opacity:1,transform:'translateY(0)',boxShadow:'0 0 0 2px transparent'}],280);}
 };
 // Keep native details semantics and keyboard behavior; animate both directions.
 document.addEventListener('click',async e=>{
  const summary=e.target.closest('.qr-title-group > summary');
  if(!summary||reduced()||!summary.parentElement.animate)return;
  const group=summary.parentElement,content=group.querySelector('.qr-title-content');
  if(!content)return;
  e.preventDefault();
  if(group.dataset.moving)return;
  group.dataset.moving='true';
  const opening=!group.open;
  if(opening)group.open=true;
  group.dataset.expanding=String(opening);
  // Allow the existing lazy QR renderer to populate before measuring.
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  const h=content.getBoundingClientRect().height;
  content.style.overflow='hidden';
  await play(content,opening?[{height:'0px',opacity:0},{height:h+'px',opacity:1}]:[{height:h+'px',opacity:1},{height:'0px',opacity:0}],230);
  if(!opening)group.open=false;
  content.style.removeProperty('overflow');
  delete group.dataset.moving;delete group.dataset.expanding;
 });
})();
