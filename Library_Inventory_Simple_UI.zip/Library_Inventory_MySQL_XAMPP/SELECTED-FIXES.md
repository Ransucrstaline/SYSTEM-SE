# Accuracy, saving and account security update

- Dashboard availability counts only copies marked available, excluding borrowed, lost and damaged copies.
- Circulation, report overdue labels, due-soon alerts, monthly chart boundaries and daily backup names consistently use the Asia/Manila calendar.
- Restoring a full JSON backup applies its borrowing and fine rules immediately, including checkout form defaults. Failed saves roll back data and leave the active rules unchanged.
- The save indicator confirms successful JSON writes or displays the actual file error. Startup does not continue with an unsaved initial inventory.
- Settings & backups includes Account security. Enter the current password to change it, or generate an offline recovery key. Copy that key to a safe place outside the computer. Generating a new key invalidates the previous key.
- Forgot password on the login screen accepts the recovery key and a confirmed new password. Recovery preserves inventory. A successful reset consumes the key; generate a new one afterward. Recovery keys are stored as salted hashes, never plaintext. Existing passwords remain valid after this upgrade.
- If no recovery key was generated before the password was forgotten, this recovery flow cannot unlock the account. Inventory backups do not include administrator credentials.

## Run
Extract the ZIP. Open the library-inventory-static folder in a terminal, run npm install, then npm start. Keep the same Windows account and app identity to retain existing app data. The records are in the application's data folder, not inside this ZIP.

## Validation
All 25 automated tests pass. Tests cover circulation persistence, correct availability, Manila date boundaries, immediate restored rules, failed-save rollback, password verification and one-time recovery. JavaScript bundle rebuilt; desktop entrypoint and preload syntax checks passed. Native Electron interface was not manually tested in this environment.
