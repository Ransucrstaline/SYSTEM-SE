-- Optional manual schema import using phpMyAdmin. Startup also creates these tables.
CREATE DATABASE IF NOT EXISTS library_inventory CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library_inventory;
CREATE TABLE IF NOT EXISTS metadata (`key` VARCHAR(80) PRIMARY KEY, value LONGTEXT NOT NULL) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS titles (id BIGINT PRIMARY KEY, record LONGTEXT NOT NULL) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS copies LIKE titles;
CREATE TABLE IF NOT EXISTS members LIKE titles;
CREATE TABLE IF NOT EXISTS loans LIKE titles;
CREATE TABLE IF NOT EXISTS reservations LIKE titles;
CREATE TABLE IF NOT EXISTS activity LIKE titles;
CREATE TABLE IF NOT EXISTS inventory_backups (name VARCHAR(80) PRIMARY KEY, inventory LONGTEXT NOT NULL) ENGINE=InnoDB;
