# Library Inventory — desktop file-storage edition (no SQL)

## Windows setup
1. Install Node.js LTS.
2. In this extracted folder, run `npm install`.
3. Run `npm run build` to rebuild the browser bundle after source edits.
4. Run `npm run desktop` to open the desktop application.
5. Optional: run `npm run package:win` on Windows to create a portable Windows executable in `release/`. The ZIP does not contain a prebuilt EXE.

## Where are records saved?
Electron saves `inventory.json` under its userData folder in `library-records`. The footer confirms desktop file saving. Automatic backups live in the `backups` subfolder: `previous.json` plus up to 30 daily snapshots. All writes use a temporary file and atomic rename. Daily backups capture the *previous* state on the first write of each new day, not a backup after every transaction. Keep additional copies on a USB drive or other device: backups on the same disk cannot protect against disk failure.

## Migrating existing records
On the OLD app, click Export backup. In this desktop app, click Import backup and choose that JSON file. This is required when switching from browser storage to desktop file storage.

## Important notes
- This desktop version is intended for ONE computer and ONE running app instance; do not edit `inventory.json` manually.
- `npm run desktop` requires installing Electron dependencies (internet may be needed for installation); library use afterward is offline.
- Opening `index.html` directly is unsupported; use START_LIBRARY.cmd for desktop file storage.
- If saving fails, the transaction reports an error rather than claiming success.
- A JSON file is local persistent storage, not an SQL database.
- Automated backend tests do not replace hands-on desktop testing.


## New desktop tools
Open **Reports · Settings · Backups** in the footer to print inventory, inspect transaction activity, verify/restore snapshots and change borrowing rules. Existing copy status editing supports **lost** and **damaged**. USB scanners configured as keyboard input can scan accession numbers into the catalog search; dedicated barcode label printing is not included.

This edition requires the Electron desktop bridge. Opening index.html directly in a browser is not supported. Data is stored under Electron's userData/library-records folder. Keep separate USB copies of exported backups. Only one instance can run at a time.

This project is source code, not a precompiled Windows executable. Run npm install and npm run desktop on a computer with Node.js and internet access for the initial dependency installation. The existing bundled js/app.js is legacy; the desktop now loads src/main.js as an ES module.
