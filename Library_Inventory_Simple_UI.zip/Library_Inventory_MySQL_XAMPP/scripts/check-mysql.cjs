const mysql=require('mysql2/promise');
const config=require('../mysql-config.json');
(async()=>{let c;try{c=await mysql.createConnection({...config,database:undefined,connectTimeout:10000});const [rows]=await c.query('SELECT VERSION() AS version');console.log('Connection successful:',rows[0].version);console.log('The app creates database and tables on first startup.');}catch(e){console.error('Connection failed:',e.message);process.exitCode=1;}finally{if(c)await c.end();}})();
