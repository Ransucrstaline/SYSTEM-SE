import {build} from 'esbuild';
import {copyFileSync} from 'node:fs';
copyFileSync('node_modules/@zxing/library/umd/index.min.js','js/zxing.min.js');
await build({entryPoints:['src/main.js'],bundle:true,format:'iife',outfile:'js/app.js'});
