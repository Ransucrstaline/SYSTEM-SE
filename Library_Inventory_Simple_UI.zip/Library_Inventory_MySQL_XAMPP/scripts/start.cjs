const fs=require('node:fs');
const path=require('node:path');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..');
function fail(message){console.error('\nLibrary Inventory: '+message);process.exitCode=1;}
let executable;
try{executable=require('electron');}catch(error){fail('Electron is missing or incomplete. Run SETUP_AND_START.cmd to repair installation.\n'+error.message);return;}
if(typeof executable!=='string'||!fs.existsSync(executable)){fail('Electron executable is missing. Run SETUP_AND_START.cmd.');return;}
const env={...process.env};
delete env.ELECTRON_RUN_AS_NODE;
const child=spawn(executable,[root,...process.argv.slice(2)],{cwd:root,env,stdio:'inherit',windowsHide:false});
child.on('error',error=>fail(error.message));
child.on('exit',(code,signal)=>{
 if(code!==0||signal){fail('The app stopped ('+(signal||code)+'). Read the error above. If Windows blocked the downloaded app, check Windows Security protection history.');}
 else console.log('Library Inventory closed. If no window appeared, check Task Manager for an already running Library Inventory/Electron instance.');
});
