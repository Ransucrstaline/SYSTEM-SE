@echo off
net session >nul 2>&1
if errorlevel 1 (
 echo Right-click this file and choose Run as administrator.
 pause
 exit /b 1
)
powershell -NoProfile -Command "New-NetFirewallRule -DisplayName 'Library Inventory Phone Access 3210' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3210,3211 -RemoteAddress LocalSubnet -Profile Any -ErrorAction Stop"
echo If a rule already exists, you can keep using it.
echo Phone access is limited to devices on a directly connected network.
pause
