@echo off
cd /d "%~dp0"
echo Close the Library app before continuing. This clears only saved connection credentials.
node scripts/start.cjs --reset-mysql
if errorlevel 1 pause
