@echo off
setlocal
cd /d "%~dp0"
set ELECTRON_RUN_AS_NODE=
where node >nul 2>&1
if errorlevel 1 (
 echo Install Node.js LTS first, then reopen this file.
 pause
 exit /b 1
)
echo Installing project dependencies. Internet is needed for initial setup.
call npm install
if errorlevel 1 goto failed
echo Checking or downloading the Electron desktop runtime...
node node_modules\electron\install.js
if errorlevel 1 goto failed
call npm start
pause
exit /b
:failed
echo Setup failed. Copy the error above or take a screenshot of this window.
pause
exit /b 1
